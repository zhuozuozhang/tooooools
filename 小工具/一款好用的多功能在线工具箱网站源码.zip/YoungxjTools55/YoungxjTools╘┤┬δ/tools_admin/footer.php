<div class="row">
				
			</div>
		</div>
<div id="footer" class="col-xs-12">
                  <a href="http://www.youngxj.cn">杨小杰博客</a>
				</div>
            <script src="js/excanvas.min.js"></script>
            <script src="js/jquery.min.js"></script>
            <script src="js/jquery-ui.custom.js"></script>
            <script src="js/bootstrap.min.js"></script>
            <script src="js/jquery.flot.min.js"></script>
            <script src="js/jquery.flot.resize.min.js"></script>
            <script src="js/jquery.sparkline.min.js"></script>
            <script src="js/fullcalendar.min.js"></script>
			<script src="js/jquery.dataTables.min.js"></script>
            <script src="js/jquery.nicescroll.min.js"></script>
            <script src="js/unicorn.js"></script>
            <script src="js/unicorn.dashboard.js"></script>
	</body>
</html>
