<?php include 'header.php';?>
<style type="text/css">
	.row{
		display: table-cell;
		vertical-align: middle;
	}
	.container{
		display:table;
		height:100%;
	}
	.row-centered {
		padding-top: 70px;
		text-align:center;
	}
</style>
<div class="container">
	<div class="row row-centered">
		<div class="form-group" id="input-wrap">
			<h1 class="text-center" style="font-size: 112px;">404</h1>
			<h3 class="text-center"><script>text()</script></h3>
		</div>
	</div>
</div>
<script type="text/javascript"></script>
<?php include 'footer.php';?>
