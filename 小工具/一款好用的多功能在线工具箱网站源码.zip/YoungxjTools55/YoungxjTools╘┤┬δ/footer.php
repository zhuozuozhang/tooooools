<!--footer start-->
<footer class="footer text-center">
	<div>
    <!--切勿商用,切勿改版权,后果自付-->
		Copyright <a href="http://www.youngxj.cn" target="_blank">Youngxj</a> 2018 - <?php echo $tools_settings['icp'];?>  <a href="../log.php" target="_blank">时间轴</a> <a href="../about.php" target="_blank">关于</a>
	</div>
	<div class="hitokoto">
      	<script type="text/javascript" src="https://api.yum6.cn/yan.php?format=js"></script>
		<script>text()</script>
	</div>
  <div class="footer text-center">
    <?php echo $tools_settings['footer'];?>
  </div>
  <div id="f_list">
    <a rel="noopener noreferrer" target="_blank" class="btn qq-qun copy-btn js-tip" title="QQ群" href="//shang.qq.com/wpa/qunwpa?idkey=3ce04929f3f5c27b3fc20a892fefd8bfa9a2849f6e33fb4c49b1f1ab16991ff5" original-title="QQ群: 774688083"><i class="fa fa-qq"></i></a>
    <a rel="noopener noreferrer" target="_blank" class="btn weibo js-tip" href="http://weibo.com/youngxj0" title="微博"><i class="fa fa-weibo"></i></a>
    <a rel="noopener noreferrer" target="_blank" class="btn weibo js-tip" href="javascript:temp();" title="切换主题"><i class="fa fa-television"></i></a>
    <a rel="noopener noreferrer" target="_blank" class="btn github js-tip" href="https://gitee.com/youngxj0/YoungxjTools"><i class="fa fa-github-alt"></i></a>
    <a class="btn gotop js-tip" href="javascript:gotop();" title="返回顶部" id="gotop"><i class="fa fa-arrow-up"></i></a>
</div>

</footer>
</body>
</html>