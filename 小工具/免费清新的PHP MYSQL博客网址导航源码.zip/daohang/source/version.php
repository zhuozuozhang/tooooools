<?php
define('SYS_NAME', '网址导航管理系统');
define('SYS_VERSION', '1.0');
define('SYS_RELEASE', '20160825');
?>