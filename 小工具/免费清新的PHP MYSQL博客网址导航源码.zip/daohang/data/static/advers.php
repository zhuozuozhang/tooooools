<?php
//File name: advers.php
//Creation time: 2016-08-25 08:09:31

if (!defined('IN_HANFOX')) exit('Access Denied');

$static_data = array(
	'3' => array(
		'adver_type' => '2',
		'adver_name' => '广告位（3）250*250',
		'adver_url' => '',
		'adver_code' => '这是广告位（3），请在后台网站广告放置广告代码！',
		'adver_etips' => '',
		'adver_days' => '0',
		'adver_date' => '1472112532'
	),
	'2' => array(
		'adver_type' => '2',
		'adver_name' => '广告位（2）710*100',
		'adver_url' => '',
		'adver_code' => '这是广告位（2），请在后台网站广告放置广告代码！',
		'adver_etips' => '',
		'adver_days' => '0',
		'adver_date' => '1472112571'
	),
	'1' => array(
		'adver_type' => '2',
		'adver_name' => '广告位（1）250*250',
		'adver_url' => '',
		'adver_code' => '这是广告位（1），请在后台网站广告放置广告代码！',
		'adver_etips' => '',
		'adver_days' => '0',
		'adver_date' => '1472112491'
	),
);
?>