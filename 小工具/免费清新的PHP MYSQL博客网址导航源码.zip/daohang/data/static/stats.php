<?php
//File name: stats.php
//Creation time: 2016-01-18 15:33:51

if (!defined('IN_HANFOX')) exit('Access Denied');

$static_data = array(
	'category' => '1',
	'website' => '1',
	'adver' => '0',
	'link' => '0',
	'feedback' => '0',
	'label' => '0',
	'page' => '0',
);
?>