<?php
//File name: category_1.php
//Creation time: 2016-08-25 08:24:14

if (!defined('IN_HANFOX')) exit('Access Denied');

$static_data = array(
	'cate_id' => '1',
	'root_id' => '0',
	'cate_name' => '测试',
	'cate_dir' => '',
	'cate_url' => '',
	'cate_isbest' => '1',
	'cate_keywords' => '',
	'cate_description' => '',
	'cate_arrparentid' => '0',
	'cate_arrchildid' => '1',
	'cate_childcount' => '0',
	'cate_postcount' => '0',
);
?>