<?php
//File name: archives.php
//Creation time: 2016-08-25 08:24:45

if (!defined('IN_HANFOX')) exit('Access Denied');

$static_data = array(
	'2016' => array(
		'08' => '1',
	),
);
?>