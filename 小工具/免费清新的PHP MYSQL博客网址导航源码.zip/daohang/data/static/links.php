<?php
//File name: links.php
//Creation time: 2016-01-18 15:33:51

if (!defined('IN_HANFOX')) exit('Access Denied');

$static_data = array(
);
?>