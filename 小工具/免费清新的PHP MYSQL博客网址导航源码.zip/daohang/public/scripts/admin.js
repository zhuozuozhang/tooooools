//全选
function CheckAll(form){
	for (var i = 0; i < form.elements.length; i++) {
    	var e = form.elements[i];
        if (e.Name != "ChkAll" && e.disabled == false)
			e.checked = form.ChkAll.checked;
	}
}

//判断是否选择
function IsCheck(ObjName){
	var Obj = document.getElementsByName(ObjName); //获取复选框数组
    var ObjLen = Obj.length; //获取数组长度
    var Flag = false; //是否有选择
    for (var i = 0; i < ObjLen; i++) {
		if (Obj[i].checked == true) {
			Flag = true;
			break;
		}
	}
	return Flag;
}

//栏目合并判断
function ConfirmUnite() {
	if ($("#CurrentClassID").attr("value") == $("#TargetClassID").attr("value")) {
		alert("请不要在相同栏目内进行操作！");
		$("#TargetClassID").focus();
		return false;
	}
return true;
}

//获取META
function GetMeta() {
	var url = $("#web_url").attr("value");
	if (url == '') {
		alert('请输入网站域名！');
		$("#web_url").focus();
		return false;
	}
	$(document).ready(function(){$("#meta_btn").val('正在获取，请稍候...'); $.ajax({type: "GET", url: 'website.php?act=metainfo', data: 'url=' + url, datatype: "script", cache: false, success: function(data){$("body").append(data); $("#meta_btn").val('重新获取');}});});		
}

//获取ip, PageRank, Sogou PageRank, Alexa
function GetData() {
	var url = $("#web_url").attr("value");
	if (url == '') {
		alert('请输入网站域名！');
		$("#web_url").focus();
		return false;
	}
	$(document).ready(function(){$("#data_btn").val('正在获取，请稍候...'); $.ajax({type: "GET", url: 'website.php?act=webdata', data: 'url=' + url, datatype: "script", cache: false, success: function(data){$("body").append(data); $("#data_btn").val('重新获取');}});});		
}

//自动去除http
function strip_http() {
	var url = $("#web_url").val();
    if (url.indexOf("http://") >= 0) {
		url = url.replace("http://", "");
	}
    if (url.indexOf("/") >= 0) {
		var domainArr = url.split("/");
        $("#web_url").val(domainArr[0]);
	} else {
		$("#web_url").val(url);
	}
    return domain.replace(" ", "");
}

//验证url
function checkurl(url){
	if (url == '') {
		$("#msg").html('请输入网站域名！');
		return false;
	}
	
	$(document).ready(function(){$("#msg").html('<img src="' + sitepath + 'public/images/loading.gif" align="absmiddle"> 正在验证，请稍候...'); $.ajax({type: "GET", url: sitepath + '?mod=ajaxget&type=check', data: 'url=' + url, cache: false, success: function(data){$("#msg").html(data)}});});
return true;
};