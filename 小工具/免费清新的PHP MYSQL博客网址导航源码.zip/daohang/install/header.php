	<div class="top">
		<div class="logo"></div>
		<div id="link"><a href="http://www.tianyaseo.com/daohang/" target="_blank">官方网站</a> | <a href="mailto:ws1993@yeah.net" target="_blank">联系我们</a></div>
	</div>