---
name: Bug report | 错误反馈
about: Create a report to help us improve | 对于现有功能的建议与反馈
title: ''
labels: bug
assignees: HelipengTony

---

**描述错误情况**
A clear and concise description of what the bug is.

**场景图片**
If applicable, add screenshots to help explain your problem.

**版本号**
In the theme style.css, the first couple of lines of codes tell you the version you are at.

**Additional context**
Add any other context about the problem here.
