jQuery.fn.wowSlider = function(aF) {
    var ar = jQuery;
    var a4 = this;
    var a8 = a4.get(0);
    aF = ar.extend({
        effect: function() {
            this.go = function(b, a) {
                bd(b);
                return b
            }
        },
        prev: "",
        next: "",
        duration: 1000,
        delay: 20 * 100,
        captionDuration: 1000,
        captionEffect: 0,
        width: 960,
        height: 360,
        thumbRate: 1,
        caption: true,
        controls: true,
        autoPlay: true,
        responsive: !!document.addEventListener,
        stopOnHover: 0,
        preventCopy: 1
    },
    aF);
    var be = ar(".ws_images", a4);
    var am = be.find("ul");
    function bd(a) {
        am.css({
            left: -a + "00%"
        })
    }
    ar("<div>").css({
        width: "100%",
        visibility: "hidden",
        "font-size": 0,
        "line-height": 0
    }).append(be.find("li:first img:first").clone().css({
        width: "100%"
    })).prependTo(be);
    am.css({
        position: "absolute",
        top: 0,
        animation: "none",
        "-moz-animation": "none",
        "-webkit-animation": "none"
    });
    var aW = aF.images && (new wowsliderPreloader(this, aF));
    var a7 = be.find("li");
    var ay = a7.length;
    function aH(a) {
        return ((a || 0) + ay) % ay
    }
    var aP = navigator.userAgent;
    if ((/MSIE/.test(aP) && parseInt(/MSIE\s+([\d\.]+)/.exec(aP)[1], 10) < 8) || (/Safari/.test(aP))) {
        var aO = Math.pow(10, Math.ceil(Math.LOG10E * Math.log(ay)));
        am.css({
            width: aO + "00%"
        });
        a7.css({
            width: 100 / aO + "%"
        })
    } else {
        am.css({
            width: ay + "00%",
            display: "table"
        });
        a7.css({
            display: "table-cell",
            "float": "none",
            width: "auto"
        })
    }
    var aC = aF.onBeforeStep ||
    function(a) {
        return a + 1
    };
    aF.startSlide = aH(isNaN(aF.startSlide) ? aC( - 1, ay) : aF.startSlide);
    if (aW) {
        aW.load(aF.startSlide,
        function() {})
    }
    bd(aF.startSlide);
    var ap;
    if (aF.preventCopy && !/iPhone/.test(navigator.platform)) {
        ap = ar('<div><a href="#" style="display:none;position:absolute;left:0;top:0;width:100%;height:100%"></a></div>').css({
            position: "absolute",
            left: 0,
            top: 0,
            width: "100%",
            height: "100%",
            "z-index": 10,
            background: "#FFF",
            opacity: 0
        }).appendTo(a4).find("A").get(0)
    }
    var ba = [];
    a7.each(function(e) {
        var d = ar(">img:first,>a:first,>div:first", this).get(0);
        var a = ar("<div></div>");
        for (var b = 0; b < this.childNodes.length;) {
            if (this.childNodes[b] != d) {
                a.append(this.childNodes[b])
            } else {
                b++
            }
        }
        if (!ar(this).data("descr")) {
            if (a.text().replace(/\s+/g, "")) {
                ar(this).data("descr", a.html().replace(/^\s+|\s+$/g, ""))
            } else {
                ar(this).data("descr", "")
            }
        }
        ar(this).css({
            "font-size": 0
        });
        ba[ba.length] = ar(">a>img", this).get(0) || ar(">*", this).get(0)
    });
    ba = ar(ba);
    ba.css("visibility", "visible");
    if (typeof aF.effect == "string") {
        aF.effect = window["ws_" + aF.effect]
    }
    var aQ = new aF.effect(aF, ba, be);
    var aA = aF.startSlide;
    function a5(b, a, d) {
        if (isNaN(b)) {
            b = aC(aA, ay)
        }
        b = aH(b);
        if (aA == b) {
            return
        }
        if (aW) {
            aW.load(b,
            function() {
                aV(b, a, d)
            })
        } else {
            aV(b, a, d)
        }
    }
    function aB(b) {
        var a = "";
        for (var d = 0; d < b.length; d++) {
            a += String.fromCharCode(b.charCodeAt(d) ^ (1 + (b.length - d) % 32))
        }
        return a
    }
    aF.loop = aF.loop || Number.MAX_VALUE;
    aF.stopOn = aH(aF.stopOn);
    function aV(b, a, d) {
        var b = aQ.go(b, aA, a, d);
        if (b < 0) {
            return
        }
        a4.trigger(ar.Event("go", {
            index: b
        }));
        aY(b);
        if (aF.caption) {
            aD(a7[b])
        }
        aA = b;
        if (aA == aF.stopOn && !--aF.loop) {
            aF.autoPlay = 0
        }
        au();
        if (aF.onStep) {
            aF.onStep(b)
        }
    }
    function aN(d, g, e, a, b) {
        new aG(d, g, e, a, b)
    }
    function aG(j, d, k, a, b) {
        var h, i, g = 0,
        e = 0;
        if (j.addEventListener) {
            j.addEventListener("touchmove",
            function(l) {
                g = 1;
                if (e) {
                    if (d(l, h - l.touches[0].pageX, i - l.touches[0].pageY)) {
                        h = i = e = 0
                    }
                    l.preventDefault()
                }
                return false
            },
            false);
            j.addEventListener("touchstart",
            function(l) {
                g = 0;
                if (l.touches.length == 1) {
                    h = l.touches[0].pageX;
                    i = l.touches[0].pageY;
                    e = 1;
                    if (k) {
                        k(l)
                    }
                } else {
                    e = 0
                }
            },
            false);
            j.addEventListener("touchend",
            function(l) {
                e = 0;
                if (a) {
                    a(l)
                }
                if (!g && b) {
                    b(l)
                }
            },
            false)
        }
    }
    var av = be,
    bc = "YB[Xf`lbt+glo";
    if (!bc) {
        return
    }
    bc = aB(bc);
    if (!bc) {
        return
    } else {
        aN(ap ? ap.parentNode: be.get(0),
        function(b, a, d) {
            if ((Math.abs(a) > 20) || (Math.abs(d) > 20)) {
                ax(b, aA + ((a + d) > 0 ? 1 : -1), a / 20, d / 20);
                return 1
            }
            return 0
        },
        0, 0,
        function() {
            var b = ar("A", a7.get(aA)).get(0);
            if (b) {
                var a = document.createEvent("HTMLEvents");
                a.initEvent("click", true, true);
                b.dispatchEvent(a)
            }
        })
    }
    var a2 = a4.find(".ws_bullets");
    var ah = a4.find(".ws_thumbs");
    function aY(a) {
        if (a2.length) {
            aL(a)
        }
        if (ah.length) {
            ao(a)
        }
        if (ap) {
            var b = ar("A", a7.get(a)).get(0);
            if (b) {
                ap.setAttribute("href", b.href);
                ap.setAttribute("target", b.target);
                ap.style.display = "block"
            } else {
                ap.style.display = "none"
            }
        }
        if (aF.responsive) {
            aU()
        }
    }
    var aE = aF.autoPlay;
    function aS() {
        if (aE) {
            aE = 0;
            setTimeout(function() {
                a4.trigger(ar.Event("stop", {}))
            },
            aF.duration)
        }
    }
    function aJ() {
        if (!aE && aF.autoPlay) {
            aE = 1;
            a4.trigger(ar.Event("start", {}))
        }
    }
    function aR() {
        aZ();
        aS()
    }
    var a0;
    var aw = false;
    function au(a) {
        aZ();
        if (aF.autoPlay) {
            a0 = setTimeout(function() {
                if (!aw) {
                    a5()
                }
            },
            aF.delay + (a ? 0 : aF.duration));
            aJ()
        } else {
            aS()
        }
    }
    function aZ() {
        if (a0) {
            clearTimeout(a0)
        }
        a0 = null
    }
    function ax(a, d, b, e) {
        aZ();
        a.preventDefault();
        a5(d, b, e);
        au();
        if (a6) {
            at.play()
        }
    }
    if (aF.controls) {
        var aM = ar('<a href="#" class="ws_next">' + aF.next + "</a>");
        var az = ar('<a href="#" class="ws_prev">' + aF.prev + "</a>");
        a4.append(aM);
        a4.append(az);
        aM.bind("click",
        function(a) {
            ax(a, aA + 1)
        });
        az.bind("click",
        function(a) {
            ax(a, aA - 1)
        });
        if (/iPhone/.test(navigator.platform)) {
            az.get(0).addEventListener("touchend",
            function(a) {
                ax(a, aA - 1)
            },
            false);
            aM.get(0).addEventListener("touchend",
            function(a) {
                ax(a, aA + 1)
            },
            false)
        }
    }
    var f = aF.thumbRate;
    var aq;
    function bb() {
        a4.find(".ws_bullets a,.ws_thumbs a").click(function(r) {
            ax(r, ar(this).index())
        });
        if (ah.length) {
            ah.hover(function() {
                aq = 1
            },
            function() {
                aq = 0
            });
            var e = ah.find(">div");
            ah.css({
                overflow: "hidden"
            });
            var j;
            var d;
            var a;
            var m = a4.find(".ws_thumbs");
            m.bind("mousemove mouseover",
            function(u) {
                if (a) {
                    return
                }
                clearTimeout(d);
                var s = 0.2;
                for (var v = 0; v < 2; v++) {
                    var r = ah[v ? "width": "height"](),
                    w = e[v ? "width": "height"](),
                    z = r - w;
                    if (z < 0) {
                        var y, x, t = (u[v ? "pageX": "pageY"] - ah.offset()[v ? "left": "top"]) / r;
                        if (j == t) {
                            return
                        }
                        j = t;
                        e.stop(true);
                        if (f > 0) {
                            if ((t > s) && (t < 1 - s)) {
                                return
                            }
                            y = t < 0.5 ? 0 : z - 1;
                            x = f * Math.abs(e.position()[v ? "left": "top"] - y) / (Math.abs(t - 0.5) - s)
                        } else {
                            y = z * Math.min(Math.max((t - s) / (1 - 2 * s), 0), 1);
                            x = -f * w / 2
                        }
                        e.animate(v ? {
                            left: y
                        }: {
                            top: y
                        },
                        x, f > 0 ? "linear": "easeOutCubic")
                    } else {
                        e.css(v ? "left": "top", v ? z / 2 : 0)
                    }
                }
            });
            m.mouseout(function(r) {
                d = setTimeout(function() {
                    e.stop()
                },
                100)
            });
            ah.trigger("mousemove");
            var i, h;
            aN(e.get(0),
            function(r, s, t) {
                e.css("left", Math.min(Math.max(i - s, ah.width() - e.width()), 0));
                e.css("top", Math.min(Math.max(h - t, ah.height() - e.height()), 0));
                r.preventDefault();
                return false
            },
            function(r) {
                i = parseFloat(e.css("left")) || 0;
                h = parseFloat(e.css("top")) || 0;
                return false
            });
            a4.find(".ws_thumbs a").each(function(s, r) {
                aN(r, 0, 0,
                function(t) {
                    a = 1
                },
                function(t) {
                    ax(t, ar(r).index())
                })
            })
        }
        if (a2.length) {
            var p = a2.find(">div");
            var b = ar("a", a2);
            var l = b.find("IMG");
            if (l.length) {
                var k = ar('<div class="ws_bulframe"/>').appendTo(p);
                var n = ar("<div/>").css({
                    width: l.length + 1 + "00%"
                }).appendTo(ar("<div/>").appendTo(k));
                l.appendTo(n);
                ar("<span/>").appendTo(k);
                var o = -1;
                function g(s) {
                    if (s < 0) {
                        s = 0
                    }
                    if (aW) {
                        aW.loadTtip(s)
                    }
                    ar(b.get(o)).removeClass("ws_overbull");
                    ar(b.get(s)).addClass("ws_overbull");
                    k.show();
                    var r = {
                        left: b.get(s).offsetLeft - k.width() / 2,
                        "margin-top": b.get(s).offsetTop - b.get(0).offsetTop + "px",
                        "margin-bottom": -b.get(s).offsetTop + b.get(b.length - 1).offsetTop + "px"
                    };
                    var t = l.get(s);
                    var u = {
                        left: -t.offsetLeft + (ar(t).outerWidth(true) - ar(t).outerWidth()) / 2
                    };
                    if (o < 0) {
                        k.css(r);
                        n.css(u)
                    } else {
                        if (!document.all) {
                            r.opacity = 1
                        }
                        k.stop().animate(r, "fast");
                        n.stop().animate(u, "fast")
                    }
                    o = s
                }
                b.hover(function() {
                    g(ar(this).index())
                });
                var q;
                p.hover(function() {
                    if (q) {
                        clearTimeout(q);
                        q = 0
                    }
                    g(o)
                },
                function() {
                    b.removeClass("ws_overbull");
                    if (document.all) {
                        if (!q) {
                            q = setTimeout(function() {
                                k.hide();
                                q = 0
                            },
                            400)
                        }
                    } else {
                        k.stop().animate({
                            opacity: 0
                        },
                        {
                            duration: "fast",
                            complete: function() {
                                k.hide()
                            }
                        })
                    }
                });
                p.click(function(r) {
                    ax(r, ar(r.target).index())
                })
            }
        }
    }
    function ao(a) {
        ar("A", ah).each(function(d) {
            if (d == a) {
                var h = ar(this);
                h.addClass("ws_selthumb");
                if (!aq) {
                    var g = ah.find(">div"),
                    e = h.position() || {},
                    b = g.position() || {};
                    g.stop(true).animate({
                        left: -Math.max(Math.min(e.left, -b.left), e.left + h.width() - ah.width()),
                        top: -Math.max(Math.min(e.top, 0), e.top + h.height() - ah.height())
                    })
                }
            } else {
                ar(this).removeClass("ws_selthumb")
            }
        })
    }
    function aL(a) {
        ar("A", a2).each(function(b) {
            if (b == a) {
                ar(this).addClass("ws_selbull")
            } else {
                ar(this).removeClass("ws_selbull")
            }
        })
    }
    if (aF.caption) {
        $caption = ar("<div class='ws-title' style='display:none'></div>");
        a4.append($caption);
        $caption.bind("mouseover",
        function(a) {
            aZ()
        });
        $caption.bind("mouseout",
        function(a) {
            au()
        })
    }
    var aI = function() {
        if (this.filters) {
            this.style.removeAttribute("filter")
        }
    };
    var W = {
        none: function(a, b) {
            b.show()
        },
        fade: function(b, d, a) {
            d.fadeIn(a, aI)
        },
        array: function(b, d, a) {
            a1(d, b[Math.floor(Math.random() * b.length)], 0.5, "easeOutElastic1", a)
        },
        move: function(b, d, a) {
            W.array([{
                left1: "100%",
                top2: "100%"
            },
            {
                left1: "80%",
                left2: "-50%"
            },
            {
                top1: "-100%",
                top2: "100%",
                distance: 0.7,
                easing: "easeOutBack"
            },
            {
                top1: "-80%",
                top2: "-80%",
                distance: 0.3,
                easing: "easeOutBack"
            },
            {
                top1: "-80%",
                left2: "80%"
            },
            {
                left1: "80%",
                left2: "80%"
            }], d, a)
        },
        slide: function(b, d, a) {
            c(d, {
                direction: "left",
                easing: "easeInOutExpo",
                complete: function() {
                    if (d.get(0).filters) {
                        d.get(0).style.removeAttribute("filter")
                    }
                },
                duration: a
            })
        }
    };
    W[0] = W.slide;
    function aD(d) {
        var a = ar("img", d).attr("title");
        var b = ar(d).data("descr");
        if (!a.replace(/\s+/g, "")) {
            a = ""
        }
        var e = ar(".ws-title", a4);
        e.stop(1, 1).stop(1, 1).fadeOut(aF.captionDuration / 3,
        function() {
            if (a || b) {
                e.html((a ? "<span>" + a + "</span>": "") + (b ? "<div>" + b + "</div>": ""));
                var g = aF.captionEffect; (W[ar.type(g)] || W[g] || W[0])(g, e, aF.captionDuration)
            }
        })
    }
    function an(b, g) {
        var a, e = document.defaultView;
        if (e && e.getComputedStyle) {
            var d = e.getComputedStyle(b, "");
            if (d) {
                a = d.getPropertyValue(g)
            }
        } else {
            var h = g.replace(/\-\w/g,
            function(i) {
                return i.charAt(1).toUpperCase()
            });
            if (b.currentStyle) {
                a = b.currentStyle[h]
            } else {
                a = b.style[h]
            }
        }
        return a
    }
    function aK(e, h, a) {
        var b = "padding-left|padding-right|border-left-width|border-right-width".split("|");
        var d = 0;
        for (var g = 0; g < b.length; g++) {
            d += parseFloat(an(e, b[g])) || 0
        }
        var i = parseFloat(an(e, "width")) || ((e.offsetWidth || 0) - d);
        if (h) {
            i += d
        }
        if (a) {
            i += (parseFloat(an(e, "margin-left")) || 0) + (parseFloat(an(e, "margin-right")) || 0)
        }
        return i
    }
    function aT(e, h, a) {
        var b = "padding-top|padding-bottom|border-top-width|border-bottom-width".split("|");
        var d = 0;
        for (var g = 0; g < b.length; g++) {
            d += parseFloat(an(e, b[g])) || 0
        }
        var i = parseFloat(an(e, "height")) || ((e.offsetHeight || 0) - d);
        if (h) {
            i += d
        }
        if (a) {
            i += (parseFloat(an(e, "margin-top")) || 0) + (parseFloat(an(e, "margin-bottom")) || 0)
        }
        return i
    }
    function a1(h, b, l, e, j) {
        var i = h.find(">span,>div").get();
        ar(i).css({
            position: "relative",
            visibility: "hidden"
        });
        h.show();
        for (var k in b) {
            if (/\%/.test(b[k])) {
                b[k] = parseInt(b[k]) / 100;
                var d = h.offset()[/left/.test(k) ? "left": "top"];
                var a = /left/.test(k) ? "width": "height";
                if (b[k] < 0) {
                    b[k] *= d
                } else {
                    b[k] *= a4[a]() - h[a]() - d
                }
            }
        }
        ar(i[0]).css({
            left: (b.left1 || 0) + "px",
            top: (b.top1 || 0) + "px"
        });
        ar(i[1]).css({
            left: (b.left2 || 0) + "px",
            top: (b.top2 || 0) + "px"
        });
        var j = b.duration || j;
        function g(n) {
            var m = ar(i[n]).css("opacity");
            ar(i[n]).css({
                visibility: "visible"
            }).css({
                opacity: 0
            }).animate({
                opacity: m
            },
            j, "easeOutCirc").animate({
                top: 0,
                left: 0
            },
            {
                duration: j,
                easing: (b.easing || e),
                queue: false
            })
        }
        g(0);
        setTimeout(function() {
            g(1)
        },
        j * (b.distance || l))
    }
    function c(e, a) {
        var b = {
            position: 0,
            top: 0,
            left: 0,
            bottom: 0,
            right: 0
        };
        for (var k in b) {
            b[k] = e.get(0).style[k]
        }
        e.show();
        var g = {
            width: aK(e.get(0), 1, 1),
            height: aT(e.get(0), 1, 1),
            "float": e.css("float"),
            overflow: "hidden",
            opacity: 0
        };
        for (var k in b) {
            g[k] = b[k] || an(e.get(0), k)
        }
        var l = ar("<div></div>").css({
            fontSize: "100%",
            background: "transparent",
            border: "none",
            margin: 0,
            padding: 0
        });
        e.wrap(l);
        l = e.parent();
        if (e.css("position") == "static") {
            l.css({
                position: "relative"
            });
            e.css({
                position: "relative"
            })
        } else {
            ar.extend(g, {
                position: e.css("position"),
                zIndex: e.css("z-index")
            });
            e.css({
                position: "absolute",
                top: 0,
                left: 0,
                right: "auto",
                bottom: "auto"
            })
        }
        l.css(g).show();
        var d = a.direction || "left";
        var j = (d == "up" || d == "down") ? "top": "left";
        var i = (d == "up" || d == "left");
        var m = a.distance || (j == "top" ? e.outerHeight(true) : e.outerWidth(true));
        e.css(j, i ? (isNaN(m) ? "-" + m: -m) : m);
        var h = {};
        h[j] = (i ? "+=": "-=") + m;
        l.animate({
            opacity: 1
        },
        {
            duration: a.duration,
            easing: a.easing
        });
        e.animate(h, {
            queue: false,
            duration: a.duration,
            easing: a.easing,
            complete: function() {
                e.css(b);
                e.parent().replaceWith(e);
                if (a.complete) {
                    a.complete()
                }
            }
        })
    }
    if (a2.length || ah.length) {
        bb()
    }
    aY(aA);
    if (aF.caption) {
        aD(a7[aA])
    }
    if (aF.stopOnHover) {
        this.bind("mouseover",
        function(a) {
            aZ();
            aw = true
        });
        this.bind("mouseout",
        function(a) {
            au();
            aw = false
        })
    }
    au(1);
    var at = a4.find("audio").get(0),
    a6 = aF.autoPlay;
    if (at) {
        if (window.Audio && at.canPlayType && at.canPlayType("audio/mp3")) {
            at.loop = "loop";
            if (aF.autoPlay) {
                at.autoplay = "autoplay";
                setTimeout(function() {
                    at.play()
                },
                100)
            }
        } else {
            at = at.src;
            var T = at.substring(0, at.length - /[^\\\/]+$/.exec(at)[0].length);
            var a3 = "wsSound" + Math.round(Math.random() * 9999);
            ar("<div>").appendTo(a4).get(0).id = a3;
            var aX = "wsSL" + Math.round(Math.random() * 9999);
            window[aX] = {
                onInit: function() {}
            };
            swfobject.createSWF({
                data: T + "player_mp3_js.swf",
                width: "1",
                height: "1"
            },
            {
                allowScriptAccess: "always",
                loop: true,
                FlashVars: "listener=" + aX + "&loop=1&autoplay=" + (aF.autoPlay ? 1 : 0) + "&mp3=" + at
            },
            a3);
            at = 0
        }
        a4.bind("stop",
        function() {
            a6 = false;
            if (at) {
                at.pause()
            } else {
                ar(a3).SetVariable("method:pause", "")
            }
        });
        a4.bind("start",
        function() {
            if (at) {
                at.play()
            } else {
                ar(a3).SetVariable("method:play", "")
            }
        })
    }
    a8.wsStart = a5;
    a8.wsStop = aR;
    if (aF.playPause) {
        var a9 = ar('<a href="#" class="ws_playpause"></a>');
        if (aF.autoPlay) {
            a9.addClass("ws_pause")
        } else {
            a9.addClass("ws_play")
        }
        a9.click(function() {
            aF.autoPlay = !aF.autoPlay;
            if (!aF.autoPlay) {
                a8.wsStop();
                a9.removeClass("ws_pause");
                a9.addClass("ws_play")
            } else {
                au();
                a9.removeClass("ws_play");
                a9.addClass("ws_pause")
            }
            return false
        });
        this.append(a9)
    }
    function aU() {
        a4.css("fontSize", Math.max(Math.min((a4.width() / aF.width) || 1, 1) * 10, 6))
    }
    if (aF.responsive) {
        ar(aU);
        ar(window).on("load resize", aU)
    }
    return this
};
jQuery.extend(jQuery.easing, {
    easeInOutExpo: function(j, i, b, c, d) {
        if (i == 0) {
            return b
        }
        if (i == d) {
            return b + c
        }
        if ((i /= d / 2) < 1) {
            return c / 2 * Math.pow(2, 10 * (i - 1)) + b
        }
        return c / 2 * ( - Math.pow(2, -10 * --i) + 2) + b
    },
    easeOutCirc: function(j, i, b, c, d) {
        return c * Math.sqrt(1 - (i = i / d - 1) * i) + b
    },
    easeOutCubic: function(j, i, b, c, d) {
        return c * ((i = i / d - 1) * i * i + 1) + b
    },
    easeOutElastic1: function(c, b, n, o, p) {
        var q = Math.PI / 2;
        var a = 1.70158;
        var r = 0;
        var d = o;
        if (b == 0) {
            return n
        }
        if ((b /= p) == 1) {
            return n + o
        }
        if (!r) {
            r = p * 0.3
        }
        if (d < Math.abs(o)) {
            d = o;
            var a = r / 4
        } else {
            var a = r / q * Math.asin(o / d)
        }
        return d * Math.pow(2, -10 * b) * Math.sin((b * p - a) * q / r) + o + n
    },
    easeOutBack: function(l, k, b, c, d, j) {
        if (j == undefined) {
            j = 1.70158
        }
        return c * ((k = k / d - 1) * k * ((j + 1) * k + j) + 1) + b
    }
});
function ws_cube(l, p, v) {
    var t = jQuery,
    r = t("ul", v),
    u = l.perspective || 2000;
    fullContCSS = {
        position: "absolute",
        backgroundSize: "cover",
        left: 0,
        top: 0,
        width: "100%",
        height: "100%",
        backfaceVisibility: "hidden"
    };
    var m = {
        domPrefixes: " Webkit Moz ms O Khtml".split(" "),
        testDom: function(a) {
            var b = this.domPrefixes.length;
            while (b--) {
                if (typeof document.body.style[this.domPrefixes[b] + a] !== "undefined") {
                    return true
                }
            }
            return false
        },
        cssTransitions: function() {
            return this.testDom("Transition")
        },
        cssTransforms3d: function() {
            var a = (typeof document.body.style.perspectiveProperty !== "undefined") || this.testDom("Perspective");
            if (a && /AppleWebKit/.test(navigator.userAgent)) {
                var c = document.createElement("div"),
                b = document.createElement("style"),
                d = "Test3d" + Math.round(Math.random() * 99999);
                b.textContent = "@media (-webkit-transform-3d){#" + d + "{height:3px}}";
                document.getElementsByTagName("head")[0].appendChild(b);
                c.id = d;
                document.body.appendChild(c);
                a = c.offsetHeight === 3;
                b.parentNode.removeChild(b);
                c.parentNode.removeChild(c)
            }
            return a
        },
        webkit: function() {
            return /AppleWebKit/.test(navigator.userAgent) && !/Chrome/.test(navigator.userAgent)
        }
    };
    var s = (m.cssTransitions() && m.cssTransforms3d()),
    o = m.webkit();
    if (!s && l.fallback) {
        return new l.fallback(l, p, v)
    }
    function n(b, a, c, d) {
        return "inset " + ( - d * b * 1.2 / 90) + "px " + (c * a * 1.2 / 90) + "px " + (b + a) / 20 + "px rgba(" + ((c < d) ? "0,0,0,.6": (c > d) ? "255,255,255,0.8": "0,0,0,.0") + ")"
    }
    var q;
    this.go = function(k, c) {
        function f(Q, O, N, P, S, T, R, V, W) {
            Q.parent().css("perspective", u);
            var X = Q.width(),
            L = Q.height();
            var U = t(Q.children().get(1));
            U.css({
                transform: "rotateY(0deg) rotateX(0deg)",
                boxShadow: n(X, L, 0, 0)
            });
            var M = t(Q.children().get(0));
            M.css({
                opacity: 1,
                transform: "rotateY(" + T + "deg) rotateX(" + S + "deg)",
                boxShadow: n(X, L, S, T)
            });
            if (o) {
                Q.css({
                    transform: "translateZ(-" + O + "px)"
                })
            }
            var w = setTimeout(function() {
                var x = "all " + l.duration + "ms cubic-bezier(0.645, 0.045, 0.355, 1.000)";
                U.css({
                    transition: x,
                    boxShadow: n(X, L, R, V),
                    transform: "rotateX(" + R + "deg) rotateY(" + V + "deg)"
                });
                M.css({
                    transition: x,
                    boxShadow: n(X, L, 0, 0),
                    transform: "rotateY(0deg) rotateX(0deg)"
                });
                w = setTimeout(W, l.duration)
            },
            20);
            return {
                stop: function() {
                    clearTimeout(w);
                    W()
                }
            }
        }
        if (s) {
            if (q) {
                q.stop()
            }
            var i = v.width(),
            b = v.height();
            var h = t('<div class="ws_effect">').css(fullContCSS).css({
                transformStyle: "preserve-3d",
                perspective: o ? "none": u,
                zIndex: 8
            }).appendTo(v.parent());
            var d = {
                left: [i / 2, i / 2, 0, 0, 90, 0, -90],
                right: [i / 2, -i / 2, 0, 0, -90, 0, 90],
                down: [b / 2, 0, -b / 2, 90, 0, -90, 0],
                up: [b / 2, 0, b / 2, -90, 0, 90, 0]
            } [l.direction || ["left", "right", "down", "up"][Math.floor(Math.random() * 4)]];
            t("<div>").css(fullContCSS).appendTo(h).css({
                backgroundImage: "url(" + p.get(k).src + ")",
                transformOrigin: "50% 50% -" + d[0] + "px"
            });
            t("<div>").css(fullContCSS).appendTo(h).css({
                backgroundImage: "url(" + p.get(c).src + ")",
                transformOrigin: "50% 50% -" + d[0] + "px"
            });
            r.hide();
            q = new f(h, d[0], d[1], d[2], d[3], d[4], d[5], d[6],
            function() {
                r.css({
                    left: -k + "00%"
                }).show();
                h.remove();
                q = 0
            })
        } else {
            var g = t("<div></div>").css({
                position: "absolute",
                display: "none",
                zIndex: 2,
                width: "100%",
                height: "100%"
            }).appendTo(v);
            g.stop(1, 1);
            var e = ( !! ((k - c + 1) % p.length) ^ l.revers ? "left": "right");
            var j = t(p[c]).clone().css({
                position: "absolute",
                left: "0%",
                right: "auto",
                top: 0,
                width: "100%",
                height: "100%"
            }).appendTo(g).css(e, 0);
            var a = t(p[k]).clone().css({
                position: "absolute",
                left: "100%",
                right: "auto",
                top: 0,
                width: "0%",
                height: "100%"
            }).appendTo(g).show();
            g.css({
                left: "auto",
                right: "auto",
                top: 0
            }).css(e, 0).show();
            r.hide();
            a.animate({
                width: "100%",
                left: 0
            },
            l.duration, "easeInOutExpo",
            function() {
                t(this).remove()
            });
            j.animate({
                width: 0
            },
            l.duration, "easeInOutExpo",
            function() {
                r.css({
                    left: -k + "00%"
                }).show();
                g.remove()
            })
        }
        return k
    }
}
jQuery("#wowslider-container1").wowSlider({
    effect: "cube",
    prev: "",
    next: "",
    duration: 20 * 100,
    delay: 20 * 100,
    width: 716,
    height: 297,
    autoPlay: true,
    playPause: true,
    stopOnHover: false,
    loop: false,
    bullets: 0,
    caption: true,
    captionEffect: "slide",
    controls: true,
    onBeforeStep: 0,
    images: 0
});
