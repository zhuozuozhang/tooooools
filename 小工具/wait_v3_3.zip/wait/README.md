#关于wait主题
WordPress主题wait开源代码
##介绍
喜欢折腾，不喜欢拿来主义，所以在闲暇时间开发了这么一款主题，喜欢就拿去用，但请保留链接~~
##反馈
欢迎大家提出宝贵的建议和意见，大家可以去<a href='http://www.waitig.com'>我的网站（waitig.com）</a>留言，我会在第一时间处理，谢谢大家的支持~~

#更新日志
请到<a href="http://www.waitig.com/wait_theme_update_note_and_feedback.html">【wait主题更新日志和反馈专栏】</a>查看更新日志和提出反馈建议
