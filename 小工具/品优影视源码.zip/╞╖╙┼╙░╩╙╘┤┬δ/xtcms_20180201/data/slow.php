<?php
$html=file_get_contents('http://www.360kan.com');

$slowstr="/<a href='(.*?)' class='(.*?)'><img src='(.*?)' alt='(.*?)' \/><span class='title'>(.*?)<\/span><span class='desc'>(.*?)<\/span><b><\/b><\/a>/";
preg_match_all($slowstr, $html,$slowstrs);

$urls = $slowstrs[1];
$pics = $slowstrs[3];
$names = $slowstrs[4];
$dess = $slowstrs[6];

foreach ($urls as $k=> $l) {
	if (strpos($l, '/m/') > 0 OR strpos($l, '/tv/') > 0 OR strpos($l, '/va/') > 0 OR strpos($l, '/ct/') > 0) {
		$url[$k] = str_replace('https://www.360kan.com', '', $l);
		$ks[] = $k;
	}
}

foreach ($ks as $kk) {
	$data[$kk]['name'] = $names[$kk];
	$data[$kk]['dess'] = $dess[$kk];
	$data[$kk]['pics'] = $pics[$kk];

	$urlss = str_replace('https%3A%2F%2Fwww.360kan.com', '', urlencode($urls[$kk]));
	$urlss = str_replace('http%3A%2F%2Fwww.360kan.com', '', $urlss);

	$data[$kk]['urls'] = '/play.php?play='.$urlss;
}


