<?php
error_reporting(0); 
header('Content-type:text/html;charset=utf-8'); 
include './inc/config.php'; 
$page=$_GET['page']; 
$page1=$_GET['page']+=1; 
$page2=$_GET['page']-1; 
$pageurl = $host.'/tv.php?page='.$page1; 
$pageurl1 = $host.'/tv.php?page='.$page2; 
$info=file_get_contents('http://www.360kan.com/dianshi/list?rank=rankhot&cat=all&area=all&act=all&year=all&pageno=1'); 
define('360', 'www.360kan.com');
$vname='#<span class="s1">(.*?)</span>#';$vlist='#<a class="js-tongjic" href="(.*?)">#';
$vvlist='#<div class="s-tab-main">[\s\S]+?<div monitor-desc#';
$vstar='# <p class="star">(.*?)</p>#';$nname='#<span class="hint">(.*?)</span>#';
$vvlist='#<div class="s-tab-main">[\s\S]+?<div monitor-desc#';
$vimg='#<img src="(.*?)">#'; 
$bflist='#<a data-daochu(.*?) href="(.*?)" class="js-site-btn btn btn-play"></a>#';
$array = array(); preg_match_all($vname, $info,$namearr); preg_match_all($vlist, $info,$listarr); preg_match_all($vstar, $info,$stararr); 
preg_match_all($vvlist, $info,$imglist);
$zcf=implode($glue, $imglist[0]);
preg_match_all($vimg, $zcf,$imgarr);  preg_match_all($nname, $info,$nnamearr); foreach ($namearr[1] as $key => $value) { $gul=$listarr[1][$key]; $cd=$host.'/alist.php?id='.$gul; $guq=$listarr[1][$key]; $_GET['id']=$gul; $zimg=$imgarr[1][$key]; $zname=$namearr[1][$key]; $nname=$nnamearr[1][$key]; $zstar=$stararr[1][$key]; $jiami=base64_encode($gul); $chuandi=$host.'/inc/b.php?id='.$jiami; }?>