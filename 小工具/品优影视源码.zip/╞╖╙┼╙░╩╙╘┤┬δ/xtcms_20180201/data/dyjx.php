<?php
error_reporting(0); 
header('Content-type:text/html;charset=utf-8'); 
$page=$_GET['page']; 
$page1=$_GET['page']+=1; 
$page2=$_GET['page']-1; 
$pageurl = $host.'/?page='.$page1; $pageurl1 = $host.'/?page='.$page2; 
$info=file_get_contents('http://www.360kan.com/dianying/list.php?rank=rankhot&cat=all&area=all&act=all&year=all&pageno='.$page1); 
define('360', 'www.360kan.com');
$vname='#<span class="s1">(.*?)</span>#';
$fname='#<span class="s2">(.*?)</span>#';
$nname='#<span class="hint">(.*?)</span>#';
$vlist='#<a class="js-tongjic" href="(.*?)">#';
$vstar='# <p class="star">(.*?)</p>#';
$vvlist='#<div class="s-tab-main">[\s\S]+?<div monitor-desc#';
$vimg='#<img src="(.*?)">#'; 
$bflist='#<a data-daochu(.*?) href="(.*?)" class="js-site-btn btn btn-play"></a>#'; $array = array(); 
preg_match_all($vname, $info,$namearr); 
preg_match_all($vlist, $info,$listarr); 
preg_match_all($vstar, $info,$stararr); 
preg_match_all($vvlist, $info,$imglist);
$zcf=implode($glue, $imglist[0]);
preg_match_all($vimg, $zcf,$imgarr); 
preg_match_all($fname, $info,$fnamearr); 
preg_match_all($nname, $info,$nnamearr); 
foreach ($namearr[1] as $key => $value) 
{$gul=$listarr[1][$key]; 
$guq=$listarr[1][$key]; 
$_GET['id']=$gul; 
$zimg=$imgarr[1][$key]; 
$zname=$namearr[1][$key]; 
$fname=$fnamearr[1][$key]; 
$nname=$nnamearr[1][$key]; 
$zstar=$stararr[1][$key]; 
$jiami=base64_encode($gul);

 
 }?>