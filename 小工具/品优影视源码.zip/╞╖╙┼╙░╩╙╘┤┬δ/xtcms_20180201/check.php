<?php
if($xtcms_user==1){
	
	if(!isset($_SESSION['user_name'])){
		alert_href('请注册会员登录后观看',''.$xtcms_domain.'login.php');
	};
};
?>