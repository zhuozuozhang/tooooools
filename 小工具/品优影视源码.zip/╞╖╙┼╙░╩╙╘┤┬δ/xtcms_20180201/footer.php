<div class="hy-gototop hidden-sm hidden-xs">
   <ul class="item clearfix">
    <li><a href="<?php echo $xtcms_domain;?>login.php" title="会员中心"><i class="icon iconfont icon-member1"></i></a></li>
    <li><a href="<?php echo $xtcms_domain;?>#" title="留言求片"><i class="icon iconfont icon-comment"></i></a></li>
	<li><a href="<?php echo $xtcms_domain;?>#" title="电影下载"><i class="icon iconfont icon-record1"></i></a>
    <li class="codehover"><a href="javascript:()" title="二维码"><i class="icon iconfont icon-code1"></i></a>
     <div class="code clearfix">
      <p class="margin-0">
	  <img class="pic-responsive" src="<?php echo $xtcms_weixin;?>" alt="扫描二维码">
	  </p>
     </div></li>
    <li><a data-toggle="tooltip" data-placement="top" class="" href="javascript:scroll(0,0)" title="返回顶部"><i class="icon iconfont icon-uparrow"></i></a></li>   </ul>
  </div>
<div class="tabbar visible-xs">
		<a href="<?php echo $xtcms_domain;?>" class="item ">
        <i class="icon iconfont icon-home"></i>
        <p class="text">首页</p>
    </a>
	<a href="<?php echo $xtcms_domain;?>movie.php?m=/dianying/list.php?cat=all%26pageno=1" class="item ">
        <i class="icon iconfont icon-film"></i>
        <p class="text">电影</p>
    </a><a href="<?php echo $xtcms_domain;?>tv.php?u=/dianshi/list.php?cat=all%26pageno=1" class="item ">
        <i class="icon iconfont icon-show"></i>
        <p class="text">电视剧</p>
    </a><a href="<?php echo $xtcms_domain;?>dongman.php?m=/dongman/list.php?cat=all%26pageno=1" class="item ">
        <i class="icon iconfont icon-mallanimation"></i>
        <p class="text">动漫</p>
    </a><a href="<?php echo $xtcms_domain;?>zongyi.php?m=/zongyi/list.php?cat=all%26pageno=1" class="item ">
        <i class="icon iconfont icon-flag"></i>
        <p class="text">综艺</p>
    </a>    </div>
<div class="container">
<div class="row"  style="margin-top:10px"><?php echo get_ad(2)?></div>
	<div class="row">
		<div class="hy-footer clearfix">
        <p style="padding: 0 4px;text-align:center" class="container-fluid"><?php echo $xtcms_copyright;?></p>
		</div>
	</div>
</div>
	
</body>
</html>
