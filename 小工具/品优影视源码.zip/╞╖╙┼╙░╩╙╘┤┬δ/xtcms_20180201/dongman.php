<?php include('system/inc.php');?>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta http-equiv="cache-control" content="no-siteapp">
<title>动漫列表-<?php echo $xtcms_seoname;?></title>
<link rel="stylesheet" href="<?php echo $xtcms_domain;?>style/css/bootstrap.min.css" />
<link href="<?php echo $xtcms_domain;?>style/css/swiper.min.css" rel="stylesheet" type="text/css" >		
<link href="<?php echo $xtcms_domain;?>style/font/iconfont.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $xtcms_domain;?>style/css/blackcolor.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $xtcms_domain;?>style/css/style.min.css" rel="stylesheet" type="text/css" />
<script type='text/javascript' src="<?php echo $xtcms_domain;?>style/js/swiper.min.js"></script>
<meta name="keywords" content="动漫排行,<?php echo $xtcms_keywords;?>">
<meta name="description" content="<?php echo $xtcms_description;?>">
<!--[if lt IE 9]><script src="js/html5.js"></script><![endif]-->
</head>
<body class="vod-type apptop">
<?php include 'header.php'; ?>
<div class="container">
	<div class="row">
<div class="hy-cascade clearfix">
			<div class="left-head hidden-sm hidden-xs">
				<ul class="clearfix">
					<li class="text"><span class="text-muted">当前频道</span></li>
					<li><a href="./dongman.php?m=/dongman/list.php?cat=all%26pageno=1"  class="active">动漫</a></li></ul>
			</div>
			<div class="content-meun clearfix">
				<a class="head" href="javascript:;" data-toggle="collapse" data-target="#collapse">
				<span class="text">动漫分类</span></a>
				<div class="item collapse in" id="collapse">
					<ul class="visible-sm visible-xs clearfix">
						<li class="text"><span class="text-muted">按频道</span></li>
					<li><a href="./dongman.php?m=/dongman/list.php?cat=all&pageno=1" id="idc4ca4238a0b923820dcc509a6f75849b">动漫</a></li>					</ul>
					
					<ul class="clearfix">
											  <li><a href="?m=/dongman/list.php?cat=all&pageno=1" class="acat" style="white-space: pre-wrap;">全部</a></li>
											  <?php
include 'list.php'; 
$page=$_GET['page']; 
foreach ($dmcat as $kcat=>$vcat){ 
$flname= $dmname[$kcat]; 
$flid="?m=/dongman/list.php?cat=".$vcat.'&pageno=1'; 
echo "<li><a href='$flid' class='acat' style='white-space: pre-wrap;margin-bottom: 4px;'>$flname</a></li>"; } 
$fenge=$_GET['m']; ?>

						</ul>
				</div>
			</div>
		</div>
        		<div class="hy-layout clearfix">
<?php echo get_ad(1)?>
		</div>

		<div class="hy-layout clearfix" style="margin-top: 0;">
			<div class="hy-switch-tabs active clearfix">
				<span class="text-muted pull-right hidden-xs">如果您喜欢本站请动动小手分享给您的朋友！</span>
				<ul class="nav nav-tabs">
					<li class="active"><a href="#">最新动漫</a></li>
				</ul>
			</div>
			<div class="hy-video-list">
				<div class="item">
					<ul class="clearfix">
 <?php
$flid1=$_GET['m'];
$arr=explode('pageno',$flid1);
$yourneed=$arr[0];
$yema=$yourneed;
$arr=explode('pageno',$yema);
$yemama=$arr[0];
$mama='&pageno=';
$wangzhi="http://www.360kan.com"; 
$flid2=''.$wangzhi.$yemama.$mama.$page.'';
$rurl=file_get_contents($flid2); 
$vname='#<span class="s1">(.*?)</span>#';
$fname='#<span class="s2">(.*?)</span>#';
$vlist='#<a class="js-tongjic" href="(.*?)">#';
$vstar='# <p class="star">(.*?)</p>#';
$vvlist='#<div class="s-tab-main">[\s\S]+?<div monitor-desc#';
$vimg='#<img src="(.*?)">#'; 
$bflist='#<a data-daochu(.*?) href="(.*?)" class="js-site-btn btn btn-play"></a>#';
$jishu='#<span class="hint">(.*?)</span> #'; 
$fufei='#<span class="pay">(.*?)</span>#'; 
$yuming='http://www.360kan.com'; 
preg_match_all($vname, $rurl,$xarr); 
preg_match_all($fname, $rurl,$xarrf); 
preg_match_all($vlist, $rurl,$xarr1); 
preg_match_all($vstar, $rurl,$xarr2); 
preg_match_all($vvlist, $rurl,$imglist);
$zcf=implode($glue, $imglist[0]);
preg_match_all($vimg, $zcf,$xarr3); 
preg_match_all($bflist, $rurl,$xarr4); 
preg_match_all($jishu, $rurl,$xarr5); 
preg_match_all($fufei, $rurl,$xarrff); 
$xname=$xarr[1];$lname=$xarrf[1];
$xlist=$xarr1[1];$xstar=$xarr2[1];
$ximg=$xarr3[1];$xbflist=$xarr4[1];
$xjishu=$xarr5[1];
$xfufei=$xarrff[1]; 
foreach ($xname as $key=>$xvau){ $do=$xlist[$key]; 
$do1=$do; 
$cc="./play.php?play="; 
if ($xtcms_wei==1){
$ccb=vod.$do1;
}
else{
$ccb=$cc.$do1;	
}

			echo '<div class="col-md-2 col-sm-3 col-xs-4">
							<a class="videopic lazy" href="'.$ccb.'" title="'.$xvau.'" src="'.$ximg[$key].'" style="background: url('.$ximg[$key].') no-repeat; background-position:50% 50%; background-size: cover;"><span class="play hidden-xs"></span><span class="score">'.$xjishu[$key].'</span></a>
							<div class="title">
								<h5 class="text-overflow"><a href="'.$ccb.'">'.$xvau.'</a></h5>
							</div>
							<div class="subtitle text-muted text-muted text-overflow hidden-xs">'.$xstar[$key].'</div>
						</div>';
						
 } ?>

						</ul>
				</div>
			</div>
			<div class="hy-page clearfix">
				<ul class="cleafix">
<?php 
$b=(strpos($flid2,'cat='));
$c=(strpos($flid2,'&p'));
$ye=substr($flid2,$b+4,$b-$c-1);
if($ye==133){$fenye=('11');}
elseif($ye==101){$fenye=('23');}
elseif($ye==102){$fenye=('22');}
elseif($ye==124||$ye==103){$fenye=('5');}
elseif($ye==116||$ye==108){$fenye=('9');}
elseif($ye==110){$fenye=('12');}
elseif($ye==112){$fenye=('15');}
elseif($ye==132||$ye==122||$ye==118||$ye==117||$ye==113){$fenye=('4');}
elseif($ye==127||$ye==119||$ye==115){$fenye=('10');}
elseif($ye==125||$ye==120){$fenye=('2');}
elseif($ye==121){$fenye=('16');}
elseif($ye==123){$fenye=('14');}
elseif($ye==126){$fenye=('13');}
elseif($ye==130||$ye==129||$ye==128){$fenye=('3');}
else{$fenye=('24');}?>
<?php echo getPageHtml($page,$fenye,'dongman.php?m='.$yourneed.'pageno=');?><li><a>共<?php echo $fenye;?>页</a></li></ul>
			</div>		</div>
	</div>
</div>



<?php  include 'footer.php';?>
<?php  ?>