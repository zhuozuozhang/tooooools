<?php  include('../system/inc.php');
include('cms_check.php');
if(isset($_POST['save']))
{
	null_back($_POST['d_name'],'请填写视频名称');
	$_data['d_name']=$_POST['d_name'];
	$_data['d_zhuyan']=$_POST['d_zhuyan'];
	$_data['d_picture']=$_POST['d_picture'];
	$_data['d_parent']=$_POST['d_parent'];
	$_data['d_rec']=$_POST['d_rec'];
	$_data['d_hot']=$_POST['d_hot'];
	$_data['d_content']=$_POST['d_content'];
	$_data['d_scontent']=$_POST['d_scontent'];
	$_data['d_jifen']=$_POST['d_jifen'];
	$_data['d_keywords']=$_POST['d_keywords'];
	$_data['d_description']=$_POST['d_description'];
	$_data['d_seoname']=$_POST['d_seoname'];
	$_data['d_user']=$_POST['d_user'];
	$sql="update xtcms_vod set ".arrtoupdate($_data)." where d_id = ".$_GET['id'].";";
		if(mysql_query($sql))
	{
		alert_href('视频修改成功!','cms_detail.php?cid=0');
	}
	else
	{
		alert_back('修改失败!');
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

	<?include("inc_head.php");?>
	<script type="text/javascript">
KindEditor.ready(function(K) {
	K.create('#d_content');
	var editor = K.editor();
	K('#picture').click(function() {
		editor.loadPlugin('image', function() {
			editor.plugin.imageDialog({
			imageUrl : K('#d_picture').val(),
			clickFn : function(url, title, width, height, border, align) {
				K('#d_picture').val(url);
				editor.hideDialog();
				}
			});
		});
	});
	K('#slideshow').click(function() {
		editor.loadPlugin('multiimage', function() {
			editor.plugin.multiImageDialog({
				clickFn : function(urlList) {
					var tem_val = '';
					var tem_s = '';
					K.each(urlList, function(i, data) {
						tem_val = tem_val + tem_s + data.url;
						tem_s = '|';
					});
					K('#d_slideshow').val(tem_val);
					editor.hideDialog();
				}
			});
		});
	});
	K('#file').click(function() {
		editor.loadPlugin('insertfile', function() {
			editor.plugin.fileDialog({
				fileUrl : K('#d_file').val(),
				clickFn : function(url, title) {
					K('#d_file').val(url);
					editor.hideDialog();
				}
			});
		});
	});
});
</script>
</head>
<body>
<?include('inc_header.php');?>
<div id="content">
<div class="container">
<div class="line-big">

<? include('inc_left.php');?>
<div class="xx105">
<div class="hd-1">修改视频</div>
<div class="bd-1">

<? $result=mysql_query('select * from xtcms_vod where d_id = '.$_GET['id'].';');
if($row=mysql_fetch_array($result))
{
	?>
<form method="post">
<div class="line-big">
<div class="form-group x6">
<div class="label"><label for="d_name">视频名称 <span class="badge bg-dot">必填</span></label></div>
<div class="field">
<input id="d_name" class="input" name="d_name" type="text" size="60" data-validate="required:请输入视频名称" value="<? echo $row['d_name'];?>" />
<div class="input-note">请输入视频名称</div>
</div>
</div>
<div class="form-group x6 form-auto">
<div class="label"><label for="d_picture">图片</label></div>
<div class="field">
<input id="d_picture" class="input" name="d_picture" type="text" size="60" value="<?echo $row['d_picture'];?>" />
<span class="btn bg-dot" id="picture">上传</span>
<div class="input-note">图片列表显示的缩略图</div>
</div>
</div>
<div class="fc"></div>
<div class="form-group x12">
<div class="label"><label for="d_scontent">主演</label></div>
<div class="field">
<input id="d_zhuyan" class="input" name="d_zhuyan" type="text" size="60" data-validate="required:请输入主演" value="<?echo $row['d_zhuyan'];?>" />
<div class="input-note">主演</div>
</div>
</div>
<div class="fc"></div>
<div class="form-group x6">
<div class="label"><label for="d_name">点播所需积分</label></div>
<div class="field">
<input id="d_jifen" class="input" name="d_jifen" type="text" size="60"  value="<?echo $row['d_jifen'];?>" />
<div class="input-note">请输入积分</div>
</div>
</div>
<div class="form-group x6 form-auto">
<div class="label"><label for="d_user">可看会员组</label></div>
<div class="field">
<select id="d_user" class="input" name="d_user">
<option value="0" <?echo($row['d_user']==0?'selected="selected"':'');?>>全部</option>
<?php
$result=mysql_query('select * from xtcms_user_group');
	while($row1=mysql_fetch_array($result))
	{
		?>
						<option value="<?php echo $row1['ug_id']?>" <?php echo($row['d_user']==$row1['ug_id']?'selected="selected"':'');
		?>><?php echo $row1['ug_name']?></option>
<?php
}
	?>
</select>
<div class="input-note">请选择会员组</div>
</div>
</div>
<div class="fc"></div>
<div class="form-group x6">
<div class="label"><label for="d_parent">所属类别 <span class="badge bg-dot">必选</span></label></div>
<div class="field">
<select id="d_parent" class="input" name="d_parent">
	echo channel_select_list(0,0,$row['d_parent'],0);
	?>
</select>
<div class="input-note">请选择详情属于哪个类别</div>
</div>
</div>
<div class="form-group x3">
<div class="label"><label for="d_rec">推荐</label></div>
<div class="field">
<label class="btn"><input id="d_rec" name="d_rec" type="radio" value="0" <?echo($row['d_rec']==0?'checked="checked"' :'')?>/>否</label>
<label class="btn"><input name="d_rec" type="radio" value="1" <?echo($row['d_rec']==1?'checked="checked"' :'')?>/>是</label>
<div class="input-note">选择是否推荐</div>
</div>
</div>
<div class="form-group x3">
<div class="label"><label for="d_hot">热门</label></div>
<div class="field">
<label class="btn"><input id="d_hot" name="d_hot" type="radio" value="0" <?	echo($row['d_hot']==0?'checked="checked"' :'')?>/>否</label>
<label class="btn"><input name="d_hot" type="radio" value="1" <?	echo($row['d_hot']==1?'checked="checked"' :'')?>/>是</label>
<div class="input-note">选择是否热门</div>
</div>
</div>
<div class="fc"></div>
<div class="form-group x12">
<div class="label"><label for="d_scontent">视频地址</label></div>
<div class="field">
<textarea id="d_scontent" class="input" name="d_scontent" row="5" /><?	echo $row['d_scontent'];?></textarea>
<div class="input-note">名称|地址</div>
</div>
</div>
<div class="fc"></div>
<div class="form-group x12">
<div class="label"><label for="d_content">详细内容</label></div>
<div class="field">
<textarea id="d_content" class="input" name="d_content" /><?	echo htmlspecialchars($row['d_content']);?></textarea>
<div class="input-note">支持图文混排等</div>
</div>
</div>
<div class="fc"></div>
<div class="form-group x4">
<div class="label"><label for="d_keywords">关键字</label></div>
<div class="field">
<input id="d_keywords" class="input" name="d_keywords" type="text" size="60" placeholder="请输入关键字" value="<?	echo $row['d_keywords'];	?>" />
<div class="input-note">请输入关键字</div>
</div>
</div>
<div class="form-group x4">
<div class="label"><label for="d_description">关键描述</label></div>
<div class="field">
<input id="d_description" class="input" name="d_description" type="text" size="60" value="<?	echo $row['d_description'];	?>" />
<div class="input-note">请输入关键描述</div>
</div>
</div>
<div class="form-group x4">
<div class="label"><label for="d_seoname">优化标题</label></div>
<div class="field">
<input id="d_seoname" class="input" name="d_seoname" type="text" size="60" value="<?	echo $row['d_seoname'];	?>" />
<div class="input-note">请输入优化标题</div>
</div>
</div>
<div class="fc"></div>
<div class="form-group x12">
<div class="label"><label></label></div>
<div class="field">
<input id="save" class="btn bg-dot btn-block" name="save" type="submit" value="保存" />
</div>
</div>
</div>
</form>
<?}?>
</div>
</div>
</div>
</div></div>
<?include('inc_footer.php');?>
</body>
</html>