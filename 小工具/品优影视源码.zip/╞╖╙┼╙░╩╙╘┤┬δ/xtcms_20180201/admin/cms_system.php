<?php

include("../system/inc.php");
include("cms_check.php");
if(isset($_POST['save'])){
	$_data['s_domain']=$_POST['s_domain'];
	$_data['s_name']=$_POST['s_name'];
	$_data['s_seoname']=$_POST['s_seoname'];
	$_data['s_keywords']=$_POST['s_keywords'];
	$_data['s_description']=$_POST['s_description'];
	$_data['s_copyright']=$_POST['s_copyright'];
	$_data['s_cache']=$_POST['s_cache'];
	$_data['s_wei']=$_POST['s_wei'];
	$_data['s_user']=$_POST['s_user'];
	$_data['s_slow']=$_POST['s_slow'];
	$_data['s_logo']=$_POST['s_logo'];
	$_data['s_weixin']=$_POST['s_weixin'];
	$_data['s_dashang']=$_POST['s_dashang'];
	$_data['s_mjk']=$_POST['s_mjk'];
	$_data['s_jiekou']=$_POST['s_jiekou'];
	$_data['s_changyan']=$_POST['s_changyan'];
	$_data['s_qqun']=$_POST['s_qqun'];
	$sql="update xtcms_system set".arrtoupdate($_data)."where id = 1 ;";
	if(mysql_query($sql)){
		alert_href("系统设置修改成功!","cms_system.php");
	}else{
		alert_back("修改失败!");
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<?include("inc_head.php");?>
<script type="text/javascript">
KindEditor.ready(function(K) {
	K.create('#s_copyright');
	var editor = K.editor();
	K('#picture').click(function() {
		editor.loadPlugin('image', function() {
			editor.plugin.imageDialog({
			imageUrl : K('#s_logo').val(),
			clickFn : function(url, title, width, height, border, align) {
				K('#s_logo').val(url);
				editor.hideDialog();
				}
			});
		});
	});
	K('#weixin').click(function() {
		editor.loadPlugin('image', function() {
			editor.plugin.imageDialog({
			imageUrl : K('#s_weixin').val(),
			clickFn : function(url, title, width, height, border, align) {
				K('#s_weixin').val(url);
				editor.hideDialog();
				}
			});
		});
	});
	K('#dashang').click(function() {
		editor.loadPlugin('image', function() {
			editor.plugin.imageDialog({
			imageUrl : K('#s_dashang').val(),
			clickFn : function(url, title, width, height, border, align) {
				K('#s_dashang').val(url);
				editor.hideDialog();
				}
			});
		});
	});
});
</script>

</head>
<body>

<?include("inc_header.php");?>
<div id="content">
	<div class="container">
		<div class="line-big">
		<?include("inc_left.php");?>
			<div class="xx105">
				<div class="hd-1">系统设置</div>
				<div class="bd-1">

<? $result=mysql_query("select * from xtcms_system where id = 1");
if($row=mysql_fetch_array($result)){?>
					<form method="post">
						<div class="line-big">
							<div class="x6">
								<div class="form-group">
									<div class="label"><label for="s_name">网站名称</label></div>
									<div class="field">
										<input id="s_name" class="input" name="s_name" type="text" size="60" value="<? echo $row['s_name'];?>" />
										<div class="input-note">请填写网站名称</div>
									</div>
								</div>
							</div>
							<div class="x6">
								<div class="form-group">
									<div class="label"><label for="s_domain">域名</label></div>
									<div class="field">
										<input id="s_domain" class="input" name="s_domain" type="text" size="60" value="<? echo $row['s_domain'];?>" />
										<div class="input-note">请填写域名</div>
									</div>
								</div>
							</div>
							<div class="fc"></div>
							<div class="x4">
								<div class="form-group">
									<div class="label"><label for="s_seoname">优化标题</label></div>
									<div class="field">
										<input id="s_seoname" class="input" name="s_seoname" type="text" size="60" value="<? echo $row['s_seoname'];?>" />
										<div class="input-note">请填写优化标题</div>
									</div>
								</div>
							</div>
							<div class="x4">
								<div class="form-group">
									<div class="label"><label for="s_keywords">关键字</label></div>
									<div class="field">
										<input id="s_keywords" class="input" name="s_keywords" type="text" size="60" value="<? echo $row['s_keywords'];?>" />
										<div class="input-note">请填写关键字</div>
									</div>
								</div>
							</div>
							<div class="x4">
								<div class="form-group">
									<div class="label"><label for="s_description">关键描述</label></div>
									<div class="field">
										<input id="s_description" class="input" name="s_description" type="text" size="60" value="<? echo $row['s_description'];?>" />
										<div class="input-note">请填写关键描述</div>
									</div>
								</div>
							</div>
							<div class="fc"></div><div class="x4">
								<div class="form-group">
									<div class="label"><label for="s_seoname">是否开启缓存</label></div>
									<div class="field">
										<input type="radio" name="s_cache" value="0" <? echo($row['s_cache']==0)?'checked="checked"' :' ';?> />关闭&nbsp;
										<input type="radio" name="s_cache" value="1" <? echo($row['s_cache']==1)?'checked="checked"' :' ';?> />开启&nbsp;
			<div class="input-note">开启后加开网站访问速度，但会占用服务器空间</div>
									</div>
								</div>
							</div>
							<div class="x4">
								<div class="form-group">
									<div class="label"><label for="s_keywords">是否开启伪静态</label></div>
									<div class="field">
					<input type="radio" name="s_wei" value="0" <? echo($row['s_wei']==0)?'checked="checked"' :'';?>/>关闭&nbsp;
					<input type="radio" name="s_wei" value="1" <? echo($row['s_wei']==1)?'checked="checked"' :'';?> />开启&nbsp;
									</div>
								</div>
							</div>
							<div class="x4">
								<div class="form-group">
									<div class="label"><label for="s_description">是否开启会员观看</label></div>
									<div class="field">
									<input type="radio" name="s_user" value="0" <? echo($row['s_user']==0)?'checked="checked"' :'';?> />关闭&nbsp;
									<input type="radio" name="s_user" value="1" <? echo($row['s_user']==1)?'checked="checked"' :'';?> />开启&nbsp;
									<div class="input-note">开启后全网视频都需要注册会员观看</div>
									</div>
								</div>
							</div>
							<div class="fc"></div>
							
														<div class="x4">
								<div class="form-group form-auto">
									<div class="label"><label for="s_seoname">网站logo</label></div>
									<div class="field">
										<input id="s_logo" class="input" name="s_logo" type="text" size="40" value="<? echo $row['s_logo'];?>" />
										<span class="btn bg-dot" id="picture">上传</span>
										
									</div>
								</div>
							</div>
							<div class="x4">
								<div class="form-group form-auto">
									<div class="label"><label for="s_keywords">微信公众号图片</label></div>
									<div class="field">
										<input id="s_weixin" class="input" name="s_weixin" type="text" size="40" value="<? echo $row['s_weixin'];?>" />
										<span class="btn bg-dot" id="weixin">上传</span>
										
									</div>
								</div>
							</div>
							<div class="x4">
								<div class="form-group form-auto">
									<div class="label"><label for="s_description">微信打赏图片</label></div>
									<div class="field">
										<input id="s_dashang" class="input" name="s_dashang" type="text" size="40" value="<? echo $row['s_dashang'];?>" />
										<span class="btn bg-dot" id="dashang">上传</span>
										
									</div>
								</div>
							</div>
							<div class="fc"></div>
														
							<div class="x8">
								<div class="form-group">
									<div class="label"><label for="s_hotkeywords">默认接口</label></div>
									<div class="field">
										<input id="s_mjk" class="input" name="s_mjk" type="text" size="60" value="<? echo $row['s_mjk'];?>" />
										<div class="input-note">自动播放时的接口</div>
									</div>
								</div>
							</div>
							<div class="x4">
								<div class="form-group">
									<div class="label"><label for="s_description">是否开启自动轮播图</label></div>
									<div class="field">
									<input type="radio" name="s_slow" value="0" <? echo($row['s_slow']==0)?'checked="checked"' :'';?> />关闭&nbsp;
									<input type="radio" name="s_slow" value="1" <? echo($row['s_slow']==1)?'checked="checked"' :'';?> />开启&nbsp;
									<div class="input-note">开启后自动采集轮播图</div>
									</div>
								</div>
							</div>
							<div class="fc"></div>
							<div class="x12">
								<div class="form-group">
									<div class="label"><label for="s_hotkeywords">解析接口</label></div>
									<div class="field">
										<textarea class="input" name="s_jiekou" /><? echo $row['s_jiekou'];?></textarea>
										<div class="input-note">多个解析请用“##”分开，如：http://www.q.com/jk.php?url=##</div>
									</div>
								</div>
							</div>
							<div class="fc"></div>
							<div class="x12">
								<div class="form-group">
									<div class="label"><label for="s_copyright">版权信息</label></div>
									<div class="field">
										<textarea id="s_copyright" class="input" name="s_copyright" /><? echo htmlspecialchars($row['s_copyright']);?> </textarea>
										<div class="input-note">请填写版权信息</div>
									</div>
								</div>
							</div>
														<div class="fc"></div>
							<div class="x12">
								<div class="form-group">
									<div class="label"><label for="s_feedback">卡密购买链接</label></div>
									<div class="field">
<textarea  class="input" name="s_qqun" size="60"/><? echo $row['s_qqun'];?></textarea>
<div class="input-note">填写qq群代码</div>
									</div>
								</div>
							</div>
							<div class="fc"></div>
							<div class="x12">
								<div class="form-group">
									<div class="label"><label for="s_feedback">畅言代码</label></div>
									<div class="field">
<textarea  class="input" name="s_changyan" size="60"/><? echo $row['s_changyan'];?></textarea>
<div class="input-note">填写代码即可开启评论</div>
									</div>
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label></label></div>
							<div class="field">
								<input id="save" class="btn bg-dot btn-block" name="save" type="submit" value="保存" />
							</div>
						</div>
					</form>

<?}?>
				</div>

			</div>
		</div>
	</div>
</div>

<? include("inc_footer.php");?>
</body>
</html>