<div class="xx15 pt10">
	<div class="hd-2">系统设置</div>
	<div class="bd-2">
		<a class="btn btn-block bg-black" href="cms_system.php">基本设置</a>
		<a class="btn btn-block bg-black" href="cms_admin.php">管理员</a>
		<a class="btn btn-block bg-black" href="cms_pay.php">支付配置</a>
		<a class="btn btn-block bg-black" href="cms_ad.php">广告管理</a>
		<a class="btn btn-block bg-black" href="cms_slideshow.php">幻灯管理</a>
		<a class="btn btn-block bg-black" href="cms_nav.php">导航管理</a>
		<a class="btn btn-block bg-black" href="cms_weixin.php">微信对接</a>
	</div>
	<div class="hd-2">视频管理</div>
	<div class="bd-2">
		<a class="btn btn-block bg-black" href="cms_detail_add.php?cid=0">添加视频</a>
		<a class="btn btn-block bg-black" href="cms_detail.php?cid=0">管理视频</a>
		<a class="btn btn-block bg-black" href="cms_channel_add.php">添加栏目</a>
		<a class="btn btn-block bg-black" href="cms_channel.php">管理栏目</a>
	</div>

	<dl>
	<div class="hd-2">会员管理</div>
	<div class="bd-2">
		<a class="btn btn-block bg-black" href="cms_user.php">会员管理</a>
		<a class="btn btn-block bg-black" href="cms_usergroup.php">会员组管理</a>
		<a class="btn btn-block bg-black" href="cms_kami.php">卡密管理</a>
		<a class="btn btn-block bg-black" href="cms_link.php">友情链接</a>
	</div>

	<dl>

</div>
