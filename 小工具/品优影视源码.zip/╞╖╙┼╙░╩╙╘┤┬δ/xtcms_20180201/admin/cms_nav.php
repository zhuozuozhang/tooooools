<?php

include("../system/inc.php");
include("cms_check.php");
if(isset($_POST['save'])){
	null_back($_POST['n_name'],'请输入名称');
	non_numeric_back($_POST['order'],'请输入排序数字');
	$_data['n_name']=$_POST['n_name'];
	$_data['n_url']=$_POST['n_url'];
	$_data['order']=$_POST['order'];
	$str=arrtoinsert($_data);
	$sql="insert into xtcms_nav (".$str[0].") values (".$str[1].");";
	if(mysql_query($sql)){
		$order=mysql_insert_id();
		if($_POST['order']==0){
			mysql_query("update xtcms_nav set order =".$order."where id = ".$order);
		}
		alert_href('导航添加成功!','cms_nav.php');
	}else{
		alert_back('添加失败!');
	}
}
if(isset($_GET['del'])){
	$sql="delete from xtcms_nav where id = ".$_GET['del'].";";
	if(mysql_query($sql)){
		alert_href('删除成功!','cms_nav.php');
	}else{
		alert_back('删除失败！');
	}
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?include("inc_head.php");?>
 <script type="text/javascript">
KindEditor.ready(function(K) {
	var editor = K.editor();
	K('#picture').click(function() {
		editor.loadPlugin('image', function() {
			editor.plugin.imageDialog({
			imageUrl : K('#s_picture').val(),
			clickFn : function(url, title, width, height, border, align) {
				K('#s_picture').val(url);
				editor.hideDialog();
				}
			});
		});
	});
});
</script>
</head>
<body>
<?include("inc_header.php");?>
 <div id="content">
	<div class="container">
		<div class="line-big">
		<?include("inc_left.php");?>
 			<div class="xx105">
				<div class="hd-1">添加导航</div>
				<div class="bd-1">
					<form method="post">
						<div class="form-group">
							<div class="label"><label for="s_name">名称</label></div>
							<div class="field">
								<input id="n_name" class="input" name="n_name" type="text" size="60" value="" />
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label for="s_url">链接</label></div>
							<div class="field">
								<input id="n_url" class="input" name="n_url" type="text" size="60" value="http://" />
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label for="s_order">排序 <span class="badge bg-dot">必填</span></label></div>
							<div class="field">
								<input id="order" class="input" name="order" type="text" size="60" data-validate="required:必填,plusinteger:请输入排序数字" value="0" />
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label></label></div>
							<div class="field">
								<input id="save" class="btn bg-dot btn-block" name="save" type="submit" value="保存" />
							</div>
						</div>
					</form>
				</div>

				<div class="hd-1">导航管理</div>
				<div class="bd-1">
					<table class="table table-bordered">
						<tr>
							<th>排序</th>
							<th>名称</th>
							<th>地址</th>
							<th>操作</th>
						</tr>
						<? $result=mysql_query("select * from xtcms_nav;");
						while($row=mysql_fetch_array($result)){?>
						<tr>
							<td><?php echo $row['order'];?></td>
							<td><?php echo $row['n_name'];?></td>
							<td><?php echo $row['n_url'];?>
							</td>
							<td>
								<a class="btn bg-sub btn-small" href="cms_nav_edit.php?id=<? echo $row['id'];?>"><span class="icon-edit"> 修改</span></a> 
								<a class="btn bg-dot btn-small" href="cms_nav.php?del=<? echo $row['id'];?>" onclick="return confirm('确认要删除吗？')"><span class="icon-times"> 删除</span></a>
							</td>
						</tr>
						
						<?}?>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<?include("inc_footer.php");?>
</body>
</html>