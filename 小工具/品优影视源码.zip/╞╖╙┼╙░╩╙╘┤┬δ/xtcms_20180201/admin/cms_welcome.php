<?php
include('../system/inc.php');
include('cms_check.php');

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('inc_head.php') ?>
</head>
<body>
<?php include('inc_header.php') ?>
<div id="content">
	<div class="container">
		<div class="line-big">
			<?php include('inc_left.php') ?>
			<div class="xx105">
				<div class="hd-1">使用声明</div>
				<div class="bd-1">
				<p style="font-size:18px; line-height:30px">此程序版权所有筱瞳CMS www.hez70.com。请勿盗版。<br>
				1.本系统所有资源均自动采集，无需人工，省时省力。新版增加了发布视频功能、会员功能、充值功能、支付功能等。<br>
				2.影院自适应所有设备，PC/手机/pad均可使用。<br>
				3.本系统不依托任何第三方CMS，纯PHP，对环境要求小，基本所有的PHP环境都可轻松带起。<br>
				4.所有广告及版权信息均可从后台更改。<br>
				5.可对接微信（有教程及配置文件），可打包制作APP（苹果+安卓）。<br>
				您当前使用的是筱瞳CMS v1.01。
				</p>

				</div>
			</div>
		</div>
	</div>
</div>
<?php include('inc_footer.php') ?>
</body>
</html>