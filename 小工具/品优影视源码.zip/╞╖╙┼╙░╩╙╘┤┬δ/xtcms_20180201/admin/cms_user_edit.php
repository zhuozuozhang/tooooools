<?php

include("../system/inc.php");
include("cms_check.php");
if(isset($_POST['save'])){
	null_back($_POST['u_name'],'请填写登录帐号');
	null_back($_POST['u_password'],'请填写登录密码');
	$_data['u_name']=$_POST['u_name'];
	$_data['u_password']=md5($_POST['u_password']);
	$_data['u_email']=$_POST['u_email'];
	$_data['u_status']=$_POST['u_status'];
	$_data['u_group']=$_POST['u_group'];
	$_data['u_points']=$_POST['u_points'];
	$result=mysql_query("select * from xtcms_user where u_id = ".$_GET['id'].";");
	if($row=mysql_fetch_array($result)){
		if($_POST['u_password']!=$row['u_password']){
			$_data['u_password']=md5($_POST['u_password']);
		}else{
			$_data['u_password']=$_POST['u_password'];
		}
	}
	$sql="update xtcms_user set ".arrtoupdate($_data)." where u_id = ".$_GET['id'].";";
	if(mysql_query($sql)){
		alert_href('修改成功!','cms_user.php');
	}else{
		alert_back('修改失败!');
	}
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?include("inc_head.php");?>
</head>
<body>
<?include("inc_header.php");?>
<div id="content">
	<div class="container">
		<div class="line-big">
			<?include("inc_left.php");?>
			<div class="xx105">
				<div class="hd-1">修改会员</div>
				<div class="bd-1">
				<? $result=mysql_query("select * from xtcms_user where u_id = ".$_GET['id'].';');
				if($row=mysql_fetch_array($result)){?>
					<form method="post">
						<div class="line-big">
							<div class="form-group x6">
								<div class="label"><label for="d_name">名称 <span class="badge bg-dot">必填</span></label></div>
								<div class="field">
									<input id="u_name" class="input" name="u_name" type="text" size="60" data-validate="required:请输入名称" value="<? echo $row['u_name'];?>" />
									<div class="input-note">请输入名称</div>
								</div>
							</div>
							<div class="form-group x6">
								<div class="label"><label for="d_picture">密码</label></div>
								<div class="field">
									<input id="u_password" class="input" name="u_password" type="password" size="60" data-validate="required:请输入密码" value="<? echo $row['u_password'];?>" />
									<div class="input-note">请输入密码</div>
								</div>
							</div>
							<div class="fc"></div>
														<div class="form-group x6">
								<div class="label"><label for="d_name">状态</label></div>
								<div class="field">
								<select id="u_status" class="input" name="u_status">
									<option value="1" <? echo($row['u_status']==1?'selected="selected"':'');?>>启用</option>
									<option value="0" <? echo($row['u_status']==0?'selected="selected"':'');?>>禁用</option>
								</select>
								</div>
							</div>
							<div class="form-group x6 form-auto">
								<div class="label"><label for="d_user">会员组</label></div>
								<div class="field">
								<select id="u_group" class="input" name="u_group">
								<? $result=mysql_query('select * from xtcms_user_group;');
								while($row1=mysql_fetch_array($result)){?>
									<option value="<?php echo $row1['ug_id']?>" <?php echo($row['u_group']==$row1['ug_id']?'selected="selected"':'');?>><?php echo $row1['ug_name']?></option>
								<?}?>
									</select>
									<div class="input-note">请选择会员组</div>
		
								</div>
							</div>
							<div class="fc"></div>
							<div class="form-group x6">
								<div class="label"><label for="d_parent">积分</label></div>
								<div class="field">
								<input id="u_points" class="input" name="u_points" type="text" size="60"  value="<? echo $row['u_points'];?>" />
								<div class="input-note">请输入积分</div>
								</div>
							</div>
							<div class="form-group x6">
								<div class="label"><label for="d_rec">email</label></div>
								<div class="field">
								<input id="u_email" class="input" name="u_email" type="text" size="60"  value="<? echo $row['u_email'];?>" />
								<div class="input-note">请输入email</div>
								</div>
							</div>

							<div class="fc"></div>
							<div class="form-group x12">
								<div class="label"><label></label></div>
								<div class="field">
									<input id="save" class="btn bg-dot btn-block" name="save" type="submit" value="保存" />
								</div>
							</div>
						</div>
					</form>
					<? }?>
 				</div>
			</div>
		</div>
	</div>
</div>
<?include("inc_footer.php");?>
</body>
</html>