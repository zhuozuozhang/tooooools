<?php 

include("../system/inc.php");
include("cms_check.php");

if(isset($_POST['save'])){
	null_back($_POST['c_name'],'请填写栏目名称');
	null_back($_POST['c_pid'],'请选择上级栏目');
	non_numeric_back($_POST['c_sort'],'排序必须是数字');
	$_data['c_name']=$_POST['c_name'];
	$_data['c_pid']=$_POST['c_pid'];
	$_data['c_sort']=$_POST['c_sort'];
	if($_POST['c_pid']==$_GET['id']){
		alert_back('上级栏目不能修改!');
	}
	$sql="update xtcms_vod_class set ".arrtoupdate($_data)." where c_id = ".$_GET['id'].";";
	if(mysql_query($sql)){
		alert_href('频道修改成功!',"cms_channel.php");
	}else{
		alert_back("修改失败!");
	}
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<? include("inc_head.php");?>
<script type="text/javascript">
KindEditor.ready(function(K) {
	K.create('#c_content');
	K.create('#c_scontent');
	var editor = K.editor();
	K('#cover_upload').click(function() {
		editor.loadPlugin('image', function() {
			editor.plugin.imageDialog({
			imageUrl : K('#c_cover').val(),
			clickFn : function(url, title, width, height, border, align) {
				K('#c_cover').val(url);
				editor.hideDialog();
				}
			});
		});
	});
});
</script>
</head>
<body>

<? include("inc_header.php");?>
<div id="content">
	<div class="container">
		<div class="line-big">
			
<? include("inc_left.php");?>
			<div class="xx105">
				<div class="hd-1">修改栏目</div>
				<div class="bd-1">
					
<? $result=mysql_query("select * from xtcms_vod_class where c_id = ".$_GET['id']);
if($row=mysql_fetch_array($result)){?>
					<form method="post">
						<div class="line-big">
							<div class="form-group x3">
								<div class="label"><label for="c_name">栏目名称 <span class="badge bg-dot">必填</span></label></div>
								<div class="field">
									<input id="c_name" class="input" name="c_name" type="text" size="60" data-validate="required:请输入频道名称" value="<? echo $row['c_name'];?>" />
									<div class="input-note">请输入频道名称</div>
								</div>
							</div>
							<div class="form-group x4">
								<div class="label"><label for="c_parent">上级频道</label></div>
								<div class="field">
									<select id="c_pid" class="input" name="c_pid">
										<option value="0">作为主频道</option>
										
<? echo channel_select_list(0,0,$row['c_pid'],0);?>
									</select>
									<div class="input-note">请选择要添加频道的上级频道</div>
								</div>
							</div>
<div class="form-group x5 form-auto">
								<div class="label"><label for="c_sort">排序</label></div>
								<div class="field">
									<input id="c_sort" class="input" name="c_sort" type="text" size="30" value="<? echo $row['c_sort'];?>" />

								</div>
							</div>
							<div class="form-group x12">
								<div class="label"><label></label></div>
								<div class="field">
									<input id="save" class="btn bg-dot btn-block" name="save" type="submit" value="保存" />
								</div>
							</div>
						</div>
					</form>
					
<?}?>
				</div>
			</div>
		</div>
	</div>
</div>

<? include("inc_footer.php");?>
</body>
</html>