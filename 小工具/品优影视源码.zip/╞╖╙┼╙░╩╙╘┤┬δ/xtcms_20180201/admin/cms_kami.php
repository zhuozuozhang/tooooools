<?php
include('../system/inc.php');
include('cms_check.php');
if(isset($_POST['save']))
{
	null_back($_POST['c_number'],'请填写数量');
	null_back($_POST['c_money'],'请填写点数');
	$kmsl=$_POST['c_number'];
	$c_money= $_POST['c_money'];
	$c_addtime= time();
	function getkm($len = 12) 
	{
		$str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
		$strlen = strlen($str);
		$randstr = "";
		for ($i = 0; $i < $len; $i++) 
		{
			$randstr .= $str[mt_rand(0, $strlen - 1)];
		}
		return $randstr;
	}
	//开始添加
for ($i = 0; $i < $kmsl; $i++) 
	{
		$km=getkm(12);
		$SQL = "INSERT INTO `xtcms_user_card` (`c_id`, `c_number`, `c_money`, `c_addtime`) VALUES (NULL, '$km', '$c_money', '$c_addtime');";
		//生成卡密
mysql_query($SQL);
	}
	echo "<script>alert('生成卡密成功，一共生成 ".$kmsl." 张卡密！');location.href='cms_kami.php'</script>";
	mysql_close();
}
if(isset($_GET['del']))
{
	$sql = 'delete from xtcms_user_card where c_id = '.$_GET['del'].'';
	if(mysql_query($sql))
	{
		alert_href('删除成功!','cms_kami.php');
	}
	else
	{
		alert_back('删除失败！');
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('inc_head.php') ?>
</head>
<body>
<?php include('inc_header.php') ?>
<div id="content">
	<div class="container">
		<div class="line-big">
			<?php include('inc_left.php') ?>
			<div class="xx105">
				<div class="hd-1">卡密管理</div>
				<div class="bd-1">
					<form method="post" class="form-auto oh mb10" >
						<div class="fr" >
							 <input id="c_number" class="input" type="text" name="c_number" placeholder="请输入生成卡密数量"/>  <input id="c_money" class="input" type="text" name="c_money" placeholder="请输入点数"/>
							<input type="submit" id="save" class="btn bg-sub" name="save" value="生成" />
						</div>
<div class="fl">
							按是否使用筛选：
							<select class="input" onchange="location.href='cms_kami.php?cid='+this.options[this.selectedIndex].value;">
								<option value="">全部</option>
								<option value="1" >已使用</option>	<option value="0">未使用</option>						</select>
						</div>

					</form>
					<form method="post" class="form-auto">
						<table class="table table-bordered">
							<tr>
								<th>编号</th>
								<th>充值卡号</th>
								<th>点数</th>
								<th>使用情况</th>
								<th>使用者</th>
								<th>充值时间</th>
								<th>操作</th>
							</tr>
							<?php
$sql = 'select * from xtcms_user_card order by c_id desc';
$pager = page_handle('page',20,mysql_num_rows(mysql_query($sql)));
$result = mysql_query($sql.' limit '.$pager[0].','.$pager[1].'');
if (isset($_GET['cid'])) 
{
	$sql = 'select * from xtcms_user_card where c_used="'.$_GET['cid'].'" order by c_id desc';
	$pager = page_handle('page',20,mysql_num_rows(mysql_query($sql)));
	$result = mysql_query($sql.' limit '.$pager[0].','.$pager[1].'');
}
while($row= mysql_fetch_array($result))
{
	?>
							<tr>
								<td><?php echo $row['c_id'] ?></td>
								<td><?php echo $row['c_number'] ?></td>
								<td><?php echo $row['c_money'] ?></td>
								<td>
<?php
echo ($row['c_used'] == 1 ? '<span class="badge bg-dot">已使用</span> ':'');
	echo ($row['c_used'] == 0 ? '<span class="badge bg-main">未使用</span> ':'');
	?>
								</td>
								<td>
<?php echo $row['c_user'] ?>
								</td>
								<td><?php echo date('Y-m-d H:i:s',$row['c_usetime'])?></td>
								<td><a class="btn bg-dot btn-small" href="cms_kami.php?del=<?php echo $row['c_id']?>" onclick="return confirm('确认要删除吗？')"><span class="icon-times"> 删除</span></a></td>
							</tr>
							<?php }
?>

						</table>
					</form>
					<div class="page_show"><?php echo page_show($pager[2],$pager[3],$pager[4],2);
?> </div>
				</div>

			</div>
		</div>
	</div>
</div>
<?php include('inc_footer.php') ?>
</body>
</html>