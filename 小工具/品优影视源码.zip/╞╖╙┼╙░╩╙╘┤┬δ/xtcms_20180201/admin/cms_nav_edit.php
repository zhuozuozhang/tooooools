<?php

include("../system/inc.php");
include("cms_check.php");
 if(isset($_POST['save'])){
 	null_back($_POST['n_name'],'请输入名称');
 	non_numeric_back($_POST['order'],'请输入排序数字');
 	$_data['n_name']=$_POST['n_name'];
 	$_data['n_url']=$_POST['n_url'];
 	$_data['order']=$_POST['order'];
 	$sql="update xtcms_nav set ".arrtoupdate($_data)." where id =".$_GET['id'].";";
 	if(mysql_query($sql)){
 		alert_href('修改成功!','cms_nav.php');
 	}else{
 		alert_back('修改失败!');
 	}
 }
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?include("inc_head.php");?>
</head>
<body>
<?include("inc_header.php");?>
<div id="content">
	<div class="container">
		<div class="line-big">
		<?include("inc_left.php");?>
			<div class="xx105">
				<div class="hd-1">修改导航</div>
				<div class="bd-1">
<? $result=mysql_query("select * from xtcms_nav where id = ".$_GET['id'].";");
if($row=mysql_fetch_array($result)){?>
 					<form method="post">
<div class="form-group">
							<div class="label"><label for="s_name">名称</label></div>
							<div class="field">
								<input id="n_name" class="input" name="n_name" type="text" size="60" value="<? echo $row['n_name'];?>" />
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label for="s_url">链接</label></div>
							<div class="field">
								<input id="n_url" class="input" name="n_url" type="text" size="60" value="<? echo $row['n_url'];?>" />
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label for="s_order">排序 <span class="badge bg-dot">必填</span></label></div>
							<div class="field">
								<input id="order" class="input" name="order" type="text" size="60"  value="<? echo $row['order'];?>" />
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label></label></div>
							<div class="field">
								<input id="save" class="btn bg-dot btn-block" name="save" type="submit" value="保存" />
							</div>
						</div>
					</form>
					<? }?>
				</div>

			</div>
		</div>
	</div>
</div>
<?include("inc_footer.php");?>
</body>
</html>