<?php 

include("../system/inc.php");
include("cms_check.php");

if(isset($_GET['del'])){
	$sql="select * from xtcms_vod_class where c_id =".$_GET['del'].";";
	$result=mysql_query($sql);
	$row=mysql_fetch_array($result);
	mysql_query("delete from xtcms_vod_class where c_id = ".$_GET['del'].";");
	mysql_query("delete from xtcms_vod where d_class = ".$_GET['del'].";");
	alert_href("删除成功！","cms_channel.php");
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<? include("inc_head.php");?>
</head>
<body>
<?php include("inc_header.php");?>
<div id="content">
	<div class="container">
		<div class="line-big">

<? include("inc_left.php");?>
			<div class="xx105">
				<div class="hd-1">管理栏目</div>
				<div class="bd-1">
					<form method="post" class="form-auto">
						<table class="table table-bordered">
							<tr>
								<th>ID</th>
								<th>排序</th>
								<th>频道名称</th>
								<th>内容操作</th>
								<th>频道操作</th>
							</tr>
							
<? echo channel_manage(0,0);?>
						</table>
					</form>
				</div>

			</div>
		</div>
	</div>
</div>

<? include("inc_footer.php");?>
</body>
</html>
