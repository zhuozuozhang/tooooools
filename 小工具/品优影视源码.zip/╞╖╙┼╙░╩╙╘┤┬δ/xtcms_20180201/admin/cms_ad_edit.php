<?php 

include('../system/inc.php');
include('cms_check.php');
if(isset($_POST['save'])){
	null_back($_POST['null_back'],'请填写广告名称');
	$data['title']=$_POST['title'];
	$data['pic']=$_POST['pic'];
	$data['url']=$_POST['url'];
	$data['catid']=$_POST['catid'];
	$sql= "update xtcms_ad set ".arrtoupdate($data)."where id = ".$_GET['id'].";";
	if(mysql_query($sql)){
		alert_href("广告修改成功!","cms_ad.php");
	}else{
		alert_back("修改失败!");
	}
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<?include("inc_head.php");?>
<script type="text/javascript">
KindEditor.ready(function(K) {
	K.create('#l_picture');
	var editor = K.editor();

});
</script>
</head>
<body>

<? include("inc_header.php");?>
<div id="content">
	<div class="container">
		<div class="line-big">

<? include("inc_left.php");?>
			<div class="xx105">
				<div class="hd-1">修改广告</div>
				<div class="bd-1">

<? $result=mysql_query("select * from xtcms_ad where id =".$_GET['id'].";");
if($row=mysql_fetch_array($result)){?>
					<form method="post">
						<div class="form-group">
							<div class="label"><label for="s_name">名称<span class="badge bg-dot">必填</span></label></div>
							<div class="field">
								<input id="s_name" class="input" name="title" type="text" size="60" value="
<? echo $row['title'];?>
 " />
							</div>
						</div>

						<div class="form-group form-auto">
							<div class="label"><label for="l_picture">内容</label></div>
							<div class="field">
							<textarea id="l_picture" class="input" name="pic" />
							<? echo htmlspecialchars($row['pic']);?>
</textarea>
										<div class="input-note">请填广告内容</div>
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label for="l_url">广告位置 <span class="badge bg-dot">必填</span></label></div>
							<div class="field">
<select id="catid" class="input" name="catid">
						<option value="1" 
<? echo($row['catid']==1?'selected="selected"':" ");?>
>导航通栏</option>
						<option value="2" 
<? echo($row['catid']==2?'selected="selected"':" ");?>
>底部通栏</option>
						<option value="3" 
<? echo($row['catid']==3?'selected="selected"':" ");?>
>播放器加载</option>
						<option value="4" 
<? echo($row['catid']==4?'selected="selected"':" ");?>
>播放页右侧</option>
						<option value="5" 
<? echo($row['catid']==5?'selected="selected"':" ");?>
>播放等待广告</option>


									</select>

								<div class="input-note">请选择位置</div>
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label></label></div>
							<div class="field">
								<input id="save" class="btn bg-dot btn-block" name="save" type="submit" value="保存" />
							</div>
						</div>
					</form>
<?}?>
				</div>
			</div>
		</div>
	</div>
</div>

<? include("inc_footer.php");?>
</body>
</html>