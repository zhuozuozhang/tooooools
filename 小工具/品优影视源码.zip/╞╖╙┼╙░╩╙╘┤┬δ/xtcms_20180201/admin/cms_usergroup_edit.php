<?php
include('../system/inc.php');
include('cms_check.php');
if(isset($_POST['save'])){
	null_back($_POST['ug_name'],'请输入名称');
$_data['ug_name'] = $_POST['ug_name'];
$_data['ug_upgrade'] = $_POST['ug_upgrade'];
	
	$sql = 'update xtcms_user_group set '.arrtoupdate($_data).' where ug_id = '.$_GET['id'].'';
	if(mysql_query($sql)){
		alert_href('修改成功!','cms_usergroup.php');
	}else{
		alert_back('修改失败!');
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('inc_head.php') ?>
</head>
<body>
<?php include('inc_header.php') ?>
<div id="content">
	<div class="container">
		<div class="line-big">
			<?php include('inc_left.php') ?>
			<div class="xx105">
				<div class="hd-1">修改会员组</div>
				<div class="bd-1">
					<?php
					$result = mysql_query('select * from xtcms_user_group where ug_id = '.$_GET['id'].'');
					if($row = mysql_fetch_array($result)){
					?>
										<form method="post">
						<div class="form-group">
							<div class="label"><label for="l_name">会员组名称 <span class="badge bg-dot">必填</span></label></div>
							<div class="field">
								<input id="ug_name" class="input" name="ug_name" type="text" size="60" data-validate="required:请填写会员组名称" value="<?php echo $row['ug_name'];?>" />
								<div class="input-note">请填写会员组名称</div>
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label for="l_url">所需积分 <span class="badge bg-dot">必填</span></label></div>
							<div class="field">
								<input id="ug_upgrade" class="input" name="ug_upgrade" type="text" size="60" data-validate="required:请填写所需积分" value="<?php echo $row['ug_upgrade'];?>" />
								<div class="input-note">请填写所需积分</div>
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label></label></div>
							<div class="field">
								<input id="save" class="btn bg-dot btn-block" name="save" type="submit" value="保存" />
							</div>
						</div>
					</form>

					<?php
						}
					?>
				</div>

			</div>
		</div>
	</div>
</div>
<?php include('inc_footer.php') ?>
</body>
</html>