<?php
include('../system/inc.php');
include('cms_check.php');
if(isset($_GET['del'])){
	$sql = 'delete from xtcms_user_group where ug_id = '.$_GET['del'].'';
	if(mysql_query($sql)){
		alert_href('删除成功!','cms_usergroup.php');
	}else{
		alert_back('删除失败！');
	}
}
if(isset($_POST['save'])){
	null_back($_POST['ug_name'],'请填写名称');
	$data['ug_name'] = $_POST['ug_name'];
	$data['ug_upgrade'] = $_POST['ug_upgrade'];
	$str = arrtoinsert($data);
	$sql = 'insert into xtcms_user_group ('.$str[0].') values ('.$str[1].')';
	if(mysql_query($sql)){
		alert_href('添加成功!','cms_usergroup.php');
	}else{
		alert_back('添加失败!');
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('inc_head.php') ?>
<script type="text/javascript">
KindEditor.ready(function(K) {
	var editor = K.editor();
	K('#picture').click(function() {
		editor.loadPlugin('image', function() {
			editor.plugin.imageDialog({
			imageUrl : K('#l_picture').val(),
			clickFn : function(url, title, width, height, border, align) {
				K('#l_picture').val(url);
				editor.hideDialog();
				}
			});
		});
	});
});
</script>
</head>
<body>
<?php include('inc_header.php') ?>
<div id="content">
	<div class="container">
		<div class="line-big">
			<?php include('inc_left.php') ?>
			<div class="xx105">
				<div class="hd-1">添加会员组</div>
				<div class="bd-1">
					<form method="post">
						<div class="form-group">
							<div class="label"><label for="l_name">会员组名称 <span class="badge bg-dot">必填</span></label></div>
							<div class="field">
								<input id="ug_name" class="input" name="ug_name" type="text" size="60" data-validate="required:请填写会员组名称" value="" />
								<div class="input-note">请填写会员组名称</div>
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label for="l_url">所需积分 <span class="badge bg-dot">必填</span></label></div>
							<div class="field">
								<input id="ug_upgrade" class="input" name="ug_upgrade" type="text" size="60" data-validate="required:请填写所需积分" value="" />
								<div class="input-note">请填写所需积分</div>
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label></label></div>
							<div class="field">
								<input id="save" class="btn bg-dot btn-block" name="save" type="submit" value="保存" />
							</div>
						</div>
					</form>
				</div>
				<div class="hd-1">会员组管理</div>
				<div class="bd-1">
					<table class="table table-bordered">
						<tr>
							<th>ID</th>
							<th>名称</th>
							<th>所需积分</th>
							<th>操作</th>
						</tr>
						<?php
						$result = mysql_query('select * from xtcms_user_group');
						while($row = mysql_fetch_array($result)){
						?>
						<tr>
							<td><?php echo $row['ug_id']?></td>

							<td><?php echo $row['ug_name']?></td>
							<td><?php echo $row['ug_upgrade']?></td>
							<td><a class="btn bg-sub btn-small" href="cms_usergroup_edit.php?id=<?php echo $row['ug_id']?>"><span class="icon-edit"> 修改</span></a>&nbsp<a class="btn bg-dot btn-small" href="cms_usergroup.php?del=<?php echo $row['ug_id']?>" onclick="return confirm('确认要删除吗？')"><span class="icon-times"> 删除</span></a></td>
						</tr>
						<?php
							}
						?>
					</table>
				</div>

			</div>
		</div>
	</div>
</div>
<?php include('inc_footer.php') ?></body>
</html>