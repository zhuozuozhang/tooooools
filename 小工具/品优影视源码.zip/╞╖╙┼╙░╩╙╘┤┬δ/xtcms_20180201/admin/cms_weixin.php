<?php
include('../system/inc.php');
include('cms_check.php');
if(isset($_POST['save'])){
	$_data['s_token'] = $_POST['s_token'];
	$sql = 'update xtcms_system set '.arrtoupdate($_data).' where id = 1';
	if(mysql_query($sql)){
		alert_href('修改成功!','cms_weixin.php');
	}else{
		alert_back('修改失败!');
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('inc_head.php') ?>
<script type="text/javascript">
KindEditor.ready(function(K) {
	var editor = K.editor();
	K('#picture').click(function() {
		editor.loadPlugin('image', function() {
			editor.plugin.imageDialog({
			imageUrl : K('#l_picture').val(),
			clickFn : function(url, title, width, height, border, align) {
				K('#l_picture').val(url);
				editor.hideDialog();
				}
			});
		});
	});
});
</script>
</head>
<body>
<?php include('inc_header.php') ?>
<div id="content">
	<div class="container">
		<div class="line-big">
			<?php include('inc_left.php') ?>
			<div class="xx105">
				<div class="hd-1">微信对接配置</div>
				<div class="bd-1">
				<?php
					$result = mysql_query('select * from xtcms_system where id = 1');
					if( $row = mysql_fetch_array($result)){
					?>
					<form method="post">
							<div class="form-group">
							<div class="label"><label for="l_name">微信对接地址</label></div>
							<div class="field">
								<?php echo 'http://'.$_SERVER['SERVER_NAME'];?>/wx_api.php
								<div class="input-note">公众号对接地址</div>
							</div>
						</div>
						<div class="form-group">
							<div class="label"><label for="l_name">token值 <span class="badge bg-dot">必填</span></label></div>
							<div class="field">
								<input id="s_token" class="input" name="s_token" type="text" size="60" data-validate="required:请填写账号" value="<?php echo $row['s_token']?>" />
								<div class="input-note">请填写token值</div>
							</div>
						</div>

						
						<div class="form-group">
							<div class="label"><label></label></div>
							<div class="field">
								<input id="save" class="btn bg-dot btn-block" name="save" type="submit" value="保存" />
							</div>
						</div>
					</form>
					<?php
						}
					?>
				</div>

			</div>
		</div>
	</div>
</div>
<?php include('inc_footer.php') ?>
</body>
</html>