<?php
if (!isset($_COOKIE['admin_name'])) {
    alert_href('非法登录', 'cms_login.php');
}
function getTopDomainhuo()
{
    $xzv_0 = $_SERVER['HTTP_HOST'];
}
/*$domain = getTopDomainhuo();
$real_domain = 'baidu.com';
$check_host = 'http://shouquan.pucms.com/update.php';
$client_check = $check_host . '?a=client_check&u=' . $_SERVER['HTTP_HOST'];
$check_message = $check_host . '?a=check_message&u=' . $_SERVER['HTTP_HOST'];
$check_info = file_get_contents($client_check);
$message = file_get_contents($check_message);
if ($check_info == '1') {
    echo '<font color=red>' . $message . '</font>';
    die;
} elseif ($check_info == '2') {
    echo '<font color=red>' . $message . '</font>';
    die;
} elseif ($check_info == '3') {
    echo '<font color=red>' . $message . '</font>';
    die;
}
if ($check_info !== '0') {
    if ($domain !== $real_domain) {
        echo '远程检查失败了。请联系授权提供商。';
        die;
    }
}*/