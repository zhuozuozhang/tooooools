<div id="footer">
	<div class="container">
		<div class="line">
			<p>版权所有 筱瞳CMS 保留所有权利</p>
			<p><?php echo $cms_version; ?></p>
		</div>
	</div>
</div>
