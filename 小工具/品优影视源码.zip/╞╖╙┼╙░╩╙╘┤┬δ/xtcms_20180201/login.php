<?php 
include('system/inc.php');
if(isset($_SESSION['user_name'])){
header('location:ucenter');
};
	
if(isset($_POST['submit'])){
	null_back($_POST['u_name'],'请输入用户名');
	null_back($_POST['u_password'],'请输入密码');
	$u_name = $_POST['u_name'];
	$u_password = $_POST['u_password'];
	$sql = 'select * from xtcms_user where u_name = "'.$u_name.'" and u_password = "'.md5($u_password).'"';
	$result = mysql_query($sql);
	if(!! $row = mysql_fetch_array($result)){
		
	$_data['u_loginnum'] = $row['u_loginnum']+1; 
	$_data['u_loginip'] =$_SERVER["REMOTE_ADDR"]; 
	$_data['u_logintime'] =date('y-m-d h:i:s',time());
	mysql_query('update xtcms_user set '.arrtoupdate($_data).' where u_id ="'.$row['u_id'].'"');
	$_SESSION['user_name']=$row['u_name'];
	$_SESSION['user_group']=$row['u_group'];
		header('location:ucenter');
	}else{
		alert_href('用户名或密码错误','login.php');
	}
}
if(isset($_POST['reg'])){
	null_back($_POST['name'],'请输入用户名');
	null_back($_POST['password'],'请输入密码');
	null_back($_POST['passwd2'],'请确认密码');
		$result = mysql_query('select * from xtcms_user where u_name = "'.$_POST['name'].'"');
	if(mysql_fetch_array($result)){
		alert_back('帐号重复，请更换帐号。');
	}
	$data['u_name'] = $_POST['name'];
	$data['u_password'] = md5($_POST['password']);
	$data['u_email'] = $_POST['email'];
	$data['u_status'] =1;
	$data['u_group'] =1;
	$data['u_fav'] =0;
	$data['u_plays'] =0;
	$data['u_downs'] =0;
	
	$data['u_regtime'] =date('y-m-d h:i:s',time());
	$str = arrtoinsert($data);
		$sql = 'insert into xtcms_user ('.$str[0].') values ('.$str[1].')';
	if(mysql_query($sql)){
		alert_href('注册成功!','login.php');
	}else{
alert_back('注册失败');
	}
	
	
}
?>
<!DOCTYPE html>
<html>
<!-- Head -->
<head>
<title>会员登录-<?php echo $xtcms_seoname;?></title> 
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link rel="stylesheet" href="css/login.css" type="text/css" media="all">
<meta name="keywords" content="<?php echo $xtcms_keywords;?>">
<meta name="description" content="<?php echo $xtcms_description;?>">
</head>
<body>
<h1>欢迎登录<?php echo $xtcms_name;?></h1>

	<div class="container w3layouts agileits">

		<div class="login w3layouts agileits">
			<h2>登 录</h2>
			<form method="post">
				<input type="text" Name="u_name" placeholder="用户名" required="">
				<input type="password" Name="u_password" placeholder="密码" required="">

			<ul class="tick w3layouts agileits">
				<li>
					<input type="checkbox" id="brand1" value="">
					<label for="brand1"><span></span>记住我</label>
				</li>
			</ul>
			<div class="send-button w3layouts agileits">

					<input type="submit" name="submit" value="登 录">

			</div>
			</form>
			<div class="social-icons w3layouts agileits">
				<p>- 导航 -</p>
				<ul>
					<li class="qq"><a href="<?php echo $xtcms_domain;?>">
					<span class="icons w3layouts agileits"></span>
					<span class="text w3layouts agileits">首页</span></a></li>
					<li class="weixin w3ls"><a href="<?php echo $xtcms_domain;?>movie.php?m=/dianying/list.php?cat=all%26pageno=1">
					<span class="icons w3layouts"></span>
					<span class="text w3layouts agileits">电影</span></a></li>
					<li class="weibo aits"><a href="<?php echo $xtcms_domain;?>tv.php?u=/dianshi/list.php?cat=all%26pageno=1">
					<span class="icons agileits"></span>
					<span class="text w3layouts agileits">电视剧</span></a></li>
					<div class="clear"> </div>
				</ul>
			</div>
			<div class="clear"></div>
		</div>
		<div class="register w3layouts agileits">
			<h2>注 册</h2>
		<form method="post">

				<input type="text" Name="name" placeholder="用户名" required="">
				<input type="text" Name="email" placeholder="邮箱" required="">
				<input type="password" Name="password" placeholder="密码" required="">
				<input type="password" Name="passwd2" placeholder="确认密码" required="">

			<div class="send-button w3layouts agileits">

					<input type="submit" value="免费注册" name="reg">

			</div>
			</form>
			<div class="clear"></div>
		</div>

		<div class="clear"></div>

	</div>

	<div class="footer w3layouts agileits">
		<p><?php echo $xtcms_copyright;?></p>
	</div>

</body>
<!-- //Body -->

</html>
