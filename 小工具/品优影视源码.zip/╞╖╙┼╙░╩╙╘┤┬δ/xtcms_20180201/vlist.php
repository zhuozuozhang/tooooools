<?php include('system/inc.php');?>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta http-equiv="cache-control" content="no-siteapp">
<title>视频列表-<?php echo $xtcms_seoname;?></title>
<link rel="stylesheet" href="<?php echo $xtcms_domain;?>style/css/bootstrap.min.css" />
<link href="<?php echo $xtcms_domain;?>style/css/swiper.min.css" rel="stylesheet" type="text/css" >		
<link href="<?php echo $xtcms_domain;?>style/font/iconfont.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $xtcms_domain;?>style/css/blackcolor.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $xtcms_domain;?>style/css/style.min.css" rel="stylesheet" type="text/css" />
<script type='text/javascript' src="<?php echo $xtcms_domain;?>style/js/swiper.min.js"></script>
<meta name="keywords" content="视频排行,<?php echo $xtcms_keywords;?>">
<meta name="description" content="<?php echo $xtcms_description;?>">
<!--[if lt IE 9]><script src="js/html5.js"></script><![endif]-->
</head>
<body class="vod-type apptop">
<?php include 'header.php'; ?>
<div class="container">
	<div class="row">
<div class="hy-cascade clearfix">
			<div class="left-head hidden-sm hidden-xs">
				<ul class="clearfix">
					<li class="text"><span class="text-muted">当前频道</span></li>
					<li><a href="./vlist.php?cid=0"  class="active">抢先看资源</a></li></ul>
			</div>
			<div class="content-meun clearfix">
				<a class="head" href="javascript:;" data-toggle="collapse" data-target="#collapse">
				<span class="text">抢先看资源</span></a>
				<div class="item collapse in" id="collapse">
					<ul class="visible-sm visible-xs clearfix">
						<li class="text"><span class="text-muted">按频道</span></li>
					<li><a href="./vlist.php?cid=0" id="idc4ca4238a0b923820dcc509a6f75849b">抢先看资源</a></li>					</ul>
					
					<ul class="clearfix">
											  <li><a href="./vlist.php?cid=0" class="acat" style="white-space: pre-wrap;">全部</a></li>
											  <?php
$result = mysql_query('select * from xtcms_vod_class where c_pid=0 order by c_id asc');
while ($row = mysql_fetch_array($result)){

			echo '﻿<li><a href="./vlist.php?cid='.$row['c_id'].'" class="acat" style="white-space: pre-wrap;margin-bottom: 4px;">'.$row['c_name'].'</a></li>';
		}
?>


						</ul>
				</div>
			</div>
		</div>
        <div class="hy-layout clearfix">
<?php echo get_ad(1)?>
		</div>
		<div class="hy-layout clearfix" style="margin-top: 0;">
			<div class="hy-switch-tabs active clearfix">
				<span class="text-muted pull-right hidden-xs">如果您喜欢本站请动动小手分享给您的朋友！</span>
				<ul class="nav nav-tabs">
					<li class="active"><a href="#">抢先看资源</a></li>
				</ul>
			</div>
			<div class="hy-video-list">
				<div class="item">
					<ul class="clearfix">
 							<?php
							if (isset($_GET['cid'])) {
								if ($_GET['cid'] != 0){
									$sql = 'select * from xtcms_vod where d_parent in ('.$_GET['cid'].') order by d_id desc';
									$pager = page_handle('page',24,mysql_num_rows(mysql_query($sql)));
									$result = mysql_query($sql.' limit '.$pager[0].','.$pager[1].'');
								}else{
									$sql = 'select * from xtcms_vod order by d_id desc';
									$pager = page_handle('page',24,mysql_num_rows(mysql_query($sql)));
									$result = mysql_query($sql.' limit '.$pager[0].','.$pager[1].'');
								}
							}
							while($row= mysql_fetch_array($result)){
								$cc="./bplay.php?bf=";
								$dd="./bplay/";
if ($xtcms_wei==1){
$ccb=$dd.$row['d_id'];
}
else{
$ccb=$cc.$row['d_id'];	
}
			echo '<div class="col-md-2 col-sm-3 col-xs-4">
							<a class="videopic lazy" href="'.$ccb.'" title="'.$row['d_name'].'" src="'.$row['d_picture'].'" style="background: url('.$row['d_picture'].') no-repeat; background-position:50% 50%; background-size: cover;"><span class="play hidden-xs"></span></a>
							<div class="title">
								<h5 class="text-overflow"><a href="'.$ccb.'">'.$row['d_name'].'</a></h5>
							</div>
							<div class="subtitle text-muted text-muted text-overflow hidden-xs">'.$row['d_zhuyan'].'</div>
						</div>';

		 } ?>

						</ul>
				</div>
			</div>
			<div class="hy-page clearfix">
				<ul class="cleafix"><li>
<?php echo page_show($pager[2],$pager[3],$pager[4],2);?></li></ul>
			</div>		</div>
	</div>
</div>



<?php  include 'footer.php';?>
<?php  ?>
