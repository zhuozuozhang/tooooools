<!--<script type='text/javascript' src="<?=$xtcms_domain?>style/js/system.js"></script>-->
<script src="<?=$xtcms_domain?>js/jquery.min.js"></script>
<div class="hy-head-menu">
        <div class="container">
            <div class="row">
                <div class="item">
                    <div class="logo">
                        <a class="hidden-sm hidden-xs" href="<?=$xtcms_domain?>"><img src="<?php echo $xtcms_logo;?>" /></a>
                    </div>
                    <div class="search hidden-sm">
                        <form id="ff-search" role="search" action="<?=$xtcms_domain?>seacher.php" method="post">
                            <input class="form-control" placeholder="输入影片关键词..." type="text" id="ff-wd" name="wd" required="">
                            <input type="submit" class="hide"><a href="javascript:" class="btns" title="搜索" onClick="$('#ff-search').submit();"><i class="icon iconfont icon-search"></i></a></form>
                    </div>
                    <ul class="menulist hidden-xs">
					<li id="nav-index"><a href="<?=$xtcms_domain?>">首页</a></li>
					<li id="nav-tv"><a href="<?=$xtcms_domain?>movie.php?m=/dianying/list.php?cat=all&pageno=1">电影</a></li>
					<li id="nav-dianying"><a href="<?=$xtcms_domain?>tv.php?u=/dianshi/list.php?cat=all&pageno=1">电视剧</a></li>
					<li id="nav-dongman"><a href="<?=$xtcms_domain?>dongman.php?m=/dongman/list.php?cat=all&pageno=1">动漫</a></li>
					<li id="nav-zongyi"><a href="<?=$xtcms_domain?>zongyi.php?m=/zongyi/list.php?cat=all&pageno=1">综艺</a></li>
					<?php
						$result = mysql_query('select * from xtcms_nav');
						while($row = mysql_fetch_array($result)){
						?>
<li id="nav-down"><a href="<?php echo $row['n_url'];?>" target="_blank"><?php echo $row['n_name'];?></a></li>
<?php
						}
						?>
	
                    </ul>
                </div>
            </div>
        </div>
    </div>
