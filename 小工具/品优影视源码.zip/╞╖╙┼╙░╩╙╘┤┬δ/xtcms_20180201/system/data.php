<?php
//Mysql数据库信息
if(!defined('PCFINAL')) exit('Request Error!');
define('DATA_HOST', 'localhost');
define('DATA_USERNAME', 'root');
define('DATA_PASSWORD', 'root');
define('DATA_NAME', 'xtcms');
?>