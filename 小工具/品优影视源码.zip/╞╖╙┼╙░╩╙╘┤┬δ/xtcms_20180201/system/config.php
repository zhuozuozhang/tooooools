<?php

$result = mysql_query('select * from xtcms_system where id = 1');
$row = mysql_fetch_array($result);
$xtcms_domain = $row['s_domain'];
$xtcms_name = $row['s_name'];
$xtcms_seoname = $row['s_seoname'];
$xtcms_keywords = $row['s_keywords'];
$xtcms_description = $row['s_description'];
$xtcms_copyright = $row['s_copyright'];
$xtcms_cache = $row['s_cache'];
$xtcms_wei = $row['s_wei'];
$xtcms_user = $row['s_user'];
$xtcms_logo = $row['s_logo'];
$xtcms_weixin = $row['s_weixin'];
$xtcms_dashang = $row['s_dashang'];
$xtcms_mjk = $row['s_mjk'];
$xtcms_jiekou = $row['s_jiekou'];
$xtcms_changyan = $row['s_changyan'];
$xtcms_qqun = $row['s_qqun'];
$xtcms_token= $row['s_token'];
$xtcms_slow= $row['s_slow'];
//广告获取
function get_ad($t0){
	$result = mysql_query('select * from xtcms_ad where catid ='.$t0.'');
	if (!!$row = mysql_fetch_array($result)){
return $row['pic'];
	}else{
		return '';
	};
}	
?>