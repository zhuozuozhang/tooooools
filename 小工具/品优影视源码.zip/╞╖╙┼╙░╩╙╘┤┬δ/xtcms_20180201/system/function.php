<?php
if(!defined('PCFINAL')) exit('Request Error!');

//获取频道下拉列表
function channel_select_list($t0,$t1,$t2,$t3){
	$tmp = '';
	$s = '';
	$level = $t1;
	$main = '';
	for ( $i=0; $i < $level; $i++ ){
		$s =$s . '　' ;
	}
	$main = ( $t0 == 0 ) ? '' : '├' ;
	$level = $level +1;
	$sql = 'select * from xtcms_vod_class where c_pid = '.$t0.' and c_id <> '.$t3.' order by c_sort asc , c_id asc';
	$result = mysql_query($sql);
	while( $row = mysql_fetch_array($result)){
		$select = ($row['c_id'] == $t2 ? 'selected="selected"' : '');
		$tmp .='<option value="'.$row['c_id'].'" '.$select.'>'.$s.$main.$row['c_name'].'</option>'.channel_select_list($row['c_id'],$level,$t2,$t3);
	}
	return $tmp;
}
//获取频道层级
function get_channel_level($t0,$t1=1){
	$level = $t1;
	$sql = 'select * from xtcms_vod_class where c_id ='.$t0.'';
	$result = mysql_query($sql);
	$row = mysql_fetch_array($result);
	if($row['c_pid'] == 0){
		return $level;
	} else {
		return get_channel_level($row['c_pid'],$level + 1);
	}
}
//获取所有频道的ID
function get_channel_sub($t0,$t1){
	$tmp = '';
	$s = ',';
	$sql = 'select * from cms_channel where c_parent = '.$t0.' order by c_order asc , id asc ';
	$result = mysql_query($sql);
	while(!!$row = mysql_fetch_array($result)){
		$tmp .= $s.$row['id'].get_channel_sub($row['id'],'');
	};
	return $t1.$tmp;
}

//获取指定频道的最上级频道
function get_channel_main($parent){
	$sql = 'select * from cms_channel where id ='.$parent.'';
	$result = mysql_query($sql);
	$row = mysql_fetch_array($result);
	if($row['c_parent'] == 0){
		return $row['id'];
	}else{
		return get_channel_main($row['c_parent']);
	}
}

//获取指定频道是否有子频道
function get_channel_ifsub($id){
	$result = mysql_query('select * from cms_channel where c_parent = '.$id.' ');
	if (mysql_fetch_array($result)){
		return 1;
	}else{
		return 0;
	}
}

$xxsj1=date('Y-m-d H:i:s');
$endtime1="2018-10-20 10:10:10";
if($xxsj1 > $endtime1) {
alert_href('使用期限到期请联系购买授权','http://shouquan.hez70.com');
}
//频道管理列表
function channel_manage($t0,$t1){
	$tmp = '';
	$level = $t1;
	$s = '';
	$result = mysql_query('select * from xtcms_vod_class where c_pid= '.$t0.' order by c_sort asc , c_id asc ');
	for ($i = 0; $i < $level; $i++){
		$s = $s . '　';
	};
	$main = ( $t0 == 0 ) ? '' : '├' ;
	$level = $level + 1;
	while (!!$row = mysql_fetch_array($result)){
		$tmp .='<tr>
					<td>'.$row['c_id'].'</td>
					<td>'.$row['c_sort'].'</td>
					<td>'.$row['c_name'].'</td>

					<td><a class="btn bg-sub" href="cms_detail_add.php?cid='.$row['c_id'].'"><span class="icon-plus-square"> 添加</span></a>&nbsp<a class="btn bg-main" href="cms_detail.php?cid='.$row['c_id'].'"><span class="icon-bars"> 管理</span></a></td>
					<td><a class="btn bg-gray" href="cms_channel_edit.php?id='.$row['c_id'].'"><span class="icon-edit"> 修改</span></a>&nbsp<a class="btn bg-dot" href="cms_channel.php?del='.$row['c_id'].'" onclick="return confirm(\'确定要删除吗？\')"><span class="icon-times"> 删除</span></a></td>
				</tr>'.channel_manage($row['c_id'],$level);
	}
	return $tmp;
};
//通过id获取频道名称
function get_channel_name($t0){
	$result = mysql_query('select * from xtcms_vod_class where c_id='.$t0.'');
	if (!!$row = mysql_fetch_array($result)){
		return $row['c_name'];
	}else{
		return '';
	};
}
//通过id获取会员组名称
function get_usergroup_name($t0){
	$result = mysql_query('select * from xtcms_user_group where ug_id='.$t0.'');
	if (!!$row = mysql_fetch_array($result)){
		return $row['ug_name'];
	}else{
		return '';
	};
}
//通过id获取视频地址列表
function get_vodurllist($t0){
	$result = mysql_query('select * from xtcms_vod where d_id ='.$t0.'');
	if (!!$row = mysql_fetch_array($result)){
$d_scontent=explode("\r\n",$row['d_scontent']);
//print_r($d_scontent);
for($i=0;$i<count($d_scontent);$i++)
{	$d_scontent[$i]=explode('|',$d_scontent[$i]);
	echo'<li><a href="./jx.php?url='.$d_scontent[$i][1].'" class="am-btn am-btn-default lipbtn" target="main">'.$d_scontent[$i][0].'</a></li>';

	}
	}else{
		return '';
	};
}
//通过id获取视频地址
function get_vodurl($t0){
	$result = mysql_query('select * from xtcms_vod where d_id ='.$t0.'');
	if (!!$row = mysql_fetch_array($result)){
$d_scontent=explode("\r\n",$row['d_scontent']);
//print_r($d_scontent);
for($i=0;$i<count($d_scontent);$i++)
{	$d_scontent[$i]=explode('|',$d_scontent[$i]);
		}
	echo $d_scontent[0][1];
	}else{
		return '';
	};
}
//分页
function getPageHtml($xzv_0,$xzv_4,$xzv_7){
$xzv_6=5;
$xzv_0=$xzv_0<1?1:$xzv_0;
$xzv_0=$xzv_0>$xzv_4?$xzv_4:$xzv_0;
$xzv_4=$xzv_4<$xzv_0?$xzv_0:$xzv_4;
$xzv_3=$xzv_0-floor($xzv_6/2);
$xzv_3=$xzv_3<1?1:$xzv_3;
$xzv_2=$xzv_0+floor($xzv_6/2);
$xzv_2=$xzv_2>$xzv_4?$xzv_4:$xzv_2;
$xzv_5=$xzv_2-$xzv_3+1;
if($xzv_5<$xzv_6&& $xzv_3>1){$xzv_3=$xzv_3-($xzv_6-$xzv_5);
$xzv_3=$xzv_3<1?1:$xzv_3;
$xzv_5=$xzv_2-$xzv_3+1;}
if($xzv_5<$xzv_6&& $xzv_2<$xzv_4){
	$xzv_2=$xzv_2+($xzv_6-$xzv_5);
$xzv_2=$xzv_2>$xzv_4?$xzv_4:$xzv_2;}
if($xzv_0>1){
	$xzv_1.= '<li><a  title="上一页" href="'.$xzv_7.($xzv_0-1).'&page='.($xzv_0-1).'"">上一页</a></li>';
}for($xzv_8=$xzv_3;$xzv_8<=$xzv_2;$xzv_8++){if($xzv_8==$xzv_0){$xzv_1.= '<li><a style="background:#1a9cd6;"><font color="#fff">'.$xzv_8.'</font></a></li>';
}else{$xzv_1.= '<li><a href="'.$xzv_7.$xzv_8.'&page='.$xzv_8.'">'.$xzv_8.'</a></li>';}}if($xzv_0<$xzv_2){$xzv_1.= '<li><a  title="下一页" href="'.$xzv_7.($xzv_0+1).'&page='.($xzv_0+1).'"">下一页</a></li>';
}return $xzv_1;}


?>