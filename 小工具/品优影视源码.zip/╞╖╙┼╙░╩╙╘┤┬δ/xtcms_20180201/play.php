<?php include('system/inc.php');
include('check.php');
error_reporting(0);
$yuming='http://www.360kan.com';
$player = $yuming.$_GET['play'];
$tvinfo = file_get_contents($player);
$tvzz='#<div class="num-tab-main g-clear\s*js-tab"\s*(style="display:none;")?>[\s\S]+?<a data-num="(.*?)" data-daochu="to=(.*?)" href="(.*?)">[\s\S]+?</div>#';
$tvzz1 = '#<a data-num="(.*?)" data-daochu="to=(.*?)" href="(.*?)">#';
$dyzz= '#<span class="txt">站点排序：</span>[\s\S]+?<div style=\' visibility:hidden\'#';
$bflist = '#<a data-daochu=(.*?) class="btn js-site ea-site (.*?)" href="(.*?)">(.*?)</a>#';
$jianjie = '#<p class="item-desc js-open-wrap">(.*?)</p>#';
$biaoti = '#<h1>(.*?)</h1>#';
$pan = '#<h2 class="title g-clear">(.*?)</h2>#';
$pan1 = '#<h2 class="g-clear">(.*?)</h2>#';

preg_match_all($jianjie, $tvinfo, $jjarr);
preg_match_all($tvzz, $tvinfo, $tvarr);
preg_match_all($dyzz, $tvinfo, $dyarr);
preg_match_all($pan, $tvinfo, $ptvarr);
preg_match_all($pan1, $tvinfo, $ptvarr1);
preg_match_all($dyzz, $tvinfo, $tvlist);
preg_match_all($biaoti, $tvinfo, $btarr);
$mvsrc = implode($glue, $tvlist[0]);
preg_match_all($bflist, $mvsrc, $dyarr1);
//print_r($dyarr1[0]);
$dysrc=$dyarr1[0];
$c=$dyarr1[3];//电影的播放链接
$d=$dyarr1[4];//电影来源

$jian = $jjarr[1][0];//简介
$timu = $btarr[1][0];//标题
$panduan = $ptvarr[1][0];
$panduan1 = $ptvarr1[1][0];

$zyv="#<div class=\"juji-main\">[\s\S]+?<div class=\"juji-page\">#";
$qi="#<span class='w-newfigure-hint'>(.*?)</span>#";
$zyimg="#data-src='(.*?)' alt='(.*?)'#";
preg_match_all($zyv, $tvinfo,$zyvarr);
$zylist = implode($glue, $zyvarr[0]);
$ztlizz="#<a href='(.*?)' data-daochu=to=(.*?) class='js-link'><div class='w-newfigure-imglink g-playicon js-playicon'>#";
preg_match_all($ztlizz, $zylist,$zyliarr);
preg_match_all($qi, $zylist,$qiarr);
preg_match_all($zyimg, $zylist,$imgarr);
$zyvi=$zyliarr[1];

$noqi=$qiarr[1];
$zypic=$imgarr[1];
$zyname=$imgarr[2];
//print_r($zyvi);
$mvsrc1 = str_replace("http://cps.youku.com/redirect.html?id=0000028f&url=", "", "$dysrc");
$zcf = implode($glue, $tvarr[0]);
preg_match_all($tvzz1, $zcf, $tvarr1);

$b = $tvarr1[3];

$much = 1;
$mjk=$xtcms_mjk;?>
<?php 
if (empty($c[0])){
$result = mysql_query('select * from xtcms_vod order by d_id asc');
		while ($row = mysql_fetch_array($result))
		{
if($timu==$row['d_name']){
	echo '<meta http-equiv = "refresh" content = "0;url='.$xtcms_domain.'bplay.php?bf='.$row['d_id'].'">';
}
}
}?>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta http-equiv="cache-control" content="no-siteapp">
<link rel="stylesheet" href="<?php echo $xtcms_domain;?>style/css/bootstrap.min.css" />
<link href="<?php echo $xtcms_domain;?>style/css/swiper.min.css" rel="stylesheet" type="text/css" >		
<link href="<?php echo $xtcms_domain;?>style/font/iconfont.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $xtcms_domain;?>style/css/blackcolor.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $xtcms_domain;?>style/css/style.min.css" rel="stylesheet" type="text/css" />
<script type='text/javascript' src="<?php echo $xtcms_domain;?>style/js/swiper.min.js"></script>
<script type='text/javascript' src='<?php echo $xtcms_domain;?>js/jquery.min.js?ver=0.5'></script>
<title><?php echo $timu; ?>-正在播放-<?php echo $xtcms_seoname;?></title>
<meta name="keywords" content="<?php echo $timu; ?>,<?php echo $xtcms_keywords;?>">
<meta name="description" content="<?php echo $timu; ?>,<?php echo $xtcms_description;?>">
<!--[if lt IE 9]><script src="js/html5.js"></script><![endif]-->

</head>
<body class="vod-type apptop">
<?php include 'header.php'; ?>
<div class="container">
<div class="row"  style="margin-top:10px"><?php echo get_ad(1)?></div>
	<div class="row">
		<div class="hy-player clearfix">
			<div class="item">
				<div class="col-md-9 col-sm-12 padding-0">
					<div class="info embed-responsive embed-responsive-4by3 bofangdiv"  id="cms_player">
						<img id="addid" src="<?php echo get_ad(3)?>" style="display: none;width:100%;border: 0px solid #FF6651">
						<iframe id="video" src="<?php if (empty($panduan) && empty($panduan1)) {echo"$mjk$c[0]";}else{if(!empty($b[0])){echo "$mjk$b[0]";}else{echo"$mjk$zyvi[1]";}}?>" style="width:100%;border:none"></iframe><a style="display:none" id="videourlgo" href=""></a>
					</div>
					<div class="footer clearfix">
						
					<? if (empty($c) && empty($zyvi)) {?>
						<ul class="cleafix hidden-sm hidden-xs">
							<li>
								<a class="btn btn-sm btn-default" id="btn-prev" href="javascript:void(0);"><i class="icon iconfont icon-rewind1"></i> 上一集</a>
							</li>
							<li class="">
								<a class="btn btn-sm btn-default" id="btn-next" href="javascript:void(0);">下一集 <i class="icon iconfont icon-fastforward"></i></a>
							</li>
						</ul>
					<?}?>
						<span class="text-muted" id="xuji"></span><span id="jishu" style="display:none;">1</span>
						
					</div>
					<div class="footer clearfix" id="xlu" style="display:none; height:auto"><span class="text-muted" >
<?php
$jkjk=explode('##',$xtcms_jiekou);if(empty($_GET[jx])){$_GET[jx]='0';}$jxjk=$jkjk[$_GET[jx]];
	for($k=0;$k<count($jkjk);$k++){
		$suzi=$k+1;
echo '<a onclick="xldata(';
echo "'$jkjk[$k]'";
echo ')" class="btn btn-sm btn-default">线路'.$suzi.'</a>  ';
}
?>
						</span></div>
				</div>
					<script type="text/javascript">
function xldata(urls){
	var videourls = document.getElementById('video');
	var xlqieh = document.getElementById('videourlgo');
	videourls.src = urls+xlqieh.href;
}
</script>
				<div class="col-md-3 col-sm-12 padding-0">
					<div class="sidebar">
						<div class="hy-play-list play">
							<div class="item tyui" id="dianshijuid">
								<div class="panel clearfix">
									<a class="option collapsed" data-toggle="collapse" data-parent="#playlist" href="#playlist1">点击播放<span class="text-muted pull-right"><i class="icon iconfont icon-right"></i></span></a>
									<div id="playlist1" class="playlist collapse in dianshijua">
										<ul class="playlistlink-1 list-15256 clearfix">
<?php
if (empty($panduan) && empty($panduan1)) {
	foreach ($c as $kk => $vod) {

		//echo $much++;
		//echo $video.'<br/>';
		//echo $key.'<br/>';
		echo "<li><a href='$vod' target='ajax' id=''>";
		echo "$d[$kk]</a></li>";
	}

} else {
	foreach ($b as $key => $video) {
		$mmm = $much++;
		$vd = $video;
		//echo $much++;
		//echo $video.'<br/>';
		//echo $key.'<br/>';
		echo "<li><a href='$vd' target='ajax' id='$mmm'>";
		echo "$mmm</a></li>";
	}
	if (!empty($panduan1)) 
foreach ($zyvi as $keya=>$tvideoa){
 			
		echo "<li style='width:50%'><a href='$tvideoa' target='ajax' id='$noqi[$keya]'><img src='$zypic[$keya]' width=100%/><br>$noqi[$keya]<br>$zyname[$keya]</a></li>";
    	
		
		}
}
?></ul>

									</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
	var al = $('.dianshijua a');
	al.attr('class','am-btn am-btn-default lipbtn');
	var ji= new Array();
	var btnji= new Array();
	for(var g=0;g<al.length;g++){
		ji.push(al[g].href);
		btnji.push(al[g].id);
		al[g].href = 'javascript:void(0)';
		al[g].target = '_self';
		al.eq(g).attr('onclick','bofang(\''+ji[g]+'\',\''+btnji[g]+'\')');
	};
	document.getElementById('xuji').style.display='block';
	document.getElementById('xlu').style.display = 'block';
</script>
<script type="text/javascript">
var tishi = ('正在为您播放<?php echo $timu; ?>');
document.getElementById('xuji').innerHTML = tishi;
	function bofang(mp4url,jiid){
		var tishi = ('正在为您播放<?php echo $timu; ?> '+jiid+'');
		var jitotal = $(".lipbtn").length;
		if (jiid != 1) {
			$("#btn-prev").attr("style","");
		}else{
			$("#btn-prev").attr("style","display:none;");
		}

		if (jiid != jitotal) {
			$("#btn-next").attr("style","");
		}else{
			$("#btn-next").attr("style","display:none;");
		}
		document.getElementById('videourlgo').href=mp4url;
		document.getElementById('xuji').innerHTML = tishi;
		document.getElementById('jishu').innerHTML = jiid;
		$(".btn-play-active").attr("style","");
        $(".btn-play-active").removeClass("btn-play-active");
		$("#"+jiid).addClass("btn-play-active");
		$("#"+jiid).attr("style","background: #00a0e9;color: #ffffff;border:1px solid #00a0e9;");
		if(mp4url.indexOf('iqiyi')>=0){
			document.getElementById('video').src='<?php echo $mjk;?>'+mp4url;
		}else if(mp4url.indexOf('qq')>=0){
			document.getElementById('video').src='<?php echo $mjk;?>'+mp4url;
		}else if(mp4url.indexOf('sohu')>=0){
			document.getElementById('video').src='<?php echo $mjk;?>'+mp4url;
		}else if(mp4url.indexOf('youku')>=0){
			document.getElementById('video').src='<?php echo $mjk;?>'+mp4url;
		}else if(mp4url.indexOf('tudou')>=0){
			document.getElementById('video').src='<?php echo $mjk;?>'+mp4url;
		}else if(mp4url.indexOf('le')>=0){
			document.getElementById('video').src='<?php echo $mjk;?>'+mp4url;
		}else if(mp4url.indexOf('58')>=0 && mp4url.indexOf('58')<5 ){
			document.getElementById('video').src='<?php echo $mjk;?>'+mp4url;
		}else{
			document.getElementById('video').src='<?php echo $mjk;?>'+mp4url;
		};
		//点击之后
		

		
		function test() {

			document.getElementById('addid').style.display = 'none';
		}
		setTimeout(test, 5000);
	};
</script>
<script type="text/javascript">
	var jishu = document.getElementById('jishu').innerHTML;
    	var tishi = ('正在为您播放<?php echo $timu; ?> '+jishu+'');
    	document.getElementById('xuji').innerHTML = tishi;
		$("#"+jishu).addClass("btn-play-active");
		$("#"+jishu).attr("style","background: #00a0e9;color: #ffffff;border:1px solid #00a0e9;");
		if (jishu == 1) {
			$("#btn-prev").attr("style","display:none;");
		};

	$("#btn-prev").click(function(){
       var obj = $(".btn-play-active");
        if(obj!=null){
        	$(".btn-play-active").attr("style","");
            $(".btn-play-active").removeClass("btn-play-active");
            obj.parent().prev().children(0).click();
           	
        }
    });
    $("#btn-next").click(function(){
       var obj = $(".btn-play-active");
        if(obj!=null){
        	$(".btn-play-active").attr("style","");
            $(".btn-play-active").removeClass("btn-play-active");
            obj.parent().next().children(0).click();
           
        }
    });

</script>
<div class="container">
	<div class="row">
		<div class="col-md-9 col-sm-12 hy-main-content">
			<div class="hy-layout clearfix">
				<div class="hy-switch-tabs">
					<ul class="nav nav-tabs">
						<li class="active"><a href="#list3" data-toggle="tab">剧情介绍</a></li>
											</ul>
				</div>
				<div class="tab-content">
					<div class="hy-play-list tab-pane fade in active" id="list3">
						<div class="item">
							<div class="plot">
								<?php echo $jian; ?></div>
						</div>
					</div>
				</div>
			</div>
			<div class="hy-layout clearfix">
				<div class="hy-video-list">
					<div class="hy-video-head">
			
						<h3 class="margin-0">猜你喜欢</h3>
					</div>
					<div class="swiper-container hy-switch">
						<div class="swiper-wrapper">
							<?php include 'data/like.php'; ?></div>
						<div class="swiper-button-next">
							<i class="icon iconfont icon-right"></i>
						</div>
						<div class="swiper-button-prev">
							<i class="icon iconfont icon-back"></i>
						</div>
					</div>
					
				</div>
			</div>
			<div class="hy-layout clearfix">
				<div class="hy-video-head">
					<h3 class="margin-0">影片评论</h3>
				</div>
				<div class="ff-forum" id="ff-forum" data-id="37432" data-sid="1">
<?php echo $xtcms_changyan; ?>
</div>
			</div>
		</div>
		<div class="col-md-3 col-sm-12 hy-main-side hidden-sm hidden-xs">
			<div class="hy-layout clearfix">
				<div class="hy-details-qrcode side clearfix">
					<div class="item">
						<h5 class="text-muted">扫一扫用手机观看</h5>
						<p>
						<img src="<?php echo $xtcms_weixin;?>" width="250">
						</p>
						<p class="text-muted">
							分享到朋友圈
						</p>
					</div>
				</div>
				<div class="hy-video-ranking side clearfix">
					<div class="head">
						<a class="text-muted pull-right" href="./vlist.php">更多 <i class="icon iconfont icon-right"></i></a>
						<h4><i class="icon iconfont icon-top text-color"></i> 抢先看资源</h4>
					</div>
					<div class="item">
						<ul class="clearfix">
						<?php $result = mysql_query('select * from xtcms_vod order by d_id desc');
		while ($row = mysql_fetch_array($result)){
$cc="./bplay.php?bf=";
								$dd="../../bplay/";
if ($xtcms_wei==1){
$ccb=$dd.$row['d_id'];
}
else{
$ccb=$cc.$row['d_id'];	
}
			echo '<li class="text-overflow"><span class="pull-right text-color">->></span><a href="'.$ccb.'" title="'.$row['d_name'].'">
						<em class="number active ">抢先</em>'.$row['d_name'].'</a></li>';
		}?>			

						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<span class="ff-hits" id="ff-hits-insert" data-id="37432" data-sid="vod" data-type="insert"></span>		<script>
	    var swiper = new Swiper('.hy-switch', {
	        pagination: '.swiper-pagination',
	        paginationClickable: true,
	        slidesPerView: 5,
	        spaceBetween: 0,
	        nextButton: '.swiper-button-next',
	        prevButton: '.swiper-button-prev',
	        breakpoints: {
	            1200: {
	                slidesPerView: 4,
	                spaceBetween: 0
	            },
	            767: {
	                slidesPerView: 3,
	                spaceBetween: 0					            
	            }
	        }
	    });	 
	    </script>
<span class="ff-record-set" data-sid="1" data-id="37432" data-id-sid="1" data-id-pid="1">
</span>



<?php include 'footer.php'; ?>
