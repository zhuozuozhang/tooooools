	<div class="sidebar">
<div class="widget widget-textasst"><a class="style02" href="" target="_blank"><strong>关注微信</strong><div class="article-wechats">
      </br>            <img src="<?php echo $xtcms_weixin;?>">
           
    </div> </a></div>
<?php
						$result = mysql_query('select * from xtcms_ad where catid=4');
						while($row = mysql_fetch_array($result)){
						?>
<div class="widget widget_text"><h3><?php echo $row['title']?></h3>			
<div class="textwidget"><a href="<?php echo $row['url']?>" target="_blank"><img src="<?php echo $row['pic']?>" /></a></div>
						</div><?php
						}
						?></div>	
   
		
		<script>
var ifh=$('.sidebar');
if(ifh.height()<10){
$('.content').css("width","100%");
}else{
}</script>