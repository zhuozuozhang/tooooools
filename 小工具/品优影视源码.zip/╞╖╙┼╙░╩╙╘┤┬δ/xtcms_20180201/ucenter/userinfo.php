<?php include('../system/inc.php');
if(!isset($_SESSION['user_name'])){
		alert_href('请登陆后进入','../login.php');
	};
if ( isset($_POST['save']) ) {
	null_back($_POST['u_password'],'请填写登录密码');
	$result = mysql_query('select * from xtcms_user where u_name="'.$_SESSION['user_name'].'"');
    if($row = mysql_fetch_array($result)){
if ($_POST['u_password'] != $row['u_password']) {
$_data['u_password'] = md5($_POST['u_password']);
	}
	else{
$_data['u_password'] = $_POST['u_password'];	
	}
	}

	$_data['u_email'] = $_POST['u_email'];
	$_data['u_phone'] = $_POST['u_phone'];
	$_data['u_qq'] = $_POST['u_qq'];
$sql = 'update xtcms_user set '.arrtoupdate($_data).' where u_name="'.$_SESSION['user_name'].'"';
	if (mysql_query($sql)) {
		alert_href('修改成功!','userinfo.php');
	} else {
		alert_back('修改失败!');
	}
}
?>
<?php
$result = mysql_query('select * from xtcms_user where u_name="'.$_SESSION['user_name'].'"');
$row = mysql_fetch_array($result)
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>会员中心</title>

<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/datepicker3.css" rel="stylesheet">
<link href="css/styles.css" rel="stylesheet">

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->

</head>

<body>
<?php include('head.php');?>
<?php include('left.php');?>
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="../"><span class="glyphicon glyphicon-home"></span></a></li>
				<li class="active">资料修改</li>
			</ol>
		</div><!--/.row-->
		
<?php
					$result = mysql_query('select * from xtcms_user where u_name="'.$_SESSION['user_name'].'"');
					if($row){
					?>
		
		<div class="row">
			<div class="col-md-8">
				<div class="panel panel-default">
					<div class="panel-heading"><span class="glyphicon glyphicon-envelope"></span>个人资料修改</div>
					<div class="panel-body">
						<form class="form-horizontal" action="" method="post">
							<fieldset>
								<!-- Name input-->
								<div class="form-group">
									<label class="col-md-3 control-label" for="name">用户名</label>
									<div class="col-md-9" style="line-height:35px">
									<input id="u_name" name="u_name" type="text" class="form-control" value="<?php echo $row['u_name'];?>" disabled>
									</div>
								</div>
							
								<!-- Email input-->
								<div class="form-group">
									<label class="col-md-3 control-label" for="email">密码</label>
									<div class="col-md-9" style="line-height:35px">
										<input name="u_password" type="password" class="form-control" value="<?php echo $row['u_password'];?>">
									</div>
								</div>
<div class="form-group">
									<label class="col-md-3 control-label" for="message">手机号码</label>
									<div class="col-md-9" style="line-height:35px">
							<input id="u_phone" name="u_phone" type="text" class="form-control" placeholder="请输入您的手机号码" value="<?php echo $row['u_phone'];?>">
									</div>
								</div>
								<div class="form-group">
									<label class="col-md-3 control-label" for="message">QQ</label>
									<div class="col-md-9" style="line-height:35px">
							<input id="u_qq" name="u_qq" type="text" class="form-control" placeholder="请输入您的QQ" value="<?php echo $row['u_qq'];?>">
									</div>
								</div>
								
								
															<div class="form-group">
									<label class="col-md-3 control-label" for="message">email</label>
									<div class="col-md-9" style="line-height:35px">
							<input id="u_email" name="u_email" type="text" class="form-control" placeholder="请输入您的邮箱" value="<?php echo $row['u_email'];?>">
									</div>
								</div>
											
								<!-- Form actions -->
										<div class="form-group">
									<div class="col-md-12 widget-right">
										<button type="submit" name="save" class="btn btn-default btn-md pull-right">保存</button>
									</div>
								</div>
							</fieldset>
						</form>
					</div>
				</div>
				
<?php
						}
					?>
				
			</div><!--/.col-->
			
			<div class="col-md-4">
			
				<div class="panel panel-red">
					<div class="panel-heading dark-overlay"><span class="glyphicon glyphicon-calendar"></span>日历</div>
					<div class="panel-body">
						<div id="calendar"></div>
					</div>
				</div>
				

								
			</div><!--/.col-->
		</div><!--/.row-->
	</div>	<!--/.main-->

	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script>
		$('#calendar').datepicker({
		});

		!function ($) {
		    $(document).on("click","ul.nav li.parent > a > span.icon", function(){          
		        $(this).find('em:first').toggleClass("glyphicon-minus");      
		    }); 
		    $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
		}(window.jQuery);

		$(window).on('resize', function () {
		  if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
		})
		$(window).on('resize', function () {
		  if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
		})
	</script>	
</body>

</html>
