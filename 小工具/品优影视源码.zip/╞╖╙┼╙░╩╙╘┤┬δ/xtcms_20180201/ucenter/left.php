		
	<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
		<ul class="nav menu">
			<li ><a href="index.php"><span class="glyphicon glyphicon-dashboard"></span>个人信息</a></li>
			<li><a href="userinfo.php"><span class="glyphicon glyphicon-pencil"></span>资料修改</a></li>
			<li><a href="chongzhi.php"><span class="glyphicon glyphicon-stats"></span>充值卡充值</a></li>
			<li><a href="<?php echo $xtcms_qqun;?>" target="_blank"><span class="glyphicon glyphicon-stats"></span>充值卡购买</a></li>
			<li><a href="mingxi.php"><span class="glyphicon glyphicon-list-alt"></span>升级会员组</a></li>
          <?
          if($row['u_group'] == 2){?>
          	<li><a href="tequan.php"><span class="glyphicon glyphicon-list-alt"></span>黄金会员特权</a></li>
          <?}?>
         	


			<li role="presentation" class="divider"></li>
			<li><a href="exit.php" onClick="return confirm('确定要退出吗？')"><span class="glyphicon glyphicon-user"></span>退出登录</a></li>
		</ul>
		<div class="attribution"> <a href="http://www.hez70.com/" target="_blank" title="筱瞳CMS">筱瞳CMS</a></div>
	</div><!--/.sidebar-->
