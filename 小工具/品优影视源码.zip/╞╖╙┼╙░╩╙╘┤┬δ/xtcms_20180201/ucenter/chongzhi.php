<?php include('../system/inc.php');
if(!isset($_SESSION['user_name'])){
		alert_href('请登陆后进入','../login.php');
	};
if ( isset($_POST['save']) ) {
null_back($_POST['c_number'],'请填写充值卡号');

//判定卡号是否存在
$result = mysql_query('select * from xtcms_user_card where c_number = "'.$_POST['c_number'].'" and c_used=0');
if($row = mysql_fetch_array($result)){
$_data['u_points'] = $row['c_money']+$_POST['u_points'];
$sql = 'update xtcms_user set '.arrtoupdate($_data).' where u_name="'.$_SESSION['user_name'].'"';	
	if (mysql_query($sql)) {
$data['c_used'] = 1;
$data['c_user'] = $_SESSION['user_name'];
$data['c_usetime'] =time();

$sql = 'update xtcms_user_card set '.arrtoupdate($data).' where c_number = "'.$_POST['c_number'].'"';	
if (mysql_query($sql)) {
		alert_href('充值成功!','chongzhi.php');
}	} else {
		alert_back('充值失败!');
	}
		

}
else{
	alert_back('卡号不存在,或者已经使用');
	}
}
?>
		
<?php
$result = mysql_query('select * from xtcms_user where u_name="'.$_SESSION['user_name'].'"');
$row = mysql_fetch_array($result)
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>会员中心</title>

<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/datepicker3.css" rel="stylesheet">
<link href="css/styles.css" rel="stylesheet">

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->

</head>

<body>
<?php include('head.php');?>
<?php include('left.php');?>
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="../"><span class="glyphicon glyphicon-home"></span></a></li>
				<li class="active">卡密充值</li>
			</ol>
		</div><!--/.row-->

			<?
      if($row){?>
		<div class="row">
			<div class="col-md-8">
				<div class="panel panel-default">
					<div class="panel-heading"><span class="glyphicon glyphicon-envelope"></span>卡密充值</div>
					<div class="panel-body">
						<form class="form-horizontal" action="" method="post">
						<input name="u_points" type="hidden" class="form-control" value="<?php echo $row['u_points'];?>">
							<fieldset>
								<!-- Name input-->
								<div class="form-group">
									<label class="col-md-3 control-label" for="name">用户名</label>
									<div class="col-md-9" style="line-height:35px">
									<input id="u_name" name="u_name" type="text" class="form-control" value="<?php echo $row['u_name'];?>" disabled>
									</div>
								</div>
							
								<!-- Email input-->
								<div class="form-group">
									<label class="col-md-3 control-label" for="email">充值卡号</label>
									<div class="col-md-9" style="line-height:35px">
										<input name="c_number" type="text" class="form-control" value="">
									</div>
								</div>
								

											
								<!-- Form actions -->
										<div class="form-group">
									<div class="col-md-12 widget-right">
										<button type="submit" name="save" class="btn btn-default btn-md pull-right">提交</button>
									</div>
								</div>
							</fieldset>
						</form>
					</div>
				</div>
				
<?php
						}
					?>
				
			</div><!--/.col-->
			
			<div class="col-md-4">
			
				<div class="panel panel-red">
					<div class="panel-heading dark-overlay"><span class="glyphicon glyphicon-calendar"></span>日历</div>
					<div class="panel-body">
						<div id="calendar"></div>
					</div>
				</div>
				

								
			</div><!--/.col-->
		</div><!--/.row-->
	</div>	<!--/.main-->

	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script>
		$('#calendar').datepicker({
		});

		!function ($) {
		    $(document).on("click","ul.nav li.parent > a > span.icon", function(){          
		        $(this).find('em:first').toggleClass("glyphicon-minus");      
		    }); 
		    $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
		}(window.jQuery);

		$(window).on('resize', function () {
		  if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
		})
		$(window).on('resize', function () {
		  if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
		})
	</script>	
</body>

</html>
