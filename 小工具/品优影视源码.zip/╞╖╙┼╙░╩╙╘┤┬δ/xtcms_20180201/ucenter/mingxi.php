<?php include('../system/inc.php');
if(!isset($_SESSION['user_name'])){
		alert_href('请登陆后进入','../login.php');
	};
if ( isset($_POST['save']) ) {

//判定会员组别
$result = mysql_query('select * from xtcms_user where u_name="'.$_SESSION['user_name'].'"');
if($row = mysql_fetch_array($result)){
if ($_POST['u_group'] <= $row['u_group']) {
	alert_back('会员组不能降级使用!');
}
$u_points=$row['u_points'];
$use= mysql_query('select * from xtcms_user_group where ug_id="'.$_POST['u_group'].'"');
if($row1 = mysql_fetch_array($use)){
$ug_upgrade=$row1['ug_upgrade'];
}

if ($u_points>=$ug_upgrade) {
$_data['u_points'] =$u_points-$ug_upgrade;
$_data['u_group'] =$_POST['u_group'];
$sql = 'update xtcms_user set '.arrtoupdate($_data).' where u_name="'.$_SESSION['user_name'].'"';
if (mysql_query($sql)) {
alert_href('升级成功!','mingxi.php');
}

}
	else{
	alert_back('积分不足请充值!');
}
}
}
?>
<?php
$result = mysql_query('select * from xtcms_user where u_name="'.$_SESSION['user_name'].'"');
$row = mysql_fetch_array($result)
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>会员中心</title>

<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/datepicker3.css" rel="stylesheet">
<link href="css/styles.css" rel="stylesheet">

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->

</head>

<body>
<?php include('head.php');?>
<?php include('left.php');?>
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="../"><span class="glyphicon glyphicon-home"></span></a></li>
				<li class="active">升级会员组</li>
			</ol>
		</div><!--/.row-->
		

			<?   if($row){?>
		<div class="row">
			<div class="col-md-8">
				<div class="panel panel-default">
					<div class="panel-heading"><span class="glyphicon glyphicon-envelope"></span>升级会员组</div>
					<div class="panel-body">
						<form class="form-horizontal" action="" method="post">
						<input name="u_points" type="hidden" class="form-control" value="<?php echo $row['u_points'];?>">
							<fieldset>
								<!-- Name input-->
							<div class="form-group">
									<label class="col-md-3 control-label" for="message">所属会员组</label>
									<div class="col-md-9" style="line-height:35px">
						<?php
							$result = mysql_query('select * from xtcms_user_group where ug_id='.$row['u_group'].'');
							while($row1 = mysql_fetch_array($result)){
						?>
						<?php echo $row1['ug_name']?>
<?php
							}
						?>
									</div>
								</div>
							
								<!-- Email input-->
								<div class="form-group">
									<label class="col-md-3 control-label" for="email">请选择要升级会员</label>
									<div class="col-md-9" style="line-height:35px">
			<select id="u_group" class="input" name="u_group">
													<?php
							$result = mysql_query('select * from xtcms_user_group');
							while($row = mysql_fetch_array($result)){
						?>
						<option value="<?php echo $row['ug_id']?>"><?php echo $row['ug_name']?>[<?php echo $row['ug_upgrade']?>积分]</option>
<?php
							}
						?>
									</select>
									</div>
								</div>
								

											
								<!-- Form actions -->
										<div class="form-group">
									<div class="col-md-12 widget-right">
										<button type="submit" name="save" class="btn btn-default btn-md pull-right">提交</button>
									</div>
								</div>
							</fieldset>
						</form>
					</div>
				</div>
				
<?php
						}
					?>
				
			</div><!--/.col-->
			
			<div class="col-md-4">
			
				<div class="panel panel-red">
					<div class="panel-heading dark-overlay"><span class="glyphicon glyphicon-calendar"></span>日历</div>
					<div class="panel-body">
						<div id="calendar"></div>
					</div>
				</div>
				

								
			</div><!--/.col-->
		</div><!--/.row-->
	</div>	<!--/.main-->

	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script>
		$('#calendar').datepicker({
		});

		!function ($) {
		    $(document).on("click","ul.nav li.parent > a > span.icon", function(){          
		        $(this).find('em:first').toggleClass("glyphicon-minus");      
		    }); 
		    $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
		}(window.jQuery);

		$(window).on('resize', function () {
		  if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
		})
		$(window).on('resize', function () {
		  if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
		})
	</script>	
</body>

</html>
