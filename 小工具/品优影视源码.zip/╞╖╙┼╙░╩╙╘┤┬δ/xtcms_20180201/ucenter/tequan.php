<?php include('../system/inc.php');
if(!isset($_SESSION['user_name'])){
		alert_href('请登陆后进入','../login.php');
	};
	?>
<?php
$result = mysql_query('select * from xtcms_user where u_name="'.$_SESSION['user_name'].'"');
$row = mysql_fetch_array($result)
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>黄金会员特权</title>

<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/datepicker3.css" rel="stylesheet">
<link href="css/styles.css" rel="stylesheet">

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->

</head>

<body>
<?php include('head.php');?>
<?php include('left.php');?>
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="../"><span class="glyphicon glyphicon-home"></span></a></li>
				<li class="active">黄金会员特权</li>
			</ol>
		</div><!--/.row-->
		<?
      if($row['u_group'] == 2){?>
		<div class="row">
          
			<div class="col-md-8" style="width: 100%;">
				<div class="panel panel-default">
					<div class="panel-heading"><span class="glyphicon glyphicon-envelope"></span>等待开发</div>
				</div>							
			</div>
          	
          
          
		</div><!--/.row-->
	</div>	<!--/.main-->
	<?}else{
      
      echo "没有权限";
      }?>	
		
	</div>	

</body>

</html>
