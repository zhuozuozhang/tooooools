<?php include('../system/inc.php');
if(!isset($_SESSION['user_name'])){
		alert_href('请登陆后进入','../login.php');
	};
	?>
<?php
$result = mysql_query('select * from xtcms_user where u_name="'.$_SESSION['user_name'].'"');
$row = mysql_fetch_array($result)
?>
		
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>会员中心</title>

<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/datepicker3.css" rel="stylesheet">
<link href="css/styles.css" rel="stylesheet">

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->

</head>

<body>
<?php include('head.php');?>
<?php include('left.php');?>
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="../"><span class="glyphicon glyphicon-home"></span></a></li>
				<li class="active">个人信息</li>
			</ol>
		</div><!--/.row-->
		
	<?
      if($row){?>
		<div class="row">
			<div class="col-md-8">
				<div class="panel panel-default">
					<div class="panel-heading"><span class="glyphicon glyphicon-envelope"></span>个人信息</div>
					<div class="panel-body">
						<form class="form-horizontal" action="" method="post">
							<fieldset>
								<!-- Name input-->
								<div class="form-group">
									<label class="col-md-3 control-label" for="name">用户名</label>
									<div class="col-md-9" style="line-height:35px">
									<?php echo $row['u_name'];?>
									</div>
								</div>
							
								<!-- Email input-->
								<div class="form-group">
									<label class="col-md-3 control-label" for="email">状态</label>
									<div class="col-md-9" style="line-height:35px">
										<?php echo ($row['u_status'] == 1 ? '启用':'');?><?php echo ($row['u_status'] == 0 ? '禁用':'');?>
									</div>
								</div>
								
								<!-- Message body -->
								<div class="form-group">
									<label class="col-md-3 control-label" for="message">会员组</label>
									<div class="col-md-9" style="line-height:35px">
						<?php
							$result = mysql_query('select * from xtcms_user_group where ug_id='.$row['u_group'].'');
							while($row1 = mysql_fetch_array($result)){
						?>
						<?php echo $row1['ug_name']?>
<?php
							}
						?>
									</div>
								</div>
								<!-- Message body -->
								<div class="form-group">
									<label class="col-md-3 control-label" for="message">积分</label>
									<div class="col-md-9" style="line-height:35px">
										<?php echo $row['u_points'];?>
									</div>
								</div>
															<div class="form-group">
									<label class="col-md-3 control-label" for="message">email</label>
									<div class="col-md-9" style="line-height:35px">
							<?php echo $row['u_email'];?>
									</div>
								</div>
								<div class="form-group">
									<label class="col-md-3 control-label" for="message">登录时间</label>
									<div class="col-md-9" style="line-height:35px">
					<?php echo $row['u_logintime'];?>
									</div>
								</div>
								<div class="form-group">
									<label class="col-md-3 control-label" for="message">登陆ip</label>
									<div class="col-md-9" style="line-height:35px">
<?php echo $row['u_loginip'];?>
									</div>
								</div>								
								<!-- Form actions -->
		
							</fieldset>
						</form>
					</div>
				</div>
				
<?php
						}
					?>
				
			</div><!--/.col-->
			
			<div class="col-md-4">
			
				<div class="panel panel-red">
					<div class="panel-heading dark-overlay"><span class="glyphicon glyphicon-calendar"></span>日历</div>
					<div class="panel-body">
						<div id="calendar"></div>
					</div>
				</div>
				

								
			</div><!--/.col-->
		</div><!--/.row-->
	</div>	<!--/.main-->

	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script>
		$('#calendar').datepicker({
		});

		!function ($) {
		    $(document).on("click","ul.nav li.parent > a > span.icon", function(){          
		        $(this).find('em:first').toggleClass("glyphicon-minus");      
		    }); 
		    $(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
		}(window.jQuery);

		$(window).on('resize', function () {
		  if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
		})
		$(window).on('resize', function () {
		  if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
		})
	</script>	
</body>

</html>
