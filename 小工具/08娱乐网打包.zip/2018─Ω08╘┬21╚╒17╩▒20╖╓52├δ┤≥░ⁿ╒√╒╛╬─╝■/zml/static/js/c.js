! function(H, E) {
    H.DeviceOrientationEvent && H.addEventListener("deviceorientation", function(H) {
        H.beta && H.gamma && (E.onmousemove = null);
        var C = (H.beta - 20) / 3,
            F = -H.gamma / 3;
        C = Math.min(C, 20), C = Math.max(C, -20), F = Math.min(F, 20), F = Math.max(F, -20), D(C, F)
    }, !1);
    var D = function(H, E) {
        test.style.cssText = "-webkit-transform:rotateX(" + H + "deg) rotateY(" + E + "deg);-ms-transform:rotateX(" + H + "deg) rotateY(" + E + "deg);transform:rotateX(" + H + "deg) rotateY(" + E + "deg);"
    }, C = E.documentElement;
    BODY = E.body, E.onmousemove = function(H) {
        var E = H.clientX - BODY.offsetWidth / 2;
        E /= 100;
        var F = H.clientY - C.clientHeight / 2;
        F /= 100, F = -F, D(F, E)
    };
    var F = [0, 700, 2e3, 3100, 3800];
    setTimeout(function() {
        H.onscroll = function() {
            for (var H, E = 0; E < F.length; E++)
                if (H = F[E], H > Math.max(C.scrollTop, BODY.scrollTop) + C.clientHeight / 2) return C.setAttribute("step", E)
        }, H.onscroll()
    }, 1e3)
}(this, document);
var selectDatacenter = function(A) {};