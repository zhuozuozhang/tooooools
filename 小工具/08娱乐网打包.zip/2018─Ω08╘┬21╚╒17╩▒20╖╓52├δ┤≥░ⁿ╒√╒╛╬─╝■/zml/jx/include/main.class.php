<?php
/*########################################################
# xypaly 智能视频解析整合接口 X by 09dh.cn
# 官方网站: http://09dh.cn
# 源码获取：http://www.08yl.cn
# 模块功能：程序核心，jsonp服务端
#########################################################*/

//不显示读取错误
ini_set("error_reporting","E_ALL & ~E_NOTICE");

//拼接js参数
function enjs($_play){
$schwhere = '';
foreach( $_play as $k=>$v) {$schwhere.= "&$k=".escape($v);};
//foreach( $_play as $k=>$v) {$schwhere.= "&$k=".$v;};
return base64_encode(ltrim($schwhere,'&'));
}
/** 
 * js escape php 实现 
 * @param $string           the sting want to be escaped 
 * @param $in_encoding       
 * @param $out_encoding      
 */ 
function escape($string, $in_encoding = 'UTF-8',$out_encoding = 'UCS-2') { 
    $return = ''; 
    if (function_exists('mb_get_info')) { 
        for($x = 0; $x < mb_strlen ( $string, $in_encoding ); $x ++) { 
            $str = mb_substr ( $string, $x, 1, $in_encoding ); 
            if (strlen ( $str ) > 1) { // 多字节字符 
                $return .= '%u' . strtoupper ( bin2hex ( mb_convert_encoding ( $str, $out_encoding, $in_encoding ) ) ); 
            } else { 
                $return .= '%' . strtoupper ( bin2hex ( $str ) ); 
            } 
        } 
    } 
    return $return; 
}

//防盗链判断，即授权域名
function is_referer(){
 if(defined('REFERER_URL')==false){return true;}else if(REFERER_URL==""){return true;} 
	@$host = parse_url($_SERVER['HTTP_REFERER'],PHP_URL_HOST);
	@$ymarr = explode("|",REFERER_URL);
    if(in_array($host,$ymarr)){return true;}
    return false;
}

//API数据加密，只能本站调用
function lsreferer(){
    global $play;		
    if(defined('ENCODE_URL')==false || $play['debug']!='0'){return true;}else if(ENCODE_URL==""){return true;}
	@$host = parse_url($_SERVER['HTTP_REFERER'],PHP_URL_HOST);
	@$ymarr = explode("|",ENCODE_URL);
    if(in_array($host,$ymarr)){return true;}
    return false;
}
//检测字符串组的字符在字符串中是否存在,对大小写不敏感
function findstrs($string,$strs,$separator="|"){
	$ymarr = explode($separator,$strs);
	foreach ($ymarr as  $val) {  
      if(stripos($string,$val)){return true;}
    }  	 
    return false;
}

//获取顶级域名
function get_host(){
    @ $url   = $_SERVER['HTTP_HOST'];
    @$data = explode('.', $url);
    $co_ta = count($data);
    //判断是否是双后缀
    $zi_tow = true;
    $host_cn = 'com.cn,net.cn,org.cn,gov.cn';
    @$host_cn = explode(',', $host_cn);
    foreach($host_cn as $host){
        if(strpos($url,$host)){
            $zi_tow = false;
        }
    }
    //如果是返回FALSE ，如果不是返回true
    if($zi_tow == true){
        $host = $data[$co_ta-2].'.'.$data[$co_ta-1];
    }else{
        $host = $data[$co_ta-3].'.'.$data[$co_ta-2].'.'.$data[$co_ta-1];
    }
  return $host;
}

//获取远程内容
function geturl($url,$timeout = 10) {  
    $user_agent = "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36";  
    $curl = curl_init();                                        //初始化 curl
    curl_setopt($curl, CURLOPT_URL, $url);                      //要访问网页 URL 地址
	curl_setopt($curl, CURLOPT_USERAGENT,$user_agent);		   //模拟用户浏览器信息 
    curl_setopt($curl, CURLOPT_REFERER,$url) ;               //伪装网页来源 URL
    curl_setopt($curl, CURLOPT_AUTOREFERER, 1);                //当Location:重定向时，自动设置header中的Referer:信息                   
    curl_setopt($curl, CURLOPT_TIMEOUT, $timeout);             //数据传输的最大允许时间 
    curl_setopt($curl, CURLOPT_HEADER, 0);                     //不返回 header 部分
   curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);            //返回字符串，而非直接输出到屏幕上
	curl_setopt($curl, CURLOPT_FOLLOWLOCATION,1);             //跟踪爬取重定向页面
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, '0');        //不检查 SSL 证书来源
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, '0');        //不检查 证书中 SSL 加密算法是否存在
	curl_setopt($curl, CURLOPT_ENCODING, '');	          //解决网页乱码问题
    $data = curl_exec($curl);
    curl_close($curl);
    return $data;
}

//编码转换，转换为utf-8编码
function utf8($title) {						
		$encode = mb_detect_encoding($title, array('GB2312','GBK','UTF-8', 'CP936')); //得到字符串编码
		if ( $encode != 'CP936' && $encode != 'UTF-8') {
			$title=iconv($encode, 'UTF-8', $title);
		}			
		return $title;	
	}

?>
