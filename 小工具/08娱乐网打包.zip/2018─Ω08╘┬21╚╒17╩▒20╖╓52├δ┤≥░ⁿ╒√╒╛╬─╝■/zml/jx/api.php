<?php
/*########################################################
# xypaly 智能视频解析整合接口 X by 09dh.cn
# 官方网站: http://09dh.cn
# 源码获取：http://www.08yl.cn
# 模块功能：程序核心，jsonp服务端
#########################################################*/
//加载配置文件
require_once 'config.php';



//输出json格式文件
header('content-type:application/json;charset=utf8');
//header("Content-Disposition:attachment;filename='su.js'");

//取传入参数，支持POST和GET

foreach   ($_REQUEST as $k=>$v)  
{
	$$k=trim(urldecode($v));	
}
$cb= isset($cb) && $cb ? $cb:'';
$url=isset($url) && $url ? $url:'';
$wd=isset($wd) && $wd ? $wd:'';
$tp=isset($tp) && $tp ? $tp:'';
$line = isset($line) && $line ? $line:'0';
$id=isset($id) ? $id:'';
$flag=isset($flag) ? $flag:'';

$info=array('success'=>0,'code'=>0);

$myObj = new Jsonp();

//API 接口
 if($tp=='getnum'){echo sizeof($jx_url);exit;}
 if($tp=='set'){ if (setcookie("url_num", $line, time()+3600*timecookie)); exit;} 	 
 if($tp=='getset'){exit(isset($_COOKIE["url_num"]) ? $_COOKIE["url_num"] :'0');}
 
 //如果需要域名限制，可以屏蔽。
 if($tp=='img'){exit( $myObj->getimgx());}
 if($tp=='xml' && $wd!=''){exit($myObj->getname_xml($API_URL,$wd,$info));}
 
 	  
//模块输出加密
  if(!lsreferer()){
    header('HTTP/1.1 404 Forbidden');
    exit('404,文件未找到');
  }

if ($tp!=''){
  	
    if($tp=='line'){ 
         
    $info['type']="line";
    $info['val']=$myObj->lsUserAgen('xysoft');       
      if(isset($jx_url)&& sizeof($jx_url)>0){
	   $info['success']=1;
	   $info['info']=$jx_url;
      }else{
	   output_exit("参数错误，请联系东辉影视管理员！");	  
      }
   
    }else if($tp=='lsurl' && $url!=''){
	   $info['type']="lsurl";
	   $info['val']=$url;
	   if($myObj->lsurl($url)){		  
		  $info['success']=1;
          $info['info']=true;		  
	   }else{		  
		  output_exit("参数错误，请联系东辉影视管理员！");		  
	    }           	
  
    }else if($tp=='all'){
	   
	    if ($url!='' || $wd!=''){ 
		
		$ret=$myObj->getvideo($API_URL,$url,$wd,$info,true);		
		
		  if(!$ret){ output_exit("未搜索到资源!请联系东辉影视管理员！");}
	    
		}
    
    }else if($tp=='wd' && $wd!=''){	   	   
	       $ret=$myObj->getname($API_URL,$wd,$info);         
		   if(!$ret){ output_exit("未搜索到资源!请联系东辉影视管理员！");}		   
    
	}else if($tp=='xml' && $wd!=''){

           $ret=$myObj->getname_xml($API_URL,$wd,$info);         	
	       exit();
	
	}else if($tp=='img' ){
		 
		 $ret=$myObj->getimg();         	
	     	

	}else{		
		output_exit("参数错误，请联系东辉影视管理员！");				
	
	} 	 
 
 
 }else if($id!=""&& $flag!="") {	 	     
       $ret=$myObj->getvideobyid($API_URL,$flag,$id,$info);	   
	   if(!$ret){output_exit("未搜索到资源!请联系东辉影视管理员！");}	   	 
 }else{		 
		if ($url=='' && $wd==''){output_exit("参数错误，请联系东辉影视管理员！");		}     
   	    $num=(int)$_COOKIE["list_num"];	  	   
	    $ret=$myObj->getvideo($API_URL,$url,$wd,$info,false,$num);	
	   if(!$ret){output_exit("未搜索到资源!请联系东辉影视管理员！");}
      }        
  echo $myObj->out_json($cb,$info);   
  
class Jsonp
{	   
    public function lsurl($url,$timeout=10)		
	{		      
	  $ch = curl_init();
	  curl_setopt($ch,CURLOPT_URL,$url);    //设置url
      curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout); //超时时间
	  curl_setopt($ch,CURLOPT_FOLLOWLOCATION,true);  //启用301重定向跟踪
      curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);   //不显示结果
      curl_setopt($ch, CURLOPT_HEADER, 0); //包含头信息
	  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, '0');
	  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, '0');
     $flg=!(curl_exec($ch)==false);
	 //return $code= curl_getinfo($ch,CURLINFO_HTTP_CODE);
	 curl_close($ch);
	 return $flg;     
     } 
 
 //搜索显示全部视频
public function getname($API,$WD,&$DATA){ 
  global $play; 
  for($i=0;$i<sizeof($API);$i++){ 
        $data=geturl($API[$i]."?wd=".$WD);   		
        if(!$data){break;}		
		$xml = simplexml_load_string($data);  
		  foreach($xml->list->video as $video)	    
	    {   			 
			 $id=(string)$video->id;
			 $video=(string)$video->name;				 
			 if ($play['imgoff']=='1'){
			 $img=geturl($API[$i]."?ac=videolist&ids=".$id);
			 $img = preg_match('!<pic>(.*?)</pic>!i', $img, $matches) ? trim($matches[1]) : '';	
			 }
			 $info[]=array('flag'=>$i,'id'=>$id,'title'=>$video,'img'=>$img);						 						 
			 $ret=true;            			  				   
	    }      
  }
   if ($ret ){		  			 
	     $DATA['success']=1; 
		 $DATA['wd']=$WD; 
         $DATA['info']= $info; 		 	             	          		   		   	   
	}	
   return $ret;
}

public function getname_xml($API,$WD,&$DATA){ 
  global $play;
  for($i=0;$i<sizeof($API);$i++){ 
        $data=geturl($API[$i]."?wd=".$WD);   		
        if(!$data){break;}		
		$xml = simplexml_load_string($data);  		 
		 foreach($xml->list->video as $video)	    
	    {   			 
			 $id=(string)$video->id;
			 $video=(string)$video->name;	             			 
			 
			 
			 if ($play['imgoff']=='1'){
			 $img=geturl($API[$i]."?ac=videolist&ids=".$id);
			 $img = preg_match('!<pic>(.*?)</pic>!i', $img, $matches) ? trim($matches[1]) : '';			 
			 }
			 echo '["flag":'.$i.',"id":'.$id.',"title":"'.urlencode($video).'","img":"'.$img.'"]';					 						 			 			
			$ret=true;            			  				   
	   } 		
  }
 
}

//取随机美女图片

public function getimg($num=100){  
    $url="http://image.baidu.com/channel/listjson?pn=0&rn=".(string)$num."&tag1=美女&tag2=全部&ie=utf8";
	
	//$url="https://uploadbeta.com/api/pictures/random/?key=%E6%8E%A8%E5%A5%B3%E9%83%8E"
	
	$data=geturl($url);$data=json_decode($data,true);
	$i=rand(0,99);$img=$data['data'][$i]['image_url'];	
	if ($img!=""){	 
		exit($img);				
	}		
	return false;
	
}

public function getimgx(){  
	$url="https://uploadbeta.com/api/pictures/random/?key=%E6%8E%A8%E5%A5%B3%E9%83%8E";
	exit($url);
}


//取ID对应视频信息
public function getvideobyid($API,$FLAG,$ID,&$DATA){ 
    if ($ID==0 || $FLAG>=sizeof($API)){				
		return false;		
	}    
    $data=geturl($API[$FLAG]."?ac=videolist&ids=".$ID);
	$DATA['id']=$ID; 
    $xml = simplexml_load_string($data);     
    if(!$xml){		
		return false;
	}	
	 $DATA['title']=(string)$xml->list->video->name;

   //echo  $data;

	  foreach($xml->list->video->dl->dd as $video)	    
	  {        	        
		    $flag=(string)$video->attributes();        	      
	         if($flag!=""){
			 $vod=explode("#",(string)$video);
			  //检测是否存在名称	 
			  foreach($vod as &$mov){if(!strpos($mov,"$")){$mov="高清$".$mov;}}				 			  				  			  
			  $info[]=array('flag'=>$flag,'part'=>sizeof($vod),'video'=>$vod,);        
		
              $ret=true; 
			}
	   }   

    if ($ret){	
	   
		 //结果按集数降序排列。        
		  foreach ( $info as $key => $row ){		   
           $num1[$key] = $row ['part'];			   
          } 
         array_multisort($num1,SORT_DESC ,$info);			   	
		 $DATA['success']=1; 
		 $DATA['part']=1;
		 $DATA['play']=$DATA['info'][0]['flag'];		  
         $vod=$info[0]['video'][0];	$vod=explode('$', $vod); $DATA['url']=$vod[1];		
         $DATA['info']=$info;		
	}	 
	return $ret;
	   	   	   
}
 
//取资源信息
public function getvideo($API,$URL,$WD,&$DATA,$ALL=false,$i=0){
 
 if ($WD==''){
$data=geturl($URL);if ($data==""){return false;};
$title= preg_match('!<title>(.*?)</title>!i',$data, $matches) ? trim($matches[1]) : '';if ($title==""){return false;};

//编码转换
$title=utf8($title);

//$code= preg_match('!meta.*? charset=(?:"|)(.*?)"!i', $data, $matches)? trim($matches[1]) : 'utf-8';
//if($code!='utf-8'){$title = iconv($code,"utf-8",$title);}
 
$name = preg_match('!^(.*?)(?=-|—|_|——|-)!i', $title, $matches) ? trim($matches[1]) : '';$num=1;
if (preg_match('!^(.*?)(?:第| )(\d+)(?:集|)!i', $title, $matches)){ $name=trim($matches[1]);$num=(int)$matches[2];}


if ($name==""){return false;}

//标题过滤
if (preg_match('!^(.*?)(?:（| )!i', $name, $matches)){$name=trim($matches[1]);}
$find = array("《","》","【","】","（","）");$name=str_replace($find,"",$name);


//echo "网页标题：".$title."<br>" ;echo "视频名称：".$name."<br>" ; echo "视频集数：".$num."<br>" ;

$DATA['title']=$name;$DATA['part']=$num;

}

$ret=false;

if($i>=sizeof($API)){$i=0;}

 for($i;$i<sizeof($API);$i++){
 //foreach  ($API as $value) {   
	 $data=geturl($API[$i]."?wd=".urlencode($name));   
     $id = preg_match('!<id>(\d*?)</id>!i', $data, $matches) ? trim($matches[1]) : '';
// echo "视频UID：".$id."<br>" ;
	if ($id!=''){	
	   //取视频信息
      $data=geturl($API[$i]."?ac=videolist&ids=".$id);	  	  
	  //echo $data;	  
      $xml = simplexml_load_string($data);     
	  foreach($xml->list->video->dl->dd as $video)	    
	  {   
       //echo $video;	   
	   $flag=(string)$video->attributes();        
	       if(API_TYPE=="" || findstrs($flag,API_TYPE))
	        {	   	         			  
			  $vod=explode("#",(string)$video);
              $info[]=array('flag'=>$flag,'site'=>$i,'part'=>sizeof($vod),'video'=>$vod,);
              $ret=true;            			  
			}	   
	  }        	  	   
        if($ret && !$ALL && sizeof($info[0]['video'])>=$num ){break;};	     
	   
	  }   	// 单资源循环结束  
	  		  		     	  	 
   }   // 全部资源循环结束    
     if ($ret){		  
		 
		 //结果先按集数降序排列再按资源站先后顺序排列。        
		  foreach ( $info as $key => $row ){		   
           $num1[$key] = $row ['part'];
		   $num2[$key] = $row ['site'];		   
          } 
          array_multisort($num1,SORT_DESC ,$num2,SORT_ASC,$info);	
		   
          $DATA['success']=1; 
		   
		 //检查集数
		 if(sizeof($info[0]['video'])<$num){ return false;}			 
		 
		//输出数据
		$DATA['code']=200; 
		 
		 $vod=$info[0]['video'][$num-1];	 
		 $vod=explode('$', $vod);
		 $DATA['url']=$vod[1];		 
		 $DATA['play']=$info[0]['flag'];
		 $DATA['info']=$info;
	}	 
	return $ret;	   
}
//检测浏览器UA标识
 public function lsUserAgen ($ua)
 { 
    if (strpos($_SERVER['HTTP_USER_AGENT'],$ua) !== false) { return true; } 	
}
 public function out_json($jsoncallback,&$data,$info='')  
   {
	   if($info!=""){
	   $data["success"] = 0;
       $data["code"] = "-1";
       $data["m"] = $msg;		   
	   }	   
	   $json =json_encode($data);
		return  $jsoncallback.'('.$json.');';  	   	    	   
   }   

   
}

 function output_exit($msg){
      global $cb;
	  $data["success"] = 0;
      $data["code"] = "-1";
      $data["m"] = $msg;
      $json =json_encode($data);  
	  echo  $cb.'('.$json.');'; 
      exit();
  }

?>