﻿<?php 

//加载配置文件
require_once 'config.php';

//判断防盗链
if(REFERER_TYPE!=0 && !is_referer()){	
	if (REFERER_TYPE==1){		
		 exit (REFERER_INFO);				
	}else if(REFERER_TYPE==2){	
	    exit(REFERER_INFO."<script>function JumpUrl(){document.location = '".REFERER_JMP."';}setTimeout('JumpUrl()',1000);</script>");		
	}else{
	   header('HTTP/1.1 404 Forbidden');
       exit('404,文件未找到');  		
	}	
 }
//空url自定义显示信息。
if(NULL_TYPE!=0 && !@$_GET["url"] && !@$_GET["wd"]){
		    if(NULL_TYPE==1){
			  exit(NULL_INFO);
		  }else if(NULL_TYPE==2){
      exit("未授权，请联系qq201444307授权。<script>function JumpUrl(){document.location = '".REFERER_JMP."'}setTimeout('JumpUrl()',1000);</script>"); 	
	  }
	}			
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title><?php echo TITLE ?></title>


<link rel="shortcut icon" href="data/images/logo.ico" type="image/icon"/>
<style type="text/css">

body{padding: 0;margin: 0;height:100%;width:100%;background-color:#000; color:#999;}
 a{text-decoration:none;
　　color: #ffffff;
　　font-size: 20px;
　}
.org_box{
	width:120px;
    height:80px;
    line-height:80px; 
    margin-bottom:30px; 
    padding-left:2em;
    background:#F3961C; 
    position:relative; 
}
.org_bot_cor_2{
    height:30px;
    line-height:0; 
    font-size:60px; 
    color:#f3961c; 
    position:absolute; 
    left:60px; 
    bottom:-25px;
}
#word{
		position: absolute;
		z-index: 9999999;
		width: 1300px;
		height: auto;
		background-color: white;
		border: black solid 1px;
		display: none;
	}
  #playlist,#flaglist{
	    text-decoration:none
		top: 20px;
		width: 80px;
		height: auto;
		background-color: white;
		border: black solid 1px;
		display: none;
	}	
	
	.click_work{
		padding-bottom: 8px;
		font-weight:lighter;
		font-size: 13px;
		cursor:pointer;
	}
	.click_work:hover{
		color: orange;
		background-color: gray;
	}
	.error{
		color: gray;
		cursor:pointer;
	}
		
.diyi{ width:100%; height:auto; position:fixed; z-index:999;}
.dier{ width:100%; height:100%; position:absolute; background:#000; z-index:5;}
.dish{ width:100%; height:100%; position:absolute; background:#000; z-index:3;}
.logo{display:block;float:left;width:<?php echo $style['logo_width']?>px;height:<?php echo $style['logo_height']?>px;margin-top:<?php echo $style['logo_top']?>px;margin-left:<?php echo $style['logo_left']?>px; background: transparent url("<?php echo $style['logo_url']?>") no-repeat scroll ;cursor: pointer;}
.list{display:block;float:right;width:<?php echo $style['list_width']?>px;height:<?php echo $style['list_height']?>px;margin-top:<?php echo $style['list_top']?>px;margin-right:<?php echo $style['list_right']?>px;background: transparent url("<?php echo $style['list_url']?>") no-repeat scroll ;cursor: pointer;}
.tip{display:block;float;left:34px;top:-32px;height:32px;width:100%;background: transparent url("data/images/tip.png") no-repeat scroll ;cursor: pointer;}

</style>


<script type="text/javascript" src="ckplayer/ckplayer.js" ></script>
</head>
 <body>
<div>
<div id="play_header"  class="diyi"  > 
<a id="logo"  href="javascript:void(0)" class="logo"   onclick="Createlines()"></a> 
<div id="word" style="display:none;text-decoration:none;margin-top:<?php echo $style['logo_height']?>px;margin-left:<?php echo $style['logo_left']?>px;"></div> 
<a id="list"  class="list" style="display:none" ></a>
<div id="flaglist" style="float:right;"  >  </div> 
<div id="playlist"  style="float:right;"  > </div> 

<a id="tip"  href="javascript:void(0)" class="tip" style="display:none;float:left;margin-left:<?php echo $style['logo_left']?>px;"></a> 



</div>
<div id="playad"  class="dier" align="center" style="display:block"></div>
<div id="player" class="dish"  align="center" style="display:block;background-color:#000" ></div>
</div>
</body>

<script src="data/js/jquery.mini.js"></script><script id="xyplay" src="data/js/xyplay.mini.js?parm=<?php echo enjs($play);?>"></script>


<!--
添加 统计代码然后显示在 下面

<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1273261001'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s22.cnzz.com/z_stat.php%3Fid%3D1273261001%26online%3D1%26show%3Dline' type='text/javascript'%3E%3C/script%3E"));</script>
<script type="text/javascript" src="//js.users.51.la/19425203.js"></script>style="border:none" /></a></noscript>
-->
</body>
</html>