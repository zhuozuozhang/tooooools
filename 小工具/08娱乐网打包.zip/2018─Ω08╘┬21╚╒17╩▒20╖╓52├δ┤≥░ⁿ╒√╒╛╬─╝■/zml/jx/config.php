<?php

//加载核心类库

require_once 'include/main.class.php';

//强制编码

header("Content-type: text/html; charset=utf-8"); 

//定义当前网页地址，无需修改；
define('SERVER_URL','http://'.$_SERVER['SERVER_NAME'].$_SERVER["PHP_SELF"]);
//定义当前顶级域名，无需修改；
define('SERVER_HOST', 'http://'.get_host()); 

//-------------------------------请修改以下配置------------------------------------

//路径设置(保留设置,目前设置无效)；

define('YOU_URL', '/api/');
 
//网站标题设置，后面‘’内填写标题
define('TITLE', '东辉影视解析-东辉影视v.09dh.cn 乔越博客 08娱乐网,免费解析');  

//样式设置,根据图片尺寸修改对应数字即可,单位像素。(height:高度;width:宽度;left:左边距,top:顶边距;right:右边距)

$style=array(
  //左侧logo图标样式设置
  'logo_url'=>'data/images/logo.png',           //logo路径设置
  'logo_width'=>'0',                           //显示宽度,单位：像素，下同。(100为显示 切换线路的logo  0为不显示)
  'logo_height'=>'35',                          //高度
  'logo_top'=>'3',                              //顶边距
  'logo_left'=>'5',                             //左边距
  
  //右侧列表图标样式设置
  'list_url'=>'data/images/list.png',           //列表图标路径设置
  'list_width'=>'16',                           //显示宽度,单位：像素，下同
  'list_height'=>'16',                          //高度
  'list_top'=>'5',                              //顶边距
  'list_right'=>'5',                             //右边距
  
);


//cookie 有效期，单位：小时
define('timecookie', 2)  ;   

//模块输出加密,填写解析所在域名,多个用|隔开，cdn填写cdn域名 。
//完整例子： define('ENCODE_URL','jx.test.com|api.test.com')；
//设置后用户只能访问index.php,防止数据盗用,启用调试模式后,此设置自动失效。

define('ENCODE_URL','');   

//防盗链模式,0为关闭，1为显示信息，2为显示信息并跳转网站,3为返回404错误。
define('REFERER_TYPE', 3);

//防盗链域名,即授权域名,填写解析所在域名,多个用|隔开，cdn填写cdn域名 ；
//完整例子： define('REFERER_URL','09dh.cn|api.test.com')；
define('REFERER_URL', '');     //‘’内填写域名,默认留空不防盗链。

//盗链提示信息,当防盗链模式为1时生效,支持html。
define('REFERER_INFO', '本站已开启防盗链，获取授权请联系东辉影视管理员。');  

//跳转网站,当模式为2时生效,默认为当前顶级域名。 
define('REFERER_JMP', SERVER_HOST);        
             
//空url显示模式，0为关闭，1为显示信息，2为跳转网站,关闭时默认显示"URL地址不能为空!"
define('NULL_TYPE', 1);

//空url提示信息，当空url显示模式为1时生效，支持html。
define('NULL_INFO','<br ><br /><br /><br />URL地址或关键字不能为空!<br /><br />
您调用接口的方式有误, 请正确掉用接口,接口后必须有视频地址<br /><br />
解析接口：http://09dh.cn/jx/?url=<br /><br />
举例：http://09dh.cn/jx/?url=https://v.youku.com/v_show/id_XMTUyMTQ0MDM0NA==.html?spm=a2h0k.11417342.soresults.dposter <br /><br />
本接口只做测试学习使用,请勿用于商业用途,使用本接口后请于24小时内删除,使用本接口造成的任何后果概不负责 <br /><br />
接口正常使用,无任何费用,无广告 <br /><br />
更多使用说明: QQ群 766812861 <br /><br />
东辉影视客服管理QQ：201444307<br />
<br /><br /> </div>');

//定义采集站地址，尽量使用m3u8专用接口，支持苹果，海洋等CMS专用采集接口地址；
//注意：不要设置过多，影响加载速度，尽量添加优质资源。
$API_URL = array(			 
	                              
				"http://api.iokzy.com/inc/apickm3u8.php",                     //OK资源
				"http://www.zdziyuan.com/inc/s_api_zuidam3u8.php",          // 最大资源
				// "http://www.jingpinzy.com/inc/seacmsapi.php",		          //精品资源	
			    //'http://www.33uudy.com/inc/seacmsapi.php',                   //33UU资源
          		//'http://mov.nohacks.cn/zyapi.php',				//星源影视 5W+资源
				
				   
	);	


//采集站来源标签过滤,如果不设置请留空,请根据采集站来源填写,推荐设置：'m3u8|mp4|webm|ogg|uuck'

define('API_TYPE','m3u8|mp4|webm|ogg|uuck');	                        //设置后只显示包含标签的资源来源
	
	
//解析接口设置，参照格式修改,可以无限添加。
$jx_url = array(
                // 无广告解析
                                                        "http://jx.du2.cc/?url=", 
                                                    //    "http://api.zuilingxian.com/jiexi.php?url=", 
				//"http://api.xyingyu.com/?url=", 
				

	);	   		


//此处进行播放相关配置，符号"=>"后为设置内容,必须由单引号包裹,逗号结束，否则出错。

$play = array(

     //pc端配置
     'pcintLine' => '1' ,                       //默认线路
     'pcadTime' => '0' ,                       //缓冲页显示时间，单位:秒,设置为0 则不显示。
     'pcadsPage'=> 'data/ad/wap.html',        //缓冲页

   //移动端配置
   'mintLine'=>'1',                         //默认线路；
    'madTime'=>'0',                     //缓冲页显示时间
   'madsPage'=>'data/ad/wap.html',      //缓冲页

  //公用配置
  
  //云播放相关配置
  'yunoff'=>'0',                  //云播放开关，1为开启，0为关闭，不影响搜索功能。
  'allload'=>'1',                 //是否一次加载全部资源,如果发现云资源加载过慢，请关闭此项。
  'autolist'=>'0',                  //刷新换资源,0关闭,非0启用。
  
  //设置使用云播放的网站，设置为空，则不限制,参考：'iqiyi.com|v.qq.com|v.youku.com'
  
  'yunflag'=>'', 
  
  
 //其它配置 
  'autoLine'=>'0',                 //刷新换线,0关闭,非0启用。
 'timeout'=>'400',              //超时设置,单位毫秒，默认10秒(10000毫秒);
 'timecookie'=>'2',               //cookie有效期，单位:小时 ；
 'ckplay'=>'1',                   //如果可用，是否强制使用在线资源，1为启用，0为关闭。
 'intoff'=>'0',                    //是否启用线路自动选择,1为启用,0为关闭，默认关闭。 
 'imgoff'=>'0',                  //搜索是否输出图片信息，耗费系统大量网络资源，默认关闭。
 //反调试配置
 
 'debug'=>'0',                      //调试模式，默认为'0',禁止调试。
 
 //反调试执行代码，检测到调试后执行的js代码：下面是参考代码：
 //1.跳转网站: 'top.location.href="http://79bk.cn";'
 //2.显示信息：'echo("<br><br><br>该功能被禁止，请联系管理员！");'
 //3.死机代码：'var l="a";for(i=0;i<10;i++){ l=l.replace(new RegExp("","g"),l)};'

 'decode'=>'top.location.href="http://www.79bk.cn/";',   
  
 //线路相关配置
  
 //线路自动选择设置，格式：'视频站域名->线路序号,...'，,多条用逗号分割。
 //'Intarr'=> 'v.youku.com->1,v.qq.com->1,iqiyi.com->1',    
  
 // 指定线路从url，设置后如果url含有设置内容将直接调用设置线路播放，多条用逗号分割,本规则优先级最高。
 // 测试vid:   27panPacuvi4UtgqtPv0J
 
 'urljmp'=>'27pan->http://api2.my230.com/?vid=,BGM->http://api.jp255.com/api/?url=',                
 
  //指定直链从url，设置后如果url含有设置内容将直链打开,优先级高于ckflag标签,多条请用符号"|"分割。
  
 'urlurl'=>'/share/', 
  
  //指定直链从来源，设置后如果来源标签含有设置内容将直链打开，优先级高于ckflag标签,多条请用符号"|"分割。
  
 'urlflag'=>'url|yun|ziyuan', 
  
 
 //指定ck播放从来源，设置后如果来源标签含有设置内容将调用ck播放器播放，,多条请用符号"|"分割。
 
 'ckflag'=>'ogg|mp4|webm|m3u8|uuck',     
 

//版权信息设置
 'ver'=>'不能右键昂',
  'by'=>'东辉影视：你很淘气哦！我这是超稳定解析！', 
 'help'=>'如果播放失败，请切换不同线路！',
 'info'=>'云播放现在已支持剧集连播，刷新可以切换来源!',
 
 
 
);
		
//----------------------------------修改区域结束---------------------------------------


?>
