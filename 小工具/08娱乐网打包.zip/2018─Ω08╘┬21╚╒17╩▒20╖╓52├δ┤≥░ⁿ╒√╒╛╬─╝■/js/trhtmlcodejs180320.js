﻿function yulan180320(trtextareaid180320){
	var temp = document.getElementById(trtextareaid180320).value;
	var test = open("", "test","status=no,menubar=yes,toolbar=no");
	test.document.open();
	test.document.write(temp);
	test.document.close();
}
function quanxuan180320(trtextareaid180320){
	var temp = document.getElementById(trtextareaid180320);
	temp.select();
}
