﻿// JavaScript Document
    $(function () {
        var ie6 = /msie 6/i.test(navigator.userAgent),
            dv = $('#trnavparent178888'),
            st;
        dv.attr('otop', dv.offset().top); //存储原来的距离顶部的距离  
        $(window).scroll(function () {
			var otrnav178888=document.getElementById("trnav178888")
			var otrnavcompensation178888=document.getElementById("trnavcompensation178888")
            var otrnavparent178888 = document.getElementById("trnavparent178888");
//            var otrnavbox178888 = document.getElementById("trnavbox178888");
//            otrnavbox178888height = otrnavbox178888.scrollHeight + 20;
            otr178888winclientheight = document.documentElement.clientHeight
            otr178888bodyscrolltop = document.body.scrollTop
//            bodyclientheight = document.body.clientHeight
            otrnavparent178888offsettop = otrnavparent178888.offsetTop
            otrnavparent178888scrollheight = otrnavparent178888.scrollHeight
            otrnavparent178888scrolltop = otrnavparent178888offsettop - otr178888bodyscrolltop //导航栏顶部距离浏览器上边的距离
            otrnavparent178888scrollbottom = (otr178888bodyscrolltop + otr178888winclientheight) - (otrnavparent178888offsettop + otrnavparent178888scrollheight) //导航栏底部距离浏览器下边的距离
            otrnavmore178888 = otrnavparent178888scrollheight - otr178888winclientheight //导航栏比屏幕高度的数值
            if(otrnavparent178888scrollheight < otr178888winclientheight) {
				//console.log (otrnav178888.offsetHeight)
//				otrnavcompensation178888.style.height =otrnav178888.offsetHeight + 'px'
                st = Math.max(document.body.scrollTop || document.documentElement.scrollTop);
                if(st > parseInt(dv.attr('otop'))) {
                    if(ie6) { //IE6不支持fixed属性，所以只能靠设置position为absolute和top实现此效果  
                        dv.css({
                            position: 'absolute',
                            top: st,
                            "z-index": '999'
                        });
                    } else if(dv.css('position') != 'fixed') dv.css({
                        'position': 'fixed',
                        top: 0,
                        'z-index': '998'
                    });
                    tr178888setnavhidden1();
               } else if(dv.css('position') != 'static') {
                    dv.css({
                        'position': 'static',
                        "z-index": '99'
                    });
                    tr178888setnavhidden2();
                } 
//				else if(st < parseInt(dv.attr('otop'))-1) {
//			var otrnavcompensation178888=document.getElementById("trnavcompensation178888")
// 				otrnavcompensation178888.style.height =0+'px'
//			}
            } else if(otrnavparent178888scrollheight >= otr178888winclientheight && otrnavparent178888.style.position != 'absolute') {
                otr178888bodyscrolltop = document.body.scrollTop;
                otrnavparent178888.style.position = 'absolute'
                otrnavparent178888.style.top = otr178888bodyscrolltop + 'px'
            } else if(otrnavparent178888scrolltop > 0) {
                otr178888bodyscrolltop = document.body.scrollTop;
                otrnavparent178888.style.position = 'absolute'
                otrnavparent178888.style.top = otr178888bodyscrolltop + 'px'
            } else if(otrnavparent178888scrollbottom > 0) {
                //                console.log('b:' + otrnavparent178888scrolltop)
                otr178888bodyscrolltop = document.body.scrollTop;
                otrnavparent178888.style.position = 'absolute'
                otrnavparent178888.style.top = (otr178888bodyscrolltop - otrnavmore178888) + 'px'
            }

        });
    });
    window.onload = tr178888setnavparentwidth;
    window.onresize = tr178888setnavparentwidth;
    function tr178888setnavparentwidth() {
        var bodywidth171108 = document.body.offsetWidth;
        document.getElementById("trnavparent178888").style.width = bodywidth171108 + 'px'
    }
    function tr178888setnavhidden1() {
        var bodywidth171108 = document.body.offsetWidth;
        if(bodywidth171108 > 767) {
            document.getElementById("trlogoother").style.display = "none";
            document.getElementById("trnav178888").style.display = "block";
        } else {
            document.getElementById("trlogoother").style.display = "block";
            document.getElementById("trlogoright178888").style.display = "none";
        }
    }
    function tr178888setnavhidden2() {
        var bodywidth171108 = document.body.offsetWidth;
        if(bodywidth171108 > 767) {
            document.getElementById("trlogoother").style.display = "block";
            document.getElementById("trnav178888").style.display = "block";
        } else {
            document.getElementById("trlogoother").style.display = "block";
            document.getElementById("trlogoright178888").style.display = "block";
        }
    }
