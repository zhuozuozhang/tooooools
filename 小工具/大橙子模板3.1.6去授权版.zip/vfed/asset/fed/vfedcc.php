<?php return array (
  'main' => 
  array (
    'icon' => '',
    'lazy' => '',
    'bigs' => '',
    'back' => '',
    'wane' => 
    array (
      'state' => '0',
      'value' => '5px',
    ),
    'copy' => '',
    'meta' => '',
    'foot' => '',
  ),
  'home' => 
  array (
    'slide' => 
    array (
      'value' => '5',
      'state' => '1',
    ),
    'menu' => 
    array (
      'value' => '1',
      'state' => '0',
    ),
    'note' => 
    array (
      'value' => '1',
      'state' => '1',
    ),
    'small' => 
    array (
      'value' => '5',
      'state' => '0',
    ),
    'shop' => 
    array (
      'value' => '6',
      'state' => '0',
    ),
    'hots' => 
    array (
      'value' => '12',
      'title' => '影院热映',
      'state' => '0',
    ),
    'week' => 
    array (
      'value' => '6',
      'title' => '本周更新',
      'state' => '0',
    ),
    'video' => 
    array (
      'value' => '12',
      'title' => '最新视频',
      'state' => '1',
    ),
    'taoke' => 
    array (
      'value' => '6',
      'title' => '精品推荐',
      'state' => '0',
    ),
    'news' => 
    array (
      'value' => '8',
      'title' => '最新资讯',
      'state' => '1',
    ),
    'class' => 
    array (
      'value' => '6',
      'class' => '6',
      'state' => '1',
    ),
    'actor' => 
    array (
      'value' => '6',
      'title' => '明星',
      'state' => '0',
    ),
    'topic' => 
    array (
      'value' => '3',
      'title' => '专题',
      'state' => '0',
    ),
    'link' => 
    array (
      'value' => '20',
      'title' => '友情链接',
      'state' => '1',
    ),
  ),
  'play' => 
  array (
    'parse' => '//jx.itaoju.top/player.php?url=',
    'pass' => '1',
    'danmu' => '1',
    'auto' => '1',
    'apis' => '1',
    'high' => 
    array (
      'pgao' => '56.25%',
      'wgao' => '56.25%',
    ),
    'tips' => '正在加载...',
    'copy' => '',
    'advs' => 
    array (
      'state' => '0',
      'time' => '5',
      'link' => '',
      'tips' => '广告倒计时',
    ),
    'logo' => 
    array (
      'state' => '0',
      'value' => 'template/vfed/asset/img/logo.png',
    ),
    'pics' => 
    array (
      'state' => '1',
      'value' => 'template/vfed/asset/img/loading.gif',
    ),
    'code' => 
    array (
      'state' => '0',
      'value' => '',
    ),
    'stat' => '',
  ),
  'seos' => 
  array (
    'index' => 
    array (
      'title' => '',
      'word' => '',
      'info' => '',
    ),
    'vinfo' => 
    array (
      'title' => '',
      'word' => '',
      'info' => '',
    ),
    'vplay' => 
    array (
      'title' => '',
      'word' => '',
      'info' => '',
    ),
    'artic' => 
    array (
      'title' => '',
      'word' => '',
      'info' => '',
    ),
    'rinfo' => 
    array (
      'title' => '',
      'word' => '',
      'info' => '',
    ),
    'topic' => 
    array (
      'title' => '',
      'word' => '',
      'info' => '',
    ),
    'tinfo' => 
    array (
      'title' => '',
      'word' => '',
      'info' => '',
    ),
    'actor' => 
    array (
      'title' => '',
      'word' => '',
      'info' => '',
    ),
    'ainfo' => 
    array (
      'title' => '',
      'word' => '',
      'info' => '',
    ),
  ),
  'navs' => 
  array (
    'arts' => 
    array (
      'name' => '',
      'link' => '',
      'state' => '1',
    ),
    'live' => 
    array (
      'name' => '',
      'link' => '',
      'state' => '0',
    ),
    'song' => 
    array (
      'name' => '',
      'link' => '',
      'state' => '0',
    ),
    'topic' => 
    array (
      'name' => '',
      'link' => '',
      'state' => '1',
    ),
    'gbook' => 
    array (
      'name' => '',
      'link' => '',
      'state' => '1',
    ),
    'head' => 
    array (
      'value' => '4',
      'state' => '1',
    ),
    'case' => 
    array (
      'value' => '',
      'state' => '0',
    ),
    'foot' => '1',
    'node' => '0',
  ),
  'rest' => 
  array (
    'coll' => 
    array (
      'href' => '/template/vfed/asset/js/collect.js',
      'state' => '0',
    ),
    'theme' => 
    array (
      'skin' => '0',
      'state' => '1',
    ),
    'share' => 
    array (
      'state' => '1',
      'host' => '',
    ),
    'taoke' => 
    array (
      'dkey' => '',
      'home' => '',
    ),
    'note' => 
    array (
      'state' => '0',
      'value' => '1',
    ),
    'play' => '6',
    'arts' => '10',
    'font' => '0',
  ),
  'advs' => 
  array (
    'fits' => 
    array (
      'state' => '0',
    ),
    'home' => 
    array (
      'head' => '',
      'foot' => '',
    ),
    'play' => 
    array (
      'head' => '',
      'inne' => '',
      'foot' => '',
      'list' => '',
    ),
  ),
);?>